package buffer

import (
	"strings"
	"unicode"
	"unicode/utf8"
)

// SetLines substitui o conteúdo inteiro do buffer (usado pelo formatador
// de código externo), como uma única alteração de undo.
func (b *Buffer) SetLines(newLines []string) {
	if len(newLines) == 0 {
		newLines = []string{""}
	}
	b.MarkUndoPoint()
	b.Lines = newLines
	b.ClearSelection()
	if b.CursorY >= len(b.Lines) {
		b.CursorY = len(b.Lines) - 1
	}
	if b.CursorY < 0 {
		b.CursorY = 0
	}
	if b.CursorX > len(b.Lines[b.CursorY]) {
		b.CursorX = len(b.Lines[b.CursorY])
	}
	b.Dirty = true
}

// --- Indentação em bloco (Tab / Shift+Tab com seleção) ---

// IndentSelection adiciona indentStr no início de cada linha tocada pela
// seleção atual (como o Tab do VS Code quando há texto selecionado).
func (b *Buffer) IndentSelection(indentStr string) {
	if !b.Selecting || indentStr == "" {
		return
	}
	sy, _, ey, _ := b.selectionRange()
	b.snapshotPush()
	b.breakRun()
	for y := sy; y <= ey; y++ {
		b.Lines[y] = indentStr + b.Lines[y]
	}
	b.SelStartX += len(indentStr)
	b.CursorX += len(indentStr)
	b.Dirty = true
}

// dedentLineAt remove até tabWidth espaços (ou 1 tab literal) do início da
// linha y, e devolve quantos caracteres foram removidos.
func (b *Buffer) dedentLineAt(y, tabWidth int) int {
	line := b.Lines[y]
	if strings.HasPrefix(line, "\t") {
		b.Lines[y] = line[1:]
		return 1
	}
	n := 0
	for n < tabWidth && n < len(line) && line[n] == ' ' {
		n++
	}
	if n > 0 {
		b.Lines[y] = line[n:]
	}
	return n
}

// DedentSelection remove um nível de indentação de cada linha selecionada.
func (b *Buffer) DedentSelection(tabWidth int) {
	if !b.Selecting {
		return
	}
	sy, _, ey, _ := b.selectionRange()
	b.snapshotPush()
	b.breakRun()
	for y := sy; y <= ey; y++ {
		b.dedentLineAt(y, tabWidth)
	}
	b.clampCursor()
	if b.SelStartX > len(b.Lines[b.SelStartY]) {
		b.SelStartX = len(b.Lines[b.SelStartY])
	}
	b.Dirty = true
}

// DedentCurrentLine remove um nível de indentação da linha do cursor
// (Shift+Tab sem seleção).
func (b *Buffer) DedentCurrentLine(tabWidth int) {
	b.snapshotPush()
	b.breakRun()
	b.dedentLineAt(b.CursorY, tabWidth)
	b.clampCursor()
	b.Dirty = true
}

// --- Delete (tecla Delete, apaga pra frente) ---

// DeleteForward apaga o caractere sob o cursor (ou junta com a linha de
// baixo, se o cursor estiver no fim da linha). Chamadas consecutivas são
// agrupadas num único passo de undo, como Backspace/InsertRune.
func (b *Buffer) DeleteForward() {
	if b.Selecting {
		b.DeleteSelection()
		return
	}
	atEnd := b.CursorY == len(b.Lines)-1 && b.CursorX == len(b.Lines[b.CursorY])
	if atEnd {
		return
	}
	if b.runKind != 'd' || b.runAtX != b.CursorX || b.runAtY != b.CursorY {
		b.snapshotPush()
		b.runKind = 'd'
	}
	line := b.Lines[b.CursorY]
	if b.CursorX >= len(line) {
		b.Lines[b.CursorY] = line + b.Lines[b.CursorY+1]
		b.Lines = append(b.Lines[:b.CursorY+1], b.Lines[b.CursorY+2:]...)
	} else {
		_, size := utf8.DecodeRuneInString(line[b.CursorX:])
		b.Lines[b.CursorY] = line[:b.CursorX] + line[b.CursorX+size:]
	}
	b.runAtX = b.CursorX
	b.runAtY = b.CursorY
	b.Dirty = true
}

// --- Modo overwrite (tecla Insert) ---

// OverwriteRune substitui o caractere sob o cursor pelo caractere digitado,
// em vez de empurrar o resto da linha pra frente. No fim da linha, se
// comporta como uma inserção normal.
func (b *Buffer) OverwriteRune(r rune) {
	if b.Selecting {
		b.DeleteSelection()
	}
	if b.runKind != 'i' || b.runAtX != b.CursorX || b.runAtY != b.CursorY {
		b.snapshotPush()
		b.runKind = 'i'
	}
	line := b.Lines[b.CursorY]
	newRune := string(r)
	if b.CursorX < len(line) {
		_, size := utf8.DecodeRuneInString(line[b.CursorX:])
		b.Lines[b.CursorY] = line[:b.CursorX] + newRune + line[b.CursorX+size:]
	} else {
		b.Lines[b.CursorY] = line + newRune
	}
	b.CursorX += len(newRune)
	b.runAtX = b.CursorX
	b.runAtY = b.CursorY
	b.Dirty = true
}

// --- Seleção ---

// StartSelection marca o início de uma seleção na posição atual do cursor,
// se ainda não houver uma em andamento.
func (b *Buffer) StartSelection() {
	if !b.Selecting {
		b.Selecting = true
		b.SelStartX = b.CursorX
		b.SelStartY = b.CursorY
	}
}

// ClearSelection cancela a seleção atual (sem apagar texto).
func (b *Buffer) ClearSelection() {
	b.Selecting = false
}

// SelectAll seleciona o buffer inteiro.
func (b *Buffer) SelectAll() {
	b.Selecting = true
	b.SelStartX = 0
	b.SelStartY = 0
	b.CursorY = len(b.Lines) - 1
	b.CursorX = len(b.Lines[b.CursorY])
}

// selectionRange devolve os limites da seleção já normalizados
// (início sempre antes do fim, na ordem do texto).
func (b *Buffer) selectionRange() (sy, sx, ey, ex int) {
	sy, sx, ey, ex = b.SelStartY, b.SelStartX, b.CursorY, b.CursorX
	if sy > ey || (sy == ey && sx > ex) {
		sy, sx, ey, ex = ey, ex, sy, sx
	}
	return
}

// SelectionLines devolve as linhas [y0,y1] (inclusive, normalizadas)
// cobertas pela seleção atual — versão pública de selectionRange, só
// com as linhas (sem coluna), pra quem só precisa saber quais linhas
// estão selecionadas (ex: comentar/descomentar em bloco). Devolve
// ok=false se não houver seleção ativa.
func (b *Buffer) SelectionLines() (y0, y1 int, ok bool) {
	if !b.Selecting {
		return 0, 0, false
	}
	y0, _, y1, _ = b.selectionRange()
	return y0, y1, true
}

// SelectedText devolve o texto selecionado (linhas juntadas com \n).
func (b *Buffer) SelectedText() string {
	if !b.Selecting {
		return ""
	}
	sy, sx, ey, ex := b.selectionRange()
	if sy == ey {
		line := b.Lines[sy]
		if sx > len(line) {
			sx = len(line)
		}
		if ex > len(line) {
			ex = len(line)
		}
		return line[sx:ex]
	}
	var parts []string
	parts = append(parts, b.Lines[sy][sx:])
	for y := sy + 1; y < ey; y++ {
		parts = append(parts, b.Lines[y])
	}
	last := b.Lines[ey]
	if ex > len(last) {
		ex = len(last)
	}
	parts = append(parts, last[:ex])
	return strings.Join(parts, "\n")
}

// DeleteSelection apaga o trecho selecionado e deixa o cursor no ponto do corte.
func (b *Buffer) DeleteSelection() {
	if !b.Selecting {
		return
	}
	sy, sx, ey, ex := b.selectionRange()
	b.snapshotPush()
	b.breakRun()

	if sy == ey {
		line := b.Lines[sy]
		if ex > len(line) {
			ex = len(line)
		}
		b.Lines[sy] = line[:sx] + line[ex:]
	} else {
		last := b.Lines[ey]
		if ex > len(last) {
			ex = len(last)
		}
		merged := b.Lines[sy][:sx] + last[ex:]
		newLines := make([]string, 0, len(b.Lines)-(ey-sy))
		newLines = append(newLines, b.Lines[:sy]...)
		newLines = append(newLines, merged)
		newLines = append(newLines, b.Lines[ey+1:]...)
		b.Lines = newLines
	}
	b.CursorY = sy
	b.CursorX = sx
	b.Selecting = false
	b.Dirty = true
}

// --- Duplicar / mover linha ---

// DuplicateLine copia a linha atual logo abaixo dela.
// DuplicateSelectionDown duplica todas as linhas cobertas pela seleção
// atual, inserindo a cópia logo abaixo — a seleção passa a apontar pra
// cópia nova (igual o VS Code faz quando duplica com algo selecionado).
func (b *Buffer) DuplicateSelectionDown() {
	sy, _, ey, _ := b.selectionRange()
	b.snapshotPush()
	b.breakRun()
	block := append([]string{}, b.Lines[sy:ey+1]...)
	newLines := make([]string, 0, len(b.Lines)+len(block))
	newLines = append(newLines, b.Lines[:ey+1]...)
	newLines = append(newLines, block...)
	newLines = append(newLines, b.Lines[ey+1:]...)
	b.Lines = newLines
	n := ey - sy + 1
	b.SelStartY += n
	b.CursorY += n
	b.Dirty = true
}

// DuplicateSelectionUp duplica todas as linhas cobertas pela seleção
// atual, inserindo a cópia logo acima — a seleção continua marcando o
// mesmo texto (que agora é a cópia de cima), igual o VS Code.
func (b *Buffer) DuplicateSelectionUp() {
	sy, _, ey, _ := b.selectionRange()
	b.snapshotPush()
	b.breakRun()
	block := append([]string{}, b.Lines[sy:ey+1]...)
	newLines := make([]string, 0, len(b.Lines)+len(block))
	newLines = append(newLines, b.Lines[:sy]...)
	newLines = append(newLines, block...)
	newLines = append(newLines, b.Lines[sy:]...)
	b.Lines = newLines
	// SelStartY/CursorY não mudam: continuam nas mesmas linhas, que
	// agora são a cópia (o original foi empurrado pra baixo)
	b.Dirty = true
}

func (b *Buffer) DuplicateLine() {
	b.snapshotPush()
	b.breakRun()
	line := b.Lines[b.CursorY]
	newLines := make([]string, 0, len(b.Lines)+1)
	newLines = append(newLines, b.Lines[:b.CursorY+1]...)
	newLines = append(newLines, line)
	newLines = append(newLines, b.Lines[b.CursorY+1:]...)
	b.Lines = newLines
	b.CursorY++
	b.Dirty = true
}

// DuplicateLineUp duplica a linha atual, mas a cópia entra ACIMA — o
// cursor fica na cópia nova (que agora é a linha de cima), igual o
// Shift+Alt+Up do VS Code.
func (b *Buffer) DuplicateLineUp() {
	b.snapshotPush()
	b.breakRun()
	line := b.Lines[b.CursorY]
	newLines := make([]string, 0, len(b.Lines)+1)
	newLines = append(newLines, b.Lines[:b.CursorY]...)
	newLines = append(newLines, line)
	newLines = append(newLines, b.Lines[b.CursorY:]...)
	b.Lines = newLines
	// CursorY fica igual: antes apontava pro original, agora aponta pra
	// cópia (que entrou no mesmo índice, empurrando o original pra baixo)
	b.Dirty = true
}

// MoveLineUp troca a linha atual de lugar com a linha acima.
func (b *Buffer) MoveLineUp() {
	if b.CursorY == 0 {
		return
	}
	b.snapshotPush()
	b.breakRun()
	b.Lines[b.CursorY-1], b.Lines[b.CursorY] = b.Lines[b.CursorY], b.Lines[b.CursorY-1]
	b.CursorY--
	b.Dirty = true
}

// MoveLineDown troca a linha atual de lugar com a linha abaixo.
func (b *Buffer) MoveLineDown() {
	if b.CursorY >= len(b.Lines)-1 {
		return
	}
	b.snapshotPush()
	b.breakRun()
	b.Lines[b.CursorY+1], b.Lines[b.CursorY] = b.Lines[b.CursorY], b.Lines[b.CursorY+1]
	b.CursorY++
	b.Dirty = true
}

// --- Comentário de linha ---

// ToggleLineComment adiciona ou remove o prefixo de comentário (ex: "//")
// no início do conteúdo da linha atual.
func (b *Buffer) ToggleLineComment(prefix string) {
	if prefix == "" {
		return
	}
	b.snapshotPush()
	b.breakRun()
	line := b.Lines[b.CursorY]
	trimmed := strings.TrimLeft(line, " \t")
	indent := line[:len(line)-len(trimmed)]

	if strings.HasPrefix(trimmed, prefix+" ") {
		b.Lines[b.CursorY] = indent + strings.TrimPrefix(trimmed, prefix+" ")
	} else if strings.HasPrefix(trimmed, prefix) {
		b.Lines[b.CursorY] = indent + strings.TrimPrefix(trimmed, prefix)
	} else {
		b.Lines[b.CursorY] = indent + prefix + " " + trimmed
	}
	b.Dirty = true
}

// ToggleLineCommentRange faz a mesma coisa que ToggleLineComment, mas
// em todas as linhas de [y0,y1] (inclusive) de uma vez, como uma única
// alteração de undo — usado quando há uma seleção de várias linhas em
// cima de uma linguagem que só tem comentário de linha (bash, python,
// etc), sem comentário em bloco. Decide comentar ou descomentar
// olhando se todas as linhas não-vazias do intervalo já estão
// comentadas; linhas em branco dentro do intervalo são ignoradas (não
// ganham prefixo à toa).
func (b *Buffer) ToggleLineCommentRange(y0, y1 int, prefix string) {
	if prefix == "" || y0 > y1 || y0 < 0 || y1 >= len(b.Lines) {
		return
	}
	b.snapshotPush()
	b.breakRun()

	allCommented := true
	hasContent := false
	for y := y0; y <= y1; y++ {
		trimmed := strings.TrimLeft(b.Lines[y], " \t")
		if trimmed == "" {
			continue
		}
		hasContent = true
		if !strings.HasPrefix(trimmed, prefix) {
			allCommented = false
			break
		}
	}
	if !hasContent {
		allCommented = false // bloco só com linhas vazias: comenta (nao ha nada pra descomentar)
	}

	for y := y0; y <= y1; y++ {
		line := b.Lines[y]
		trimmed := strings.TrimLeft(line, " \t")
		if trimmed == "" {
			continue
		}
		indent := line[:len(line)-len(trimmed)]
		if allCommented {
			if strings.HasPrefix(trimmed, prefix+" ") {
				b.Lines[y] = indent + strings.TrimPrefix(trimmed, prefix+" ")
			} else {
				b.Lines[y] = indent + strings.TrimPrefix(trimmed, prefix)
			}
		} else {
			b.Lines[y] = indent + prefix + " " + trimmed
		}
	}
	b.Dirty = true
	b.ClearSelection()
	b.CursorY = y0
	b.CursorX = 0
}

// ToggleBlockComment envolve (ou remove o envoltório) o intervalo de
// linhas [y0,y1] com marcadores de comentário em bloco (ex: "/*" e
// "*/"), cada marcador na sua própria linha — usado quando há uma
// seleção de várias linhas em cima de uma linguagem que suporta
// comentário em bloco (C, Go, Java, JS...). Descomenta se a primeira
// linha do intervalo for exatamente o marcador de abertura e a última
// for exatamente o de fechamento (ou seja, foi comentado por essa
// mesma função antes); senão, comenta.
func (b *Buffer) ToggleBlockComment(y0, y1 int, start, end string) {
	if start == "" || end == "" || y0 > y1 || y0 < 0 || y1 >= len(b.Lines) {
		return
	}
	b.snapshotPush()
	b.breakRun()

	firstTrim := strings.TrimSpace(b.Lines[y0])
	lastTrim := strings.TrimSpace(b.Lines[y1])
	if firstTrim == start && lastTrim == end {
		newLines := make([]string, 0, len(b.Lines)-2)
		newLines = append(newLines, b.Lines[:y0]...)
		newLines = append(newLines, b.Lines[y0+1:y1]...)
		newLines = append(newLines, b.Lines[y1+1:]...)
		b.Lines = newLines
	} else {
		newLines := make([]string, 0, len(b.Lines)+2)
		newLines = append(newLines, b.Lines[:y0]...)
		newLines = append(newLines, start)
		newLines = append(newLines, b.Lines[y0:y1+1]...)
		newLines = append(newLines, end)
		newLines = append(newLines, b.Lines[y1+1:]...)
		b.Lines = newLines
	}
	b.Dirty = true
	b.ClearSelection()
	b.CursorY = y0
	b.CursorX = 0
}

// --- Paste ---

// InsertTextAtCursor insere um texto (possivelmente multi-linha) na posição
// do cursor, substituindo a seleção atual se houver uma.
func (b *Buffer) InsertTextAtCursor(text string) {
	if b.Selecting {
		b.DeleteSelection()
	} else {
		b.snapshotPush()
		b.breakRun()
	}
	for _, r := range text {
		if r == '\n' {
			line := b.Lines[b.CursorY]
			before := line[:b.CursorX]
			after := line[b.CursorX:]
			b.Lines[b.CursorY] = before
			newLines := make([]string, 0, len(b.Lines)+1)
			newLines = append(newLines, b.Lines[:b.CursorY+1]...)
			newLines = append(newLines, after)
			newLines = append(newLines, b.Lines[b.CursorY+1:]...)
			b.Lines = newLines
			b.CursorY++
			b.CursorX = 0
			continue
		}
		line := b.Lines[b.CursorY]
		s := string(r)
		b.Lines[b.CursorY] = line[:b.CursorX] + s + line[b.CursorX:]
		b.CursorX += len(s) // tamanho em BYTES do caractere, não sempre 1 —
		// caracteres acentuados/emoji ocupam mais de 1 byte em UTF-8; avançar
		// sempre 1 cortava eles ao meio, corrompendo o texto colado.
	}
	b.Dirty = true
}

// ReplaceRange troca o texto de [x0,x1) na linha y pelo texto novo, como
// uma única alteração de undo — usado pelo autocompletar (aceitar uma
// sugestão é uma substituição só, não caractere por caractere).
func (b *Buffer) ReplaceRange(y, x0, x1 int, text string) {
	if y < 0 || y >= len(b.Lines) {
		return
	}
	line := b.Lines[y]
	if x0 < 0 {
		x0 = 0
	}
	if x1 > len(line) {
		x1 = len(line)
	}
	if x0 > x1 {
		x0 = x1
	}
	b.MarkUndoPoint()
	b.Lines[y] = line[:x0] + text + line[x1:]
	b.CursorY = y
	b.CursorX = x0 + len(text)
	b.Dirty = true
}

// GoToLine posiciona o cursor no início da linha n (1-indexed pro usuário).
func (b *Buffer) GoToLine(n int) {
	b.breakRun()
	y := n - 1
	if y < 0 {
		y = 0
	}
	if y >= len(b.Lines) {
		y = len(b.Lines) - 1
	}
	b.CursorY = y
	b.CursorX = 0
}

// --- Renomear todas as ocorrências (F2, como o "Rename Symbol" do VS Code) ---

// isWordChar decide o que conta como "parte da mesma palavra" pro F2.
// Só corta em espaço em branco — qualquer outra coisa (hífen, ponto,
// parênteses, barra, etc.) conta como parte do mesmo token. Bom pra
// nomes de comando/pacote colados (void-install, /usr/bin/env) — em
// código, também engole parênteses/vírgula em volta se estiverem
// colados sem espaço (ex: "print(contador)" vira um token só).
// isWordChar decide o que conta como "parte da mesma palavra" pro F2.
// Corta em espaço em branco e também em =, " e ' — assim
// variavel="teste" vira 3 pedaços (variavel / = / "teste"), e marcar
// em cima de "variavel" pega só ela, marcar dentro da string pega só
// a string, sem grudar tudo por causa do = ou das aspas.
func isWordChar(r rune) bool {
	if unicode.IsSpace(r) {
		return false
	}
	switch r {
	case '=', '"', '\'':
		return false
	}
	return true
}

// WordUnderCursor devolve a palavra (identificador) tocada pela posição
// atual do cursor — olhando tanto pra trás quanto pra frente a partir de
// CursorX, então funciona tanto com o cursor no meio da palavra quanto
// logo depois dela. Devolve "" se o cursor não estiver em cima de nada.
func (b *Buffer) WordUnderCursor() string {
	word, _, _ := b.WordUnderCursorBounds()
	return word
}

// WordUnderCursorBounds é como WordUnderCursor, mas também devolve os
// limites [start,end) da palavra na linha (em bytes) — usado pra saber a
// posição relativa do cursor dentro da palavra (início, meio ou fim).
func (b *Buffer) WordUnderCursorBounds() (word string, start, end int) {
	line := b.Lines[b.CursorY]
	x := b.CursorX

	start = x
	for start > 0 {
		r, size := utf8.DecodeLastRuneInString(line[:start])
		if !isWordChar(r) {
			break
		}
		start -= size
	}
	end = x
	for end < len(line) {
		r, size := utf8.DecodeRuneInString(line[end:])
		if !isWordChar(r) {
			break
		}
		end += size
	}
	if start == end {
		return "", 0, 0
	}
	return line[start:end], start, end
}

// ReplaceWholeWord troca toda ocorrência EXATA de word (respeitando limite
// de palavra — não troca "gato" dentro de "gatos") por repl, no buffer
// inteiro. Devolve quantas trocas fez.
// WordOccurrence é a posição (linha, byte inicial, byte final) de uma
// ocorrência trocada por ReplaceWholeWordPreview, nas coordenadas do
// texto RESULTANTE (depois da troca) — usado pra destacar na tela.
type WordOccurrence struct {
	Y, X0, X1 int
}

// ReplaceWholeWordPreview calcula como origLines ficaria se toda ocorrência
// EXATA de word (respeitando limite de palavra) fosse trocada por repl —
// sem tocar no buffer nem no histórico de undo. Devolve as linhas
// resultantes e a posição de cada ocorrência trocada, pra destaque visual.
// É a base tanto do F2 (renomear ao vivo) quanto do ReplaceWholeWord.
func ReplaceWholeWordPreview(origLines []string, word, repl string) ([]string, []WordOccurrence) {
	newLines := make([]string, len(origLines))
	var occs []WordOccurrence
	if word == "" {
		copy(newLines, origLines)
		return newLines, occs
	}
	for i, line := range origLines {
		var sb strings.Builder
		j := 0
		for j < len(line) {
			idx := strings.Index(line[j:], word)
			if idx < 0 {
				sb.WriteString(line[j:])
				break
			}
			abs := j + idx
			beforeOK := abs == 0
			if !beforeOK {
				r, _ := utf8.DecodeLastRuneInString(line[:abs])
				beforeOK = !isWordChar(r)
			}
			afterPos := abs + len(word)
			afterOK := afterPos == len(line)
			if !afterOK {
				r, _ := utf8.DecodeRuneInString(line[afterPos:])
				afterOK = !isWordChar(r)
			}
			sb.WriteString(line[j:abs])
			if beforeOK && afterOK {
				x0 := sb.Len()
				sb.WriteString(repl)
				x1 := sb.Len()
				occs = append(occs, WordOccurrence{Y: i, X0: x0, X1: x1})
			} else {
				sb.WriteString(word)
			}
			j = afterPos
		}
		newLines[i] = sb.String()
	}
	return newLines, occs
}

// ReplaceWholeWord troca toda ocorrência EXATA de word (respeitando limite
// de palavra — não troca "gato" dentro de "gatos") por repl, no buffer
// inteiro, como uma única alteração de undo. Devolve quantas trocas fez.
func (b *Buffer) ReplaceWholeWord(word, repl string) int {
	if word == "" {
		return 0
	}
	b.snapshotPush()
	b.breakRun()
	newLines, occs := ReplaceWholeWordPreview(b.Lines, word, repl)
	b.Lines = newLines
	if len(occs) > 0 {
		b.Dirty = true
	}
	return len(occs)
}
