/*
   goedit
   Editor de texto para terminal (TUI), com realce de sintaxe, plugins Lua, seleção em bloco e mais
   Site:      https://chililinux.com
   Site:      https://voidbr.org
   Site:      https://voidlinux.com.br
   GitHub:    https://github.com/voidlinuxbr/voidbr-goedit
   Created:   ter 20 out 2026 21:11:29 -04
   Updated:   ter 20 out 2026 21:36:03 -04
   Version:   0.46.0
   Copyright (C) 2019-2026 Vilmar Catafesta <vcatafesta@gmail.com>
*/

package ui

import (
	"hash/fnv"

	"github.com/gdamore/tcell/v2"
	"github.com/mattn/go-runewidth"

	"goedit/internal/buffer"
	"goedit/internal/markdown"
)

// previewCache guarda o documento já formatado por aba — só refaz
// quando o texto ou a largura mudam (busca/substituir ainda funcionam
// no preview e podem mexer no texto).
type previewCache struct {
	hash  uint64
	width int
	lines []markdown.Line
}

var previewCaches = map[*buffer.Buffer]*previewCache{}

func linesHash(lines []string) uint64 {
	h := fnv.New64a()
	for _, l := range lines {
		h.Write([]byte(l))
		h.Write([]byte{'\n'})
	}
	return h.Sum64()
}

func previewLines(b *buffer.Buffer, width int) []markdown.Line {
	h := linesHash(b.Lines)
	pc := previewCaches[b]
	if pc == nil || pc.hash != h || pc.width != width {
		pc = &previewCache{hash: h, width: width, lines: markdown.Render(b.Lines, width)}
		previewCaches[b] = pc
	}
	return pc.lines
}

// TogglePreview (F5) alterna a aba ativa entre editar e visualizar o
// Markdown renderizado. Sem rolar no preview, o cursor volta exatamente
// onde estava; rolando, volta pro trecho que estava no topo da tela.
func (a *App) TogglePreview() {
	b := a.ActiveBuffer()
	if !b.Preview {
		if !markdown.IsMarkdown(b.Path) {
			a.SetStatusMsg("preview só para arquivos Markdown (.md)")
			return
		}
		a.SuggestActive = false
		b.ClearSelection()
		b.Preview = true
		b.PreviewScrolled = false
		b.PreviewLastCursorY = -1 // força alinhar o preview ao cursor no próximo desenho
		a.SetStatusMsg("preview — F5 ou Esc volta a editar")
		return
	}
	b.Preview = false
	if b.PreviewScrolled {
		if pc := previewCaches[b]; pc != nil && b.PreviewOffset < len(pc.lines) {
			src := pc.lines[b.PreviewOffset].Src
			if src >= 0 && src < len(b.Lines) {
				b.CursorY, b.CursorX, b.OffsetY = src, 0, src
			}
		}
	}
	a.SetStatusMsg("")
}

func (a *App) drawPreview(bufIdx, x, y, width, height int, tabRanges []TabRange) PaneLayout {
	b := a.Buffers[bufIdx]
	textTop := y + 1
	textHeight := height - 1
	margin := 1
	contentW := width - 2*margin
	lines := previewLines(b, contentW)

	// cursor mudou por fora (busca, ir pra linha...) ou acabou de
	// entrar no preview: alinha o preview ao trecho do cursor, na
	// mesma altura de tela em que ele estava no modo de edição.
	if b.CursorY != b.PreviewLastCursorY {
		idx := 0
		for i, l := range lines {
			if l.Src >= b.CursorY {
				idx = i
				break
			}
			idx = i
		}
		b.PreviewOffset = idx - (b.CursorY - b.OffsetY)
		b.PreviewLastCursorY = b.CursorY
		b.PreviewScrolled = false
	}
	maxOff := len(lines) - textHeight
	if maxOff < 0 {
		maxOff = 0
	}
	b.PreviewOffset = clamp(b.PreviewOffset, 0, maxOff)

	for row := 0; row < textHeight; row++ {
		sy := textTop + row
		for cx := x; cx < x+width; cx++ {
			a.Screen.SetContent(cx, sy, ' ', nil, styleDefault)
		}
		li := b.PreviewOffset + row
		if li >= len(lines) {
			continue
		}
		cx := x + margin
		for _, seg := range lines[li].Segs {
			for _, r := range seg.Text {
				w := runewidth.RuneWidth(r)
				if w <= 0 {
					w = 1
				}
				if cx+w > x+width-margin {
					break
				}
				a.Screen.SetContent(cx, sy, r, nil, seg.Style)
				cx += w
			}
		}
	}

	return PaneLayout{
		BufIdx:     bufIdx,
		X:          x,
		TabY:       y,
		TextTop:    textTop,
		TextX:      x + margin,
		Width:      width,
		TextHeight: textHeight,
		TabRanges:  tabRanges,
	}
}

// handlePreviewKey: preview é só leitura. Setas/PgUp/PgDn/Home/End
// rolam, Esc volta a editar, atalhos "de app" (salvar, sair, abas,
// buscar, ajuda...) continuam valendo; o resto só avisa.
func (a *App) handlePreviewKey(ev *tcell.EventKey) {
	b := a.ActiveBuffer()
	page := a.pageHeight()
	km := a.Settings.Keymap
	scroll := func(d int) {
		b.PreviewOffset += d
		if b.PreviewOffset < 0 {
			b.PreviewOffset = 0
		}
		b.PreviewScrolled = true
	}
	switch ev.Key() {
	case tcell.KeyEsc:
		a.TogglePreview()
		return
	case tcell.KeyUp:
		scroll(-1)
		return
	case tcell.KeyDown:
		scroll(1)
		return
	case tcell.KeyPgUp:
		scroll(-page)
		return
	case tcell.KeyPgDn:
		scroll(page)
		return
	case tcell.KeyHome:
		b.PreviewOffset = 0
		b.PreviewScrolled = true
		return
	case tcell.KeyEnd:
		b.PreviewOffset = 1 << 30 // drawPreview limita ao fim
		b.PreviewScrolled = true
		return
	case tcell.KeyRune:
		if ev.Rune() == ' ' && ev.Modifiers()&tcell.ModAlt == 0 {
			scroll(page)
			return
		}
	case tcell.KeyCtrlY:
		if km == "nano" {
			scroll(-page)
			return
		}
	case tcell.KeyCtrlV:
		if km == "nano" {
			scroll(page)
			return
		}
	}

	if previewPassthrough(ev, km) {
		if (km == "nano" || km == "nano-hibrido") && a.tryNanoKey(ev) {
			return
		}
		if a.handleGlobalAppShortcut(ev) {
			return
		}
		if ev.Key() == tcell.KeyF3 {
			a.doFind(true)
			return
		}
	}
	a.SetStatusMsg("preview é só leitura — F5 ou Esc volta a editar")
}

// previewPassthrough lista as teclas que continuam funcionando no
// preview — nenhuma delas edita o texto diretamente.
func previewPassthrough(ev *tcell.EventKey, km string) bool {
	if ev.Modifiers()&tcell.ModAlt != 0 {
		return ev.Key() == tcell.KeyLeft || ev.Key() == tcell.KeyRight
	}
	switch ev.Key() {
	case tcell.KeyCtrlS, tcell.KeyCtrlX, tcell.KeyCtrlQ, tcell.KeyCtrlN, tcell.KeyCtrlO,
		tcell.KeyCtrlW, tcell.KeyCtrlB, tcell.KeyCtrlBackslash, tcell.KeyCtrlL, tcell.KeyCtrlF,
		tcell.KeyCtrlG, tcell.KeyCtrlP, tcell.KeyF1, tcell.KeyF3, tcell.KeyF6, tcell.KeyF9:
		return true
	case tcell.KeyCtrlH: // no nano clássico Ctrl+H é backspace
		return km != "nano"
	case tcell.KeyCtrlUnderscore, tcell.KeyCtrlC: // nano: ir pra linha / posição
		return km == "nano"
	}
	return false
}
