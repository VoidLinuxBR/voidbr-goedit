/*
   goedit
   Editor de texto para terminal (TUI), com realce de sintaxe, plugins Lua, seleção em bloco e mais
   Site:      https://chililinux.com
   Site:      https://voidbr.org
   Site:      https://voidlinux.com.br
   GitHub:    https://github.com/voidlinuxbr/voidbr-goedit
   Created:   ter 20 out 2026 21:11:29 -04
   Updated:   ter 20 out 2026 21:36:03 -04
   Version:   0.46.0
   Copyright (C) 2019-2026 Vilmar Catafesta <vcatafesta@gmail.com>
*/

package syntax

import (
	"strings"

	"github.com/alecthomas/chroma/v2"
	"github.com/alecthomas/chroma/v2/lexers"
	"github.com/gdamore/tcell/v2"
)

// codeLexerCache guarda o lexer resolvido pelo nome da linguagem citada
// num bloco cercado do Markdown (```bash, ```go, ```python...). nil =
// linguagem desconhecida (já sabemos, não precisa procurar de novo).
var codeLexerCache = map[string]chroma.Lexer{}

// codeLangAlias cobre nomes comuns em blocos de Markdown que o chroma
// não reconhece direto pelo nome/apelido.
var codeLangAlias = map[string]string{
	"sh":         "bash",
	"shell":      "bash",
	"console":    "bash",
	"zsh":        "bash",
	"py":         "python",
	"js":         "javascript",
	"ts":         "typescript",
	"yml":        "yaml",
	"golang":     "go",
	"rs":         "rust",
	"md":         "markdown",
	"dockerfile": "docker",
	"conf":       "ini",
}

func codeLexer(lang string) chroma.Lexer {
	lang = strings.ToLower(strings.TrimSpace(lang))
	if lang == "" {
		return nil
	}
	resultCacheMu.Lock()
	lx, ok := codeLexerCache[lang]
	resultCacheMu.Unlock()
	if ok {
		return lx
	}
	name := lang
	if alias, ok := codeLangAlias[lang]; ok {
		name = alias
	}
	lx = lexers.Get(name)
	if lx != nil {
		lx = chroma.Coalesce(lx)
	}
	resultCacheMu.Lock()
	codeLexerCache[lang] = lx
	resultCacheMu.Unlock()
	return lx
}

// HighlightCode tokeniza uma linha de código de uma linguagem citada
// pelo nome (o "info string" de um bloco cercado do Markdown). Linguagem
// vazia ou desconhecida devolve a linha inteira com fallback — o
// chamador decide a cor padrão do bloco de código.
func HighlightCode(lang, line string, fallback tcell.Style) []Segment {
	raw := highlightCodeRaw(lang, line)
	if raw == nil {
		return []Segment{{Text: line, Style: fallback}}
	}
	// o fundo do fallback (ex: a caixa do bloco de código no preview) é
	// aplicado em todos os tokens, senão cada palavra colorida "furava"
	// a caixa com o fundo padrão do terminal. O cache guarda os tokens
	// "crus" — o mesmo trecho aparece com e sem caixa (edição/preview).
	_, bg, _ := fallback.Decompose()
	out := make([]Segment, len(raw))
	for i, sg := range raw {
		st := sg.Style
		if st == base {
			st = fallback
		} else if bg != tcell.ColorDefault {
			st = st.Background(bg)
		}
		out[i] = Segment{Text: sg.Text, Style: st}
	}
	return out
}

func highlightCodeRaw(lang, line string) []Segment {
	lx := codeLexer(lang)
	if lx == nil {
		return nil
	}
	key := "\x01code\x00" + strings.ToLower(lang) + "\x00" + line
	resultCacheMu.Lock()
	if segs, ok := resultCache[key]; ok {
		resultCacheMu.Unlock()
		return segs
	}
	resultCacheMu.Unlock()

	isBash := lx.Config().Name == "Bash"
	iter, err := lx.Tokenise(nil, line)
	if err != nil {
		return nil
	}
	var segs []Segment
	for _, tok := range iter.Tokens() {
		txt := strings.TrimSuffix(tok.Value, "\n")
		if txt == "" {
			continue
		}
		segs = append(segs, Segment{Text: txt, Style: styleFor(tok.Type, txt, isBash)})
	}
	if len(segs) == 0 {
		segs = []Segment{{Text: line, Style: base}}
	}
	resultCacheMu.Lock()
	if len(resultCache) > 5000 {
		resultCache = map[string][]Segment{}
	}
	resultCache[key] = segs
	resultCacheMu.Unlock()
	return segs
}
