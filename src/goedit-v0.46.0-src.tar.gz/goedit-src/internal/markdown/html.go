/*
   goedit
   Editor de texto para terminal (TUI), com realce de sintaxe, plugins Lua, seleção em bloco e mais
   Site:      https://chililinux.com
   Site:      https://voidbr.org
   Site:      https://voidlinux.com.br
   GitHub:    https://github.com/voidlinuxbr/voidbr-goedit
   Created:   ter 20 out 2026 21:35:02 -04
   Updated:   ter 20 out 2026 21:36:03 -04
   Version:   0.46.0
   Copyright (C) 2019-2026 Vilmar Catafesta <vcatafesta@gmail.com>
*/

package markdown

import (
	"net/url"
	"path"
	"regexp"
	"strconv"
	"strings"

	"github.com/gdamore/tcell/v2"
)

// HTML embutido no Markdown (comum em README do GitHub): o preview
// interpreta as tags mais usadas em vez de mostrar elas cruas — igual
// o GitHub, tag desconhecida simplesmente some.

const nbsp = ' ' // espaço que não quebra linha (mantém o badge inteiro)

var (
	reTag     = regexp.MustCompile(`<!--.*?-->|</?[A-Za-z][A-Za-z0-9]*(?:\s[^<>]*)?/?>`)
	reAttr    = regexp.MustCompile(`([A-Za-z_:][-A-Za-z0-9_:.]*)\s*=\s*("[^"]*"|'[^']*'|[^\s"'>]+)`)
	reHTMLHdr = regexp.MustCompile(`(?is)^\s*<h([1-6])\b([^>]*)>(.*?)</h[1-6]>\s*$`)
)

type htmlTag struct {
	name    string
	closing bool
	attrs   map[string]string
}

func parseTag(raw string) (htmlTag, bool) {
	if strings.HasPrefix(raw, "<!--") || len(raw) < 3 {
		return htmlTag{}, false
	}
	t := strings.TrimSuffix(strings.TrimSuffix(strings.TrimPrefix(raw, "<"), ">"), "/")
	tag := htmlTag{attrs: map[string]string{}}
	if strings.HasPrefix(t, "/") {
		tag.closing = true
		t = t[1:]
	}
	end := strings.IndexAny(t, " \t\n")
	if end < 0 {
		end = len(t)
	}
	tag.name = strings.ToLower(t[:end])
	for _, m := range reAttr.FindAllStringSubmatch(t[end:], -1) {
		v := m[2]
		if len(v) >= 2 && (v[0] == '"' || v[0] == '\'') {
			v = v[1 : len(v)-1]
		}
		tag.attrs[strings.ToLower(m[1])] = v
	}
	return tag, tag.name != ""
}

// isTagOnly: linha só com tags/comentários (ex: `<div align="center">`,
// `</details>`) — não vira texto no preview, só muda o estado
// (centralizar, etc). <img> conta como conteúdo.
func isTagOnly(line string) bool {
	t := strings.TrimSpace(line)
	if t == "" || t[0] != '<' {
		return false
	}
	found := false
	rest := reTag.ReplaceAllStringFunc(t, func(m string) string {
		found = true
		if tg, ok := parseTag(m); ok && tg.name == "img" && !tg.closing {
			return "x"
		}
		return ""
	})
	return found && strings.TrimSpace(rest) == ""
}

// alignTracker acompanha os blocos HTML abertos (div, p, center...) pra
// saber se o conteúdo atual está centralizado.
type alignTracker struct{ stack []bool }

func isAlignBlock(name string) bool {
	switch name {
	case "div", "p", "center", "h1", "h2", "h3", "h4", "h5", "h6", "section", "header", "footer", "picture":
		return true
	}
	return false
}

func (a *alignTracker) centered() bool {
	for _, c := range a.stack {
		if c {
			return true
		}
	}
	return false
}

// apply processa as tags de uma linha; devolve true se alguma delas
// abriu um bloco centralizado.
func (a *alignTracker) apply(line string) (opensCenter bool) {
	for _, m := range reTag.FindAllString(line, -1) {
		tg, ok := parseTag(m)
		if !ok || !isAlignBlock(tg.name) || strings.HasSuffix(m, "/>") {
			continue
		}
		if tg.closing {
			if len(a.stack) > 0 {
				a.stack = a.stack[:len(a.stack)-1]
			}
			continue
		}
		c := tg.name == "center" || strings.EqualFold(tg.attrs["align"], "center")
		a.stack = append(a.stack, c)
		if c {
			opensCenter = true
		}
	}
	return opensCenter
}

// --- badges (shields.io) e imagens ---

var shieldsColors = map[string]int32{
	"brightgreen": 0x44cc11, "green": 0x97ca00, "yellowgreen": 0xa4a61d, "yellow": 0xdfb317,
	"orange": 0xfe7d37, "red": 0xe05d44, "blue": 0x007ec6, "lightgrey": 0x9f9f9f,
	"lightgray": 0x9f9f9f, "grey": 0x555555, "gray": 0x555555, "success": 0x44cc11,
	"important": 0xfe7d37, "critical": 0xe05d44, "informational": 0x007ec6, "inactive": 0x9f9f9f,
	"blueviolet": 0x8a2be2, "ff69b4": 0xff69b4,
}

func shieldsDecode(s string) string {
	if u, err := url.PathUnescape(s); err == nil {
		s = u
	}
	s = strings.ReplaceAll(s, "__", "\x01")
	s = strings.ReplaceAll(s, "_", " ")
	return strings.ReplaceAll(s, "\x01", "_")
}

// parseShields extrai rótulo, mensagem e cor de um badge estático
// (https://img.shields.io/badge/<rótulo>-<mensagem>-<cor>).
func parseShields(src string) (label, msg string, color tcell.Color, ok bool) {
	i := strings.Index(src, "img.shields.io/badge/")
	if i < 0 {
		return "", "", 0, false
	}
	p := src[i+len("img.shields.io/badge/"):]
	if q := strings.IndexAny(p, "?#"); q >= 0 {
		p = p[:q]
	}
	p = strings.TrimSuffix(strings.TrimSuffix(p, ".svg"), ".png")
	p = strings.ReplaceAll(p, "--", "\x02")
	parts := strings.Split(p, "-")
	for k := range parts {
		parts[k] = strings.ReplaceAll(parts[k], "\x02", "-")
	}
	var col string
	switch len(parts) {
	case 2:
		msg, col = parts[0], parts[1]
	case 3:
		label, msg, col = parts[0], parts[1], parts[2]
	default:
		return "", "", 0, false
	}
	label, msg = shieldsDecode(label), shieldsDecode(msg)
	col = strings.ToLower(strings.TrimPrefix(col, "#"))
	if v, ok := shieldsColors[col]; ok {
		color = tcell.NewHexColor(v)
	} else if len(col) == 3 || len(col) == 6 {
		if len(col) == 3 {
			col = string([]byte{col[0], col[0], col[1], col[1], col[2], col[2]})
		}
		v, err := strconv.ParseInt(col, 16, 32)
		if err != nil {
			color = tcell.NewHexColor(0x9f9f9f)
		} else {
			color = tcell.NewHexColor(int32(v))
		}
	} else {
		color = tcell.NewHexColor(0x9f9f9f)
	}
	return label, msg, color, true
}

func textOn(bg tcell.Color) tcell.Color {
	r, g, b := bg.RGB()
	if (299*r+587*g+114*b)/1000 > 150 {
		return tcell.NewHexColor(0x1a1b26)
	}
	return tcell.NewHexColor(0xffffff)
}

func pill(text string, bg tcell.Color, src int) []cell {
	st := tcell.StyleDefault.Background(bg).Foreground(textOn(bg))
	var cs []cell
	cs = append(cs, cell{nbsp, st, src})
	for _, r := range text {
		if r == ' ' {
			r = nbsp
		}
		cs = append(cs, cell{r, st, src})
	}
	return append(cs, cell{nbsp, st, src})
}

// imageCells: badge do shields.io vira pílula colorida (rótulo cinza +
// mensagem na cor do badge); outro badge do shields (dinâmico, sem o
// texto na URL) vira pílula cinza com o alt; imagem comum vira
// "[imagem: alt]".
func imageCells(alt, src string, b tcell.Style, line int) []cell {
	if label, msg, color, ok := parseShields(src); ok {
		var cs []cell
		if label != "" {
			cs = append(cs, pill(label, tcell.NewHexColor(0x555555), line)...)
		}
		return append(cs, pill(msg, color, line)...)
	}
	if strings.Contains(src, "shields.io") || strings.Contains(src, "badge") {
		if alt == "" {
			alt = "badge"
		}
		return pill(alt, tcell.NewHexColor(0x555555), line)
	}
	if alt == "" {
		alt = path.Base(src)
	}
	st := previewStyle(fImage, b)
	var cs []cell
	for _, r := range "[imagem: " + alt + "]" {
		cs = append(cs, cell{r, st, line})
	}
	return cs
}

// htmlState guarda as tags inline abertas (<b>, <i>, <kbd>...) enquanto
// formata uma linha/parágrafo.
type htmlState struct {
	depth map[string]int
}

func (h *htmlState) flags() (f flag, underline, mark bool) {
	d := h.depth
	if d["b"]+d["strong"]+d["summary"]+d["h1"]+d["h2"]+d["h3"]+d["h4"]+d["h5"]+d["h6"]+d["th"] > 0 {
		f |= fBold
	}
	if d["i"]+d["em"]+d["cite"]+d["var"] > 0 {
		f |= fItalic
	}
	if d["s"]+d["del"]+d["strike"] > 0 {
		f |= fStrike
	}
	if d["code"]+d["kbd"]+d["tt"]+d["samp"] > 0 {
		f |= fCode
	}
	if d["a"] > 0 {
		f |= fLink
	}
	return f, d["u"]+d["ins"] > 0, d["mark"] > 0
}

func (h *htmlState) style(f flag, b tcell.Style) tcell.Style {
	hf, u, m := h.flags()
	st := previewStyle(f|hf, b)
	if u {
		st = st.Underline(true)
	}
	if m {
		st = st.Background(tcell.NewHexColor(0xe0af68)).Foreground(tcell.NewHexColor(0x1a1b26))
	}
	return st
}

// tag aplica uma tag inline; devolve as células que ela gera (<br>,
// <img>, o "▸" do <summary>...) — a maioria não gera nada visível.
func (h *htmlState) tag(raw string, b tcell.Style, line int) []cell {
	if h.depth == nil {
		h.depth = map[string]int{}
	}
	tg, ok := parseTag(raw)
	if !ok {
		return nil // comentário
	}
	selfClose := strings.HasSuffix(raw, "/>")
	switch tg.name {
	case "br":
		return []cell{{'\n', b, line}}
	case "img":
		if tg.closing {
			return nil
		}
		return imageCells(tg.attrs["alt"], tg.attrs["src"], b, line)
	case "hr":
		return []cell{{'\n', b, line}}
	}
	if tg.closing {
		if h.depth[tg.name] > 0 {
			h.depth[tg.name]--
		}
		return nil
	}
	if selfClose {
		return nil
	}
	h.depth[tg.name]++
	if tg.name == "summary" {
		return []cell{{'▸', h.style(0, b), line}, {' ', b, line}}
	}
	return nil
}
