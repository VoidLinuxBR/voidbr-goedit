package ui

// Este arquivo implementa plugin.EditorAPI, a interface que os scripts Lua
// enxergam através da tabela global `goedit` (ver internal/plugin).

func (a *App) GetLine(y int) string {
	b := a.ActiveBuffer()
	if y < 0 || y >= len(b.Lines) {
		return ""
	}
	return b.Lines[y]
}

func (a *App) SetLine(y int, text string) {
	b := a.ActiveBuffer()
	if y < 0 || y >= len(b.Lines) {
		return
	}
	b.Lines[y] = text
	b.Dirty = true
}

func (a *App) LineCount() int {
	return len(a.ActiveBuffer().Lines)
}

func (a *App) GetCursor() (int, int) {
	b := a.ActiveBuffer()
	return b.CursorX, b.CursorY
}

func (a *App) SetCursor(x, y int) {
	b := a.ActiveBuffer()
	b.CursorY = y
	b.CursorX = x
}

func (a *App) InsertText(text string) {
	b := a.ActiveBuffer()
	for _, r := range text {
		if r == '\n' {
			b.InsertNewline()
			continue
		}
		b.InsertRune(r)
	}
}

func (a *App) CurrentFileName() string {
	return a.ActiveBuffer().Path
}

func (a *App) Notify(msg string) {
	a.StatusMsg = msg
}
