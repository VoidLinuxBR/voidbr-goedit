-- Plugin de exemplo pro goedit.
-- Copie este arquivo pra ~/.config/goedit/plugins/ pra ativá-lo.
-- Rode com Ctrl+P e digite o nome do comando.

goedit.register_command("ola", function()
    goedit.notify("Ola! Isso veio de um plugin Lua.")
end)

goedit.register_command("maiusculas", function()
    local x, y = goedit.get_cursor()
    local linha = goedit.get_line(y)
    goedit.set_line(y, string.upper(linha))
    goedit.notify("Linha " .. (y + 1) .. " convertida pra maiúsculas")
end)

goedit.register_command("data", function()
    goedit.insert_text(os.date("%Y-%m-%d"))
end)
