package ui

import (
	"github.com/gdamore/tcell/v2"
)

// mouseDragging indica se o botão esquerdo está sendo segurado desde um
// clique anterior no texto — usado pra saber se um movimento de mouse com
// botão pressionado deve estender a seleção.
var mouseDragging bool

// HandleMouse processa clique, arrasto e roda do mouse.
func (a *App) HandleMouse(ev *tcell.EventMouse) {
	if a.PromptActive {
		return // prompts não reagem a mouse por enquanto
	}

	x, y := ev.Position()
	btn := ev.Buttons()

	switch {
	case btn&tcell.WheelUp != 0:
		a.scrollAt(x, y, -3)
		return
	case btn&tcell.WheelDown != 0:
		a.scrollAt(x, y, 3)
		return
	}

	// Clique na sidebar.
	if a.Layout.SidebarVisible && x >= a.Layout.SidebarX0 && x < a.Layout.SidebarX1 &&
		y >= a.Layout.SidebarY0 && y < a.Layout.SidebarY1 {
		if btn&tcell.Button1 != 0 {
			a.clickSidebar(y)
		}
		return
	}

	// Clique em algum painel (aba ou texto).
	for i, pl := range a.Layout.Panes {
		if x < pl.X || x >= pl.X+pl.Width {
			continue
		}
		if btn&tcell.Button1 == 0 {
			// botão solto: encerra o arrasto de seleção, se houver
			if mouseDragging {
				mouseDragging = false
			}
			return
		}

		a.ActivePane = i
		a.SidebarFocused = false

		if y == pl.TabY {
			a.clickTabAt(pl, x)
			mouseDragging = false
			return
		}
		if y >= pl.TextTop && y < pl.TextTop+pl.TextHeight {
			a.clickText(pl, x, y, ev.Modifiers()&tcell.ModShift != 0)
			return
		}
	}
}

func (a *App) clickSidebar(y int) {
	idx := y - a.Layout.SidebarRowY0
	if idx < 0 || idx >= len(a.SidebarEntries) {
		return
	}
	a.SidebarSel = idx
	a.SidebarFocused = true
	e := a.SidebarEntries[idx]
	if e.IsDir() {
		full := a.SidebarPath + "/" + e.Name()
		a.SidebarPath = full
		a.SidebarSel = 0
		a.reloadSidebar()
	} else {
		a.OpenFile(a.SidebarPath + "/" + e.Name())
		a.SidebarFocused = false
	}
}

func (a *App) clickTabAt(pl PaneLayout, x int) {
	for _, tr := range pl.TabRanges {
		if x >= tr.X0 && x < tr.X1 {
			a.Panes[a.ActivePane] = tr.BufIdx
			return
		}
	}
}

func (a *App) clickText(pl PaneLayout, x, y int, extendSelection bool) {
	b := a.Buffers[pl.BufIdx]

	row := y - pl.TextTop
	lineIdx := b.OffsetY + row
	if lineIdx >= len(b.Lines) {
		lineIdx = len(b.Lines) - 1
	}
	if lineIdx < 0 {
		lineIdx = 0
	}

	tabWidth := a.Settings.TabWidth
	if tabWidth <= 0 {
		tabWidth = 4
	}
	targetVCol := b.OffsetX + (x - pl.TextX)
	if targetVCol < 0 {
		targetVCol = 0
	}
	col := byteIndexForVisualCol(b.Lines[lineIdx], targetVCol, tabWidth)

	if extendSelection || mouseDragging {
		if !b.Selecting {
			// se for o início de um arrasto nunca marcado, ancora na
			// posição atual do cursor antes de mover
			b.StartSelection()
		}
	} else {
		b.ClearSelection()
	}
	b.CursorY = lineIdx
	b.CursorX = col
	mouseDragging = true
}

// scrollAt rola o painel sob o cursor do mouse, movendo o cursor de texto
// junto (o auto-scroll da renderização segue a posição do cursor, então
// não dá pra rolar a viewport sem mover o cursor também neste editor).
func (a *App) scrollAt(x, y, delta int) {
	for i, pl := range a.Layout.Panes {
		if x < pl.X || x >= pl.X+pl.Width {
			continue
		}
		if y < pl.TextTop || y >= pl.TextTop+pl.TextHeight {
			continue
		}
		b := a.Buffers[pl.BufIdx]
		b.ClearSelection()
		steps := delta
		if steps < 0 {
			steps = -steps
		}
		dir := 1
		if delta < 0 {
			dir = -1
		}
		for s := 0; s < steps; s++ {
			b.MoveCursor(0, dir)
		}
		a.ActivePane = i
		return
	}
}
