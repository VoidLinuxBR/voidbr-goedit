module goedit

go 1.22.2

replace golang.org/x/sys => github.com/golang/sys v0.17.0

replace golang.org/x/term => github.com/golang/term v0.17.0

replace golang.org/x/text => github.com/golang/text v0.14.0

replace golang.org/x/tools => github.com/golang/tools v0.6.0

replace golang.org/x/mod => github.com/golang/mod v0.8.0

replace golang.org/x/sync => github.com/golang/sync v0.6.0

replace golang.org/x/xerrors => github.com/golang/xerrors v0.0.0-20231012003039-104605ab7028

replace golang.org/x/net => github.com/golang/net v0.6.0

require (
	github.com/alecthomas/chroma/v2 v2.13.0
	github.com/gdamore/tcell/v2 v2.7.4
	github.com/mattn/go-runewidth v0.0.15
	github.com/yuin/gopher-lua v1.1.1
)

require (
	github.com/dlclark/regexp2 v1.11.0 // indirect
	github.com/gdamore/encoding v1.0.0 // indirect
	github.com/lucasb-eyer/go-colorful v1.2.0 // indirect
	github.com/rivo/uniseg v0.4.3 // indirect
	golang.org/x/sys v0.17.0 // indirect
	golang.org/x/term v0.17.0 // indirect
	golang.org/x/text v0.14.0 // indirect
)
