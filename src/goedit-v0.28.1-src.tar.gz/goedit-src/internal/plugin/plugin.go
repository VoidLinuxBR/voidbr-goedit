/*
   goedit
   Editor de texto para terminal (TUI), com realce de sintaxe, plugins Lua, seleção em bloco e mais
   Site:      https://chililinux.com
   Site:      https://voidbr.org
   Site:      https://voidlinux.com.br
   GitHub:    https://github.com/voidlinuxbr/voidbr-goedit
   Created:   dom 16 ago 2026 10:15:33 -04
   Updated:   sex 21 ago 2026 11:30:00 -04
   Version:   0.28.1
   Copyright (C) 2019-2026 Vilmar Catafesta <vcatafesta@gmail.com>
*/

package plugin

import (
	"os"
	"path/filepath"
	"sort"

	lua "github.com/yuin/gopher-lua"
)

// EditorAPI é o conjunto de operações que os plugins Lua podem chamar.
// A UI implementa essa interface, evitando que o pacote plugin dependa da UI.
type EditorAPI interface {
	GetLine(y int) string
	SetLine(y int, text string)
	LineCount() int
	GetCursor() (x, y int)
	SetCursor(x, y int)
	InsertText(text string)
	CurrentFileName() string
	Notify(msg string)
}

// Command é uma ação registrada por um plugin, invocável pela paleta de comandos.
type Command struct {
	Name string
	Fn   *lua.LFunction
}

// Manager carrega e executa plugins Lua.
type Manager struct {
	L        *lua.LState
	api      EditorAPI
	Commands map[string]Command
	dir      string
}

// NewManager cria o gerenciador de plugins e prepara o estado Lua com a API do editor.
func NewManager(api EditorAPI, dir string) *Manager {
	m := &Manager{
		L:        lua.NewState(),
		api:      api,
		Commands: map[string]Command{},
		dir:      dir,
	}
	m.exposeAPI()
	return m
}

func (m *Manager) exposeAPI() {
	editor := m.L.NewTable()

	m.L.SetField(editor, "get_line", m.L.NewFunction(func(L *lua.LState) int {
		y := L.CheckInt(1)
		L.Push(lua.LString(m.api.GetLine(y)))
		return 1
	}))

	m.L.SetField(editor, "set_line", m.L.NewFunction(func(L *lua.LState) int {
		y := L.CheckInt(1)
		text := L.CheckString(2)
		m.api.SetLine(y, text)
		return 0
	}))

	m.L.SetField(editor, "line_count", m.L.NewFunction(func(L *lua.LState) int {
		L.Push(lua.LNumber(m.api.LineCount()))
		return 1
	}))

	m.L.SetField(editor, "get_cursor", m.L.NewFunction(func(L *lua.LState) int {
		x, y := m.api.GetCursor()
		L.Push(lua.LNumber(x))
		L.Push(lua.LNumber(y))
		return 2
	}))

	m.L.SetField(editor, "set_cursor", m.L.NewFunction(func(L *lua.LState) int {
		x := L.CheckInt(1)
		y := L.CheckInt(2)
		m.api.SetCursor(x, y)
		return 0
	}))

	m.L.SetField(editor, "insert_text", m.L.NewFunction(func(L *lua.LState) int {
		m.api.InsertText(L.CheckString(1))
		return 0
	}))

	m.L.SetField(editor, "filename", m.L.NewFunction(func(L *lua.LState) int {
		L.Push(lua.LString(m.api.CurrentFileName()))
		return 1
	}))

	m.L.SetField(editor, "notify", m.L.NewFunction(func(L *lua.LState) int {
		m.api.Notify(L.CheckString(1))
		return 0
	}))

	m.L.SetField(editor, "register_command", m.L.NewFunction(func(L *lua.LState) int {
		name := L.CheckString(1)
		fn := L.CheckFunction(2)
		m.Commands[name] = Command{Name: name, Fn: fn}
		return 0
	}))

	m.L.SetGlobal("goedit", editor)
}

// LoadAll carrega todos os arquivos .lua do diretório de plugins.
// Não é um erro o diretório não existir (só significa "sem plugins ainda").
func (m *Manager) LoadAll() []error {
	var errs []error
	entries, err := os.ReadDir(m.dir)
	if err != nil {
		return nil
	}
	for _, e := range entries {
		if e.IsDir() || filepath.Ext(e.Name()) != ".lua" {
			continue
		}
		full := filepath.Join(m.dir, e.Name())
		if err := m.L.DoFile(full); err != nil {
			errs = append(errs, err)
		}
	}
	return errs
}

// Run executa um comando registrado pelo nome.
func (m *Manager) Run(name string) error {
	cmd, ok := m.Commands[name]
	if !ok {
		return nil
	}
	return m.L.CallByParam(lua.P{
		Fn:      cmd.Fn,
		NRet:    0,
		Protect: true,
	})
}

// SortedCommandNames devolve os nomes dos comandos registrados, em ordem alfabética.
func (m *Manager) SortedCommandNames() []string {
	names := make([]string, 0, len(m.Commands))
	for n := range m.Commands {
		names = append(names, n)
	}
	sort.Strings(names)
	return names
}

// Close libera o estado Lua.
func (m *Manager) Close() {
	m.L.Close()
}
