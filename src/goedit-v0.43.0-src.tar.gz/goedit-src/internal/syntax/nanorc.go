/*
   goedit
   Parser de arquivos .nanorc customizados — permite usar o mesmo
   esquema de cores de sintaxe de um .nanorc real do nano, com F6
   alternando entre esse esquema e o realce padrão (chroma) sem
   precisar reabrir o arquivo.
*/

package syntax

import (
	"bufio"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"

	"github.com/gdamore/tcell/v2"
)

// NanorcColorRule é uma regra "color <nome> "<regex>" [...]" já compilada.
type NanorcColorRule struct {
	Regex *regexp.Regexp
	Style tcell.Style
}

// NanorcSyntax é um bloco "syntax <nome> "<padrão de arquivo>"" de um
// .nanorc, com os padrões de detecção (nome de arquivo, shebang/header,
// conteúdo/magic) e as regras de cor associadas a ele.
type NanorcSyntax struct {
	Name           string
	FilePatterns   []*regexp.Regexp
	HeaderPatterns []*regexp.Regexp
	Colors         []NanorcColorRule
}

// --- Conversão de regex estilo GNU/nanorc pra sintaxe RE2 (Go) ---

// convertNanoRegex converte \< \> (limite de palavra estilo GNU) pra \b
// (Go), e corrige barra invertida literal logo antes do ] de fechamento
// dentro de uma classe de caracteres — o nano/POSIX trata \ como
// caractere comum dentro de [...], mas o RE2 do Go sempre trata \ como
// início de escape, então "[^"\]" (barra invertida literal + fecha)
// precisa virar "[^"\\]" (barra invertida escapada + fecha) pro Go
// entender do jeito certo.
func convertNanoRegex(pat string) string {
	var sb strings.Builder
	inBracket := false
	runes := []rune(pat)
	for i := 0; i < len(runes); i++ {
		c := runes[i]
		if inBracket {
			if c == '\\' && i+1 < len(runes) && runes[i+1] == ']' {
				sb.WriteString(`\\`)
				continue
			}
			if c == ']' {
				inBracket = false
			}
			sb.WriteRune(c)
			continue
		}
		if c == '[' {
			inBracket = true
			sb.WriteRune(c)
			continue
		}
		if c == '\\' && i+1 < len(runes) && (runes[i+1] == '<' || runes[i+1] == '>') {
			sb.WriteString(`\b`)
			i++
			continue
		}
		sb.WriteRune(c)
	}
	return sb.String()
}

// --- Paleta de cores nomeadas do nano (rcfile.c, nano 7.x) ---

// hueBasic8 são os 8 nomes básicos (+ "normal"), como índice de paleta
// ANSI padrão (0-7); com prefixo bright/light vira +8 (variante clara).
var hueBasic8 = map[string]int{
	"black": 0, "red": 1, "green": 2, "yellow": 3,
	"blue": 4, "magenta": 5, "cyan": 6, "white": 7,
}

// hueExtended256 replica os 25 nomes de cor estendidos do nano 7.x,
// mapeados pro MESMO índice de paleta 256 cores exato que o nano usa —
// pra bater visualmente com o nano de verdade quando disponível.
var hueExtended256 = map[string]int{
	"pink": 204, "purple": 163, "mauve": 134, "lagoon": 38, "mint": 48,
	"lime": 148, "peach": 215, "orange": 208, "latte": 137, "rosy": 175,
	"beet": 127, "plum": 98, "sea": 32, "sky": 111, "slate": 66,
	"teal": 35, "sage": 107, "brown": 100, "ocher": 142, "sand": 186,
	"tawny": 136, "brick": 166, "crimson": 161, "grey": 8, "gray": 8,
}

// parseHue devolve a tcell.Color de um único nome de cor (sem vírgula),
// entendendo os prefixos bright/light, os nomes de cor do nano (básicos
// e estendidos), "normal" (cor padrão) e #rgb (hex de 3 dígitos).
func parseHue(name string) (tcell.Color, bool, error) {
	vivid := false
	if strings.HasPrefix(name, "bright") && len(name) > 6 {
		vivid = true
		name = name[6:]
	} else if strings.HasPrefix(name, "light") && len(name) > 5 {
		vivid = true
		name = name[5:]
	}

	if strings.HasPrefix(name, "#") && len(name) == 4 {
		r := name[1:2]
		g := name[2:3]
		b := name[3:4]
		hex := "#" + r + r + g + g + b + b
		return tcell.GetColor(hex), false, nil
	}

	if name == "normal" {
		return tcell.ColorDefault, false, nil
	}
	if idx, ok := hueBasic8[name]; ok {
		if vivid {
			idx += 8
		}
		return tcell.PaletteColor(idx), false, nil
	}
	if idx, ok := hueExtended256[name]; ok {
		return tcell.PaletteColor(idx), false, nil
	}
	return tcell.ColorDefault, false, fmt.Errorf("cor desconhecida: %q", name)
}

// parseColorCombo entende "cor" ou "corfg,corbg" (fundo opcional depois
// da vírgula), e os prefixos "bold," / "italic," antes da(s) cor(es).
func parseColorCombo(combo string) (tcell.Style, error) {
	style := tcell.StyleDefault
	if strings.HasPrefix(combo, "bold,") {
		style = style.Bold(true)
		combo = combo[5:]
	}
	if strings.HasPrefix(combo, "italic,") {
		style = style.Italic(true)
		combo = combo[7:]
	}
	parts := strings.SplitN(combo, ",", 2)
	fgName := strings.TrimSpace(parts[0])
	if fgName != "" {
		fg, _, err := parseHue(fgName)
		if err != nil {
			return style, err
		}
		style = style.Foreground(fg)
	}
	if len(parts) == 2 && strings.TrimSpace(parts[1]) != "" {
		bg, _, err := parseHue(strings.TrimSpace(parts[1]))
		if err != nil {
			return style, err
		}
		style = style.Background(bg)
	}
	return style, nil
}

// --- Parsing de linha (aspas com a regra exata do nano) ---

// parseNextQuoted extrai a próxima string entre aspas de s (que deve
// começar em '"'), seguindo a regra exata do parse_next_regex do nano:
// a string vai até uma '"' seguida de fim-de-linha ou espaço/tab — uma
// '"' seguida de outra coisa é conteúdo literal da regex, não fecha.
func parseNextQuoted(s string) (value, rest string, ok bool) {
	if len(s) == 0 || s[0] != '"' {
		return "", s, false
	}
	i := 1
	for i < len(s) {
		if s[i] == '"' && (i+1 >= len(s) || s[i+1] == ' ' || s[i+1] == '\t') {
			break
		}
		i++
	}
	if i >= len(s) {
		return "", s, false
	}
	value = s[1:i]
	rest = strings.TrimLeft(s[i+1:], " \t")
	return value, rest, true
}

// ParseNanorc lê um arquivo .nanorc customizado e devolve os blocos de
// sintaxe encontrados (um por diretiva "syntax"), cada um já com as
// regex de cor compiladas. Ignora diretivas que não afetam realce de
// cor (linter, tabgives, formatter, etc.) — essas não fazem sentido
// fora do nano de verdade.
func ParseNanorc(path string) ([]*NanorcSyntax, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()

	var syntaxes []*NanorcSyntax
	var current *NanorcSyntax

	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 64*1024), 1024*1024)
	lineNo := 0
	var parseErrs []string

	for sc.Scan() {
		lineNo++
		raw := sc.Text()
		line := strings.TrimSpace(raw)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}

		fields := strings.SplitN(line, " ", 2)
		directive := fields[0]
		rest := ""
		if len(fields) == 2 {
			rest = strings.TrimSpace(fields[1])
		}

		switch directive {
		case "syntax":
			nameFields := strings.SplitN(rest, " ", 2)
			name := nameFields[0]
			current = &NanorcSyntax{Name: name}
			syntaxes = append(syntaxes, current)
			if len(nameFields) == 2 {
				remainder := strings.TrimSpace(nameFields[1])
				for {
					val, novoResto, ok := parseNextQuoted(remainder)
					if !ok {
						break
					}
					re, err := regexp.Compile(convertNanoRegex(val))
					if err == nil {
						current.FilePatterns = append(current.FilePatterns, re)
					} else {
						parseErrs = append(parseErrs, fmt.Sprintf("linha %d: padrão de arquivo inválido %q: %v", lineNo, val, err))
					}
					remainder = novoResto
					if remainder == "" {
						break
					}
				}
			}
		case "header", "magic":
			if current == nil {
				continue
			}
			val, _, ok := parseNextQuoted(rest)
			if !ok {
				continue
			}
			re, err := regexp.Compile(convertNanoRegex(val))
			if err == nil {
				current.HeaderPatterns = append(current.HeaderPatterns, re)
			} else {
				parseErrs = append(parseErrs, fmt.Sprintf("linha %d: header/magic inválido %q: %v", lineNo, val, err))
			}
		case "color", "icolor":
			if current == nil {
				continue
			}
			comboFields := strings.SplitN(rest, " ", 2)
			if len(comboFields) < 1 {
				continue
			}
			style, err := parseColorCombo(comboFields[0])
			if err != nil {
				parseErrs = append(parseErrs, fmt.Sprintf("linha %d: %v", lineNo, err))
				continue
			}
			if directive == "icolor" {
				// case-insensitive: aplicado direto na regex convertida
			}
			if len(comboFields) < 2 {
				continue
			}
			remainder := strings.TrimSpace(comboFields[1])
			// "start=... end=..." (regiões multi-linha) não são
			// suportadas por esse realce baseado em regex por linha —
			// pula, documentado como limitação conhecida.
			if strings.HasPrefix(remainder, "start=") {
				parseErrs = append(parseErrs, fmt.Sprintf("linha %d: região multi-linha (start=/end=) não suportada, ignorada", lineNo))
				continue
			}
			for {
				val, novoResto, ok := parseNextQuoted(remainder)
				if !ok {
					break
				}
				pattern := convertNanoRegex(val)
				if directive == "icolor" {
					pattern = "(?i)" + pattern
				}
				re, err := regexp.Compile(pattern)
				if err != nil {
					parseErrs = append(parseErrs, fmt.Sprintf("linha %d: regex de cor inválida %q: %v", lineNo, val, err))
				} else {
					current.Colors = append(current.Colors, NanorcColorRule{Regex: re, Style: style})
				}
				remainder = novoResto
				if remainder == "" {
					break
				}
			}
		default:
			// comment, linter, tabgives, formatter, spell, etc. —
			// não afetam realce de cor, ignorados de propósito.
		}
	}
	if err := sc.Err(); err != nil {
		return syntaxes, err
	}
	if len(parseErrs) > 0 {
		return syntaxes, fmt.Errorf("%d aviso(s) ao interpretar %s:\n%s", len(parseErrs), path, strings.Join(parseErrs, "\n"))
	}
	return syntaxes, nil
}

// ScanNanorcDir lê todos os arquivos *.nanorc de um diretório (sem
// entrar em subpastas — mesmo conjunto que o nano carrega por padrão
// numa instalação normal, ex: /usr/share/nano/) e junta os blocos de
// sintaxe de todos num só slice. Cada arquivo (sh.nanorc, c.nanorc,
// go.nanorc, ...) já sabe pra qual extensão/shebang ele serve, então
// MatchNanorcSyntax acha o certo sozinho pelo arquivo sendo editado.
// Erros de um arquivo individual não impedem os outros de carregar —
// ficam juntados no erro devolvido, como avisos.
func ScanNanorcDir(dir string) ([]*NanorcSyntax, error) {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return nil, err
	}
	var all []*NanorcSyntax
	var warnings []string
	for _, entry := range entries {
		if entry.IsDir() || !strings.HasSuffix(entry.Name(), ".nanorc") {
			continue
		}
		path := filepath.Join(dir, entry.Name())
		syns, err := ParseNanorc(path)
		all = append(all, syns...)
		if err != nil {
			warnings = append(warnings, err.Error())
		}
	}
	if len(warnings) > 0 {
		return all, fmt.Errorf("%d arquivo(s) com aviso em %s:\n%s", len(warnings), dir, strings.Join(warnings, "\n"))
	}
	return all, nil
}

// MatchNanorcSyntax acha o primeiro bloco de sintaxe cujo padrão de
// nome de arquivo ou de header/shebang bate com o arquivo dado — mesma
// lógica de prioridade do nano (nome do arquivo primeiro, shebang/magic
// como alternativa pra arquivo sem extensão reconhecida).
func MatchNanorcSyntax(syntaxes []*NanorcSyntax, filename, firstLine string) *NanorcSyntax {
	base := filename
	for _, syn := range syntaxes {
		for _, re := range syn.FilePatterns {
			if re.MatchString(base) {
				return syn
			}
		}
	}
	for _, syn := range syntaxes {
		for _, re := range syn.HeaderPatterns {
			if re.MatchString(firstLine) {
				return syn
			}
		}
	}
	return nil
}

// HighlightLineNanorc aplica as regras de cor de um NanorcSyntax numa
// linha de texto, devolvendo os segmentos coloridos. Ao contrário do
// realce por tokenização do chroma, aqui cada regra de cor é aplicada
// como uma sobreposição sobre o texto (igual o nano faz internamente:
// regras posteriores no arquivo pintam por cima de partes já pintadas
// por regras anteriores que se sobrepõem na mesma posição).
func HighlightLineNanorc(syn *NanorcSyntax, line string) []Segment {
	if line == "" {
		return []Segment{{Text: "", Style: base}}
	}
	styles := make([]tcell.Style, len(line))
	for i := range styles {
		styles[i] = base
	}
	for _, rule := range syn.Colors {
		matches := rule.Regex.FindAllStringIndex(line, -1)
		for _, m := range matches {
			for i := m[0]; i < m[1] && i < len(line); i++ {
				styles[i] = rule.Style
			}
		}
	}

	var segs []Segment
	start := 0
	for i := 1; i <= len(line); i++ {
		if i == len(line) || styles[i] != styles[start] {
			segs = append(segs, Segment{Text: line[start:i], Style: styles[start]})
			start = i
		}
	}
	if len(segs) == 0 {
		segs = []Segment{{Text: line, Style: base}}
	}
	return segs
}
