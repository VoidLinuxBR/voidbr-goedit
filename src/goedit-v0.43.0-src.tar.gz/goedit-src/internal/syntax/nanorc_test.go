package syntax

import "testing"

// TestParseNanorcShFile usa o sh.nanorc real (testdata/, mesmo enviado
// pelo usuário) como regressão — garante que o parser continua
// entendendo esse arquivo específico do jeito certo mesmo se a lógica
// de conversão de regex ou de cores mudar no futuro.
func TestParseNanorcShFile(t *testing.T) {
	syns, err := ParseNanorc("testdata/sh.nanorc")
	if err != nil {
		t.Fatalf("erro ao interpretar testdata/sh.nanorc: %v", err)
	}
	if len(syns) != 1 {
		t.Fatalf("esperava 1 bloco de sintaxe, achou %d", len(syns))
	}
	sh := syns[0]
	if sh.Name != "sh" {
		t.Errorf("nome do bloco = %q, esperava \"sh\"", sh.Name)
	}
	if len(sh.Colors) != 13 {
		t.Errorf("esperava 13 regras de cor, achou %d", len(sh.Colors))
	}
	if len(sh.HeaderPatterns) != 3 {
		t.Errorf("esperava 3 padrões de header/magic, achou %d", len(sh.HeaderPatterns))
	}
}

func TestMatchNanorcSyntaxByFilename(t *testing.T) {
	syns, err := ParseNanorc("testdata/sh.nanorc")
	if err != nil {
		t.Fatalf("erro ao interpretar: %v", err)
	}
	casos := []struct {
		nome         string
		deveriaBater bool
	}{
		{"deploy.sh", true},
		{".bashrc", true},
		{"script.py", false},
	}
	for _, c := range casos {
		match := MatchNanorcSyntax(syns, c.nome, "")
		bateu := match != nil
		if bateu != c.deveriaBater {
			t.Errorf("MatchNanorcSyntax(%q) bateu=%v, esperava %v", c.nome, bateu, c.deveriaBater)
		}
	}
}

func TestMatchNanorcSyntaxByShebang(t *testing.T) {
	syns, err := ParseNanorc("testdata/sh.nanorc")
	if err != nil {
		t.Fatalf("erro ao interpretar: %v", err)
	}
	match := MatchNanorcSyntax(syns, "meuscript", "#!/usr/bin/env bash")
	if match == nil {
		t.Error("esperava bater por shebang '#!/usr/bin/env bash' num arquivo sem extensão, não bateu")
	}
}

func TestHighlightLineNanorcKeywords(t *testing.T) {
	syns, err := ParseNanorc("testdata/sh.nanorc")
	if err != nil {
		t.Fatalf("erro ao interpretar: %v", err)
	}
	sh := syns[0]

	// "if" isolado deve virar UM segmento colorido; "modificar" não
	// deve ser tratado como contendo a palavra-chave "if".
	segs := HighlightLineNanorc(sh, `if verificar_modificar`)
	achouIfColorido := false
	for _, s := range segs {
		if s.Text == "if" && s.Style != base {
			achouIfColorido = true
		}
		if s.Text == "verificar_modificar" && s.Style != base {
			t.Error("'verificar_modificar' não deveria ser colorido como se contivesse a palavra-chave 'if'")
		}
	}
	if !achouIfColorido {
		t.Error("'if' isolado deveria estar destacado como palavra-chave, não achei o segmento")
	}
}

func TestHighlightLineNanorcNoMatch(t *testing.T) {
	// linha vazia não deve quebrar nada
	syns, _ := ParseNanorc("testdata/sh.nanorc")
	segs := HighlightLineNanorc(syns[0], "")
	if len(segs) != 1 || segs[0].Text != "" {
		t.Errorf("linha vazia deveria devolver 1 segmento vazio, devolveu %v", segs)
	}
}

// TestScanNanorcDirRealSystem usa o /usr/share/nano/ de verdade do
// sistema (se existir) pra confirmar que cada extensão bate com o
// arquivo de sintaxe certo — sh->sh, c->c, go->go, etc.
func TestScanNanorcDirRealSystem(t *testing.T) {
	syns, err := ScanNanorcDir("/usr/share/nano")
	if err != nil {
		t.Logf("aviso (não fatal): %v", err)
	}
	if len(syns) == 0 {
		t.Skip("/usr/share/nano não tem .nanorc neste sistema, pulando")
	}
	casos := []struct {
		arquivo      string
		nomeEsperado string
	}{
		{"deploy.sh", "sh"},
		{"main.c", "c"},
		{"main.go", "go"},
		{"app.py", "python"},
		{"index.js", "javascript"},
	}
	for _, c := range casos {
		match := MatchNanorcSyntax(syns, c.arquivo, "")
		if match == nil {
			t.Errorf("%s: nenhum bloco bateu (esperava %q)", c.arquivo, c.nomeEsperado)
			continue
		}
		if match.Name != c.nomeEsperado {
			t.Errorf("%s: bateu com bloco %q, esperava %q", c.arquivo, match.Name, c.nomeEsperado)
		}
	}
}
