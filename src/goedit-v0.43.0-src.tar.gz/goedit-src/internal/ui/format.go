/*
   goedit
   Editor de texto para terminal (TUI), com realce de sintaxe, plugins Lua, seleção em bloco e mais
   Site:      https://chililinux.com
   Site:      https://voidbr.org
   Site:      https://voidlinux.com.br
   GitHub:    https://github.com/voidlinuxbr/voidbr-goedit
   Created:   dom 16 ago 2026 10:15:33 -04
   Updated:   sex 21 ago 2026 11:30:00 -04
   Version:   0.43.0
   Copyright (C) 2019-2026 Vilmar Catafesta <vcatafesta@gmail.com>
*/

package ui

import (
	"bytes"
	"errors"
	"fmt"
	"os/exec"
	"path/filepath"
	"strings"
)

// formatterCmd é o comando (+ argumentos) usado pra formatar um tipo de
// arquivo — sempre lendo o código pela entrada padrão e devolvendo o
// resultado formatado pela saída padrão, sem tocar em arquivo nenhum no
// disco (o goedit é quem decide se salva ou não).
type formatterCmd struct {
	cmd  string
	args []string
}

// formattersByExt mapeia extensão de arquivo pro formatador externo
// correspondente. Fácil de estender: só adicionar uma linha nova.
var formattersByExt = map[string]formatterCmd{
	".go":   {cmd: "gofmt"},
	".sh":   {cmd: "shfmt"},
	".bash": {cmd: "shfmt"},
	".yml":  {cmd: "prettier", args: []string{"--stdin-filepath", "arquivo.yml"}},
	".yaml": {cmd: "prettier", args: []string{"--stdin-filepath", "arquivo.yaml"}},
}

// formattersByInterpreter mapeia o interpretador citado no shebang
// (#!/usr/bin/env python3, #!/bin/bash, etc) pro formatador — usado só
// quando o arquivo não tem extensão nenhuma pra decidir pela extensão.
var formattersByInterpreter = map[string]formatterCmd{
	"bash": {cmd: "shfmt"},
	"sh":   {cmd: "shfmt"},
	"dash": {cmd: "shfmt"},
	"ksh":  {cmd: "shfmt"},
	"zsh":  {cmd: "shfmt"},
}

// formatterFor devolve o formatador certo pro arquivo: primeiro pela
// extensão; se não tiver extensão, tenta pelo shebang da 1ª linha; se
// nem isso achar nada, usa shfmt como padrão universal (mesma lógica do
// syntax highlighting — é o caso mais comum de script sem extensão).
// Só devolve ok=false quando a extensão É conhecida mas não tem
// formatador configurado pra ela (aí não faz sentido nenhum fallback).
func formatterFor(path, firstLine string) (formatterCmd, bool) {
	ext := realExt(path)
	if ext != "" {
		fc, ok := formattersByExt[ext]
		return fc, ok
	}
	if interp := shebangInterpreter(firstLine); interp != "" {
		if fc, ok := formattersByInterpreter[interp]; ok {
			return fc, true
		}
	}
	return formatterCmd{cmd: "shfmt"}, true
}

// shebangInterpreter lê a primeira linha do arquivo e, se for um shebang
// (#!...), devolve o nome do interpretador citado (resolvendo o caso
// "#!/usr/bin/env python3" pro nome depois do "env").
func shebangInterpreter(firstLine string) string {
	firstLine = strings.TrimSpace(firstLine)
	if !strings.HasPrefix(firstLine, "#!") {
		return ""
	}
	rest := strings.TrimSpace(strings.TrimPrefix(firstLine, "#!"))
	fields := strings.Fields(rest)
	if len(fields) == 0 {
		return ""
	}
	interp := filepath.Base(fields[0])
	if interp == "env" && len(fields) > 1 {
		interp = filepath.Base(fields[1])
	}
	return interp
}

// FormatActiveBuffer roda o formatador externo correspondente à
// linguagem do arquivo ativo, substituindo o conteúdo pelo resultado
// formatado (como uma única alteração de undo) se tudo der certo.
func (a *App) FormatActiveBuffer() {
	b := a.ActiveBuffer()
	firstLine := ""
	if len(b.Lines) > 0 {
		firstLine = b.Lines[0]
	}
	fc, ok := formatterFor(b.Path, firstLine)
	if !ok {
		a.SetStatusMsg("sem formatador configurado pra esse tipo de arquivo")
		return
	}

	input := strings.Join(b.Lines, "\n") + "\n"
	cmd := exec.Command(fc.cmd, fc.args...)
	cmd.Stdin = strings.NewReader(input)
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr

	err := cmd.Run()
	if err != nil {
		var execErr *exec.Error
		if errors.As(err, &execErr) && errors.Is(execErr.Err, exec.ErrNotFound) {
			a.SetStatusMsg(fmt.Sprintf("%s não está instalado", fc.cmd))
			return
		}
		msg := strings.TrimSpace(stderr.String())
		if msg == "" {
			msg = err.Error()
		}
		a.SetStatusMsg(fmt.Sprintf("erro ao formatar (%s): %s", fc.cmd, firstLineOnly(msg)))
		return
	}

	out := stdout.String()
	out = strings.TrimSuffix(out, "\n")
	newLines := strings.Split(out, "\n")
	b.SetLines(newLines)
	a.SetStatusMsg(fmt.Sprintf("formatado com %s", fc.cmd))
}

// firstLineOnly corta uma mensagem de erro multi-linha na primeira linha,
// pra não estourar a barra de status com o erro inteiro do formatador.
func firstLineOnly(s string) string {
	if i := strings.IndexByte(s, '\n'); i >= 0 {
		return s[:i]
	}
	return s
}
