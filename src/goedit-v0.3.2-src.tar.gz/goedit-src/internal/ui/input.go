package ui

import (
	"fmt"
	"path/filepath"
	"strconv"
	"strings"
	"unicode/utf8"

	"github.com/gdamore/tcell/v2"

	"goedit/internal/buffer"
)

// HandleKey processa um evento de teclado e atualiza o estado do App.
func (a *App) HandleKey(ev *tcell.EventKey) {
	if a.RenameActive {
		a.handleRenameKey(ev)
		return
	}
	if a.PromptActive {
		a.handlePromptKey(ev)
		return
	}
	if a.SidebarFocused {
		a.handleSidebarKey(ev)
		return
	}
	a.handleEditorKey(ev)
}

func (a *App) handlePromptKey(ev *tcell.EventKey) {
	switch ev.Key() {
	case tcell.KeyEnter:
		a.submitPrompt()
	case tcell.KeyEsc:
		a.cancelPrompt()
	case tcell.KeyBackspace, tcell.KeyBackspace2:
		if len(a.PromptInput) > 0 {
			a.PromptInput = a.PromptInput[:len(a.PromptInput)-1]
		}
	case tcell.KeyRune:
		a.PromptInput += string(ev.Rune())
	}
}

func (a *App) handleSidebarKey(ev *tcell.EventKey) {
	switch ev.Key() {
	case tcell.KeyUp:
		if a.SidebarSel > 0 {
			a.SidebarSel--
		}
	case tcell.KeyDown:
		if a.SidebarSel < len(a.SidebarEntries)-1 {
			a.SidebarSel++
		}
	case tcell.KeyEnter:
		if a.SidebarSel < len(a.SidebarEntries) {
			e := a.SidebarEntries[a.SidebarSel]
			full := filepath.Join(a.SidebarPath, e.Name())
			if e.IsDir() {
				a.SidebarPath = full
				a.SidebarSel = 0
				a.reloadSidebar()
			} else {
				a.OpenFile(full)
				a.SidebarFocused = false
			}
		}
	case tcell.KeyBackspace, tcell.KeyBackspace2:
		a.SidebarPath = filepath.Dir(a.SidebarPath)
		a.SidebarSel = 0
		a.reloadSidebar()
	case tcell.KeyCtrlB:
		a.ShowSidebar = false
		a.SidebarFocused = false
	case tcell.KeyEsc:
		a.SidebarFocused = false
	}
}

func (a *App) handleEditorKey(ev *tcell.EventKey) {
	b := a.ActiveBuffer()
	shift := ev.Modifiers()&tcell.ModShift != 0
	alt := ev.Modifiers()&tcell.ModAlt != 0

	// Atalhos globais primeiro (não dependem de shift/alt).
	switch ev.Key() {
	case tcell.KeyCtrlQ:
		a.Quit = true
		return
	case tcell.KeyCtrlS:
		a.doSave()
		return
	case tcell.KeyCtrlO:
		a.startPrompt("Abrir arquivo: ", func(input string) {
			if input != "" {
				a.OpenFile(input)
			}
		}, nil)
		return
	case tcell.KeyCtrlN:
		a.NewBuffer()
		return
	case tcell.KeyCtrlW:
		a.CloseActiveBuffer()
		return
	case tcell.KeyCtrlB:
		a.ShowSidebar = !a.ShowSidebar
		if a.ShowSidebar {
			a.SidebarFocused = true
		}
		return
	case tcell.KeyCtrlBackslash:
		a.ToggleSplit()
		return
	case tcell.KeyCtrlL:
		a.SwitchPaneFocus()
		return
	case tcell.KeyCtrlF:
		a.startPrompt("Buscar: ", func(input string) {
			a.LastSearch = input
			a.doFind(false)
		}, nil)
		return
	case tcell.KeyCtrlH:
		a.startPrompt("Substituir - buscar: ", func(find string) {
			a.startPrompt("Substituir por: ", func(repl string) {
				n := b.ReplaceAll(find, repl)
				a.StatusMsg = fmt.Sprintf("%d substituição(ões) feita(s)", n)
			}, nil)
		}, nil)
		return
	case tcell.KeyCtrlP:
		a.startPrompt("Comando: ", func(name string) {
			if _, ok := a.Plugins.Commands[name]; !ok {
				a.StatusMsg = "comando não encontrado: " + name
				return
			}
			if err := a.Plugins.Run(name); err != nil {
				a.StatusMsg = "erro no plugin: " + err.Error()
			}
		}, nil)
		return
	case tcell.KeyCtrlZ:
		if !b.Undo() {
			a.StatusMsg = "nada para desfazer"
		}
		return
	case tcell.KeyCtrlU:
		// Atalho extra de undo (além do Ctrl+Z padrão) — não mostra
		// mensagem quando não há mais nada a desfazer, então dá pra
		// martelar sem se preocupar em passar do ponto.
		b.Undo()
		return
	case tcell.KeyCtrlY:
		if !b.Redo() {
			a.StatusMsg = "nada para refazer"
		}
		return
	case tcell.KeyCtrlK:
		// Delete de linha. No terminal, Ctrl+Shift+K quase sempre chega
		// como o mesmo código de Ctrl+K puro (o bit de shift se perde em
		// combinações Ctrl+letra), então tratamos os dois igual — bate
		// com o atalho de apagar linha do VS Code na prática.
		b.DeleteLine()
		return
	case tcell.KeyCtrlD:
		b.DuplicateLine()
		return
	case tcell.KeyCtrlG:
		a.startPrompt("Ir para linha: ", func(input string) {
			n, err := strconv.Atoi(input)
			if err == nil {
				b.GoToLine(n)
			}
		}, nil)
		return
	case tcell.KeyCtrlA:
		b.SelectAll()
		return
	case tcell.KeyCtrlC:
		if b.Selecting {
			a.Clipboard = b.SelectedText()
			a.StatusMsg = "copiado"
		}
		return
	case tcell.KeyCtrlX:
		if b.Selecting {
			a.Clipboard = b.SelectedText()
			b.DeleteSelection()
		} else {
			a.Clipboard = b.Lines[b.CursorY] + "\n"
			b.DeleteLine()
		}
		return
	case tcell.KeyCtrlV:
		if a.Clipboard != "" {
			b.InsertTextAtCursor(a.Clipboard)
		}
		return
	case tcell.KeyCtrlUnderscore:
		// Ctrl+/ chega como este código na maioria dos terminais (mesmo byte 0x1F).
		b.ToggleLineComment(commentPrefixFor(b.Path))
		return
	case tcell.KeyF3:
		a.doFind(true)
		return
	case tcell.KeyF2:
		a.startRename(b)
		return
	}

	// Alt+Seta: troca de aba ou move linha (Alt+Cima/Baixo).
	if alt {
		switch ev.Key() {
		case tcell.KeyLeft:
			a.PrevTab()
			return
		case tcell.KeyRight:
			a.NextTab()
			return
		case tcell.KeyUp:
			b.MoveLineUp()
			return
		case tcell.KeyDown:
			b.MoveLineDown()
			return
		}
	}

	// Shift+Seta / Shift+Home / Shift+End: estende a seleção.
	if shift {
		switch ev.Key() {
		case tcell.KeyUp:
			b.StartSelection()
			b.MoveCursor(0, -1)
			return
		case tcell.KeyDown:
			b.StartSelection()
			b.MoveCursor(0, 1)
			return
		case tcell.KeyLeft:
			b.StartSelection()
			b.MoveCursor(-1, 0)
			return
		case tcell.KeyRight:
			b.StartSelection()
			b.MoveCursor(1, 0)
			return
		case tcell.KeyHome:
			b.StartSelection()
			b.CursorX = 0
			return
		case tcell.KeyEnd:
			b.StartSelection()
			b.CursorX = len(b.Lines[b.CursorY])
			return
		}
	}

	// Ctrl+Home / Ctrl+End: início/fim do arquivo.
	if ev.Modifiers()&tcell.ModCtrl != 0 {
		switch ev.Key() {
		case tcell.KeyHome:
			b.ClearSelection()
			b.CursorY, b.CursorX = 0, 0
			return
		case tcell.KeyEnd:
			b.ClearSelection()
			b.CursorY = len(b.Lines) - 1
			b.CursorX = len(b.Lines[b.CursorY])
			return
		}
	}

	// Edição / navegação normal — qualquer movimento sem shift cancela a seleção.
	switch ev.Key() {
	case tcell.KeyUp:
		b.ClearSelection()
		b.MoveCursor(0, -1)
	case tcell.KeyDown:
		b.ClearSelection()
		b.MoveCursor(0, 1)
	case tcell.KeyLeft:
		b.ClearSelection()
		b.MoveCursor(-1, 0)
	case tcell.KeyRight:
		b.ClearSelection()
		b.MoveCursor(1, 0)
	case tcell.KeyHome:
		b.ClearSelection()
		b.CursorX = 0
	case tcell.KeyEnd:
		b.ClearSelection()
		b.CursorX = len(b.Lines[b.CursorY])
	case tcell.KeyPgUp:
		b.ClearSelection()
		for i := 0; i < 20; i++ {
			b.MoveCursor(0, -1)
		}
	case tcell.KeyPgDn:
		b.ClearSelection()
		for i := 0; i < 20; i++ {
			b.MoveCursor(0, 1)
		}
	case tcell.KeyEnter:
		b.InsertNewline()
	case tcell.KeyBackspace, tcell.KeyBackspace2:
		b.Backspace()
	case tcell.KeyDelete:
		b.DeleteForward()
	case tcell.KeyInsert:
		a.OverwriteMode = !a.OverwriteMode
		if a.OverwriteMode {
			a.StatusMsg = "modo OVERWRITE (sobrescrever)"
		} else {
			a.StatusMsg = "modo INSERT (inserir)"
		}
	case tcell.KeyTab:
		if b.Selecting {
			b.IndentSelection(a.indentString())
		} else if a.Settings.InsertSpaces {
			for i := 0; i < a.Settings.TabWidth; i++ {
				b.InsertRune(' ')
			}
		} else {
			b.InsertRune('\t')
		}
	case tcell.KeyBacktab:
		if b.Selecting {
			b.DedentSelection(a.Settings.TabWidth)
		} else {
			b.DedentCurrentLine(a.Settings.TabWidth)
		}
	case tcell.KeyRune:
		if a.OverwriteMode && !b.Selecting {
			b.OverwriteRune(ev.Rune())
		} else {
			b.InsertRune(ev.Rune())
		}
	}
}

// indentString devolve o texto inserido por um nível de indentação,
// respeitando a configuração de tabWidth/insertSpaces do usuário.
func (a *App) indentString() string {
	if a.Settings.InsertSpaces {
		return strings.Repeat(" ", a.Settings.TabWidth)
	}
	return "\t"
}

// commentPrefixFor devolve o prefixo de comentário de linha pra linguagens comuns,
// baseado na extensão do arquivo. Vazio significa "sem comentário conhecido".
func commentPrefixFor(path string) string {
	ext := filepath.Ext(path)
	switch ext {
	case ".go", ".c", ".h", ".cpp", ".hpp", ".cc", ".java", ".js", ".ts", ".jsx", ".tsx",
		".rs", ".swift", ".kt", ".cs", ".php", ".scala", ".dart":
		return "//"
	case ".py", ".sh", ".bash", ".zsh", ".rb", ".pl", ".r", ".yaml", ".yml", ".toml", ".cfg", ".ini":
		return "#"
	case ".lua", ".sql", ".hs":
		return "--"
	case ".vim":
		return "\""
	case ".html", ".xml", ".md":
		return "<!--"
	default:
		return "//"
	}
}

func (a *App) doSave() {
	b := a.ActiveBuffer()
	if b.Path == "" {
		a.startPrompt("Salvar como: ", func(path string) {
			if path == "" {
				return
			}
			if err := b.SaveAs(path); err != nil {
				a.StatusMsg = "erro ao salvar: " + err.Error()
			} else {
				a.StatusMsg = "salvo em " + path
			}
		}, nil)
		return
	}
	if err := b.Save(); err != nil {
		a.StatusMsg = "erro ao salvar: " + err.Error()
	} else {
		a.StatusMsg = "salvo"
	}
}

func (a *App) doFind(skipCurrent bool) {
	if a.LastSearch == "" {
		return
	}
	b := a.ActiveBuffer()
	fromCol := b.CursorX
	if skipCurrent {
		fromCol++
	}
	y, x, ok := b.Find(a.LastSearch, b.CursorY, fromCol)
	if !ok {
		a.StatusMsg = "não encontrado: " + a.LastSearch
		return
	}
	b.CursorY = y
	b.CursorX = x
	a.StatusMsg = ""
}

// --- Renomear ao vivo (F2) ---

// startRename entra no modo de renomear: acha a palavra sob o cursor,
// guarda uma cópia do texto original (pra poder cancelar e pra servir de
// base do preview a cada tecla), e cria o primeiro preview (sem troca
// nenhuma ainda, já que o nome novo começa vazio).
func (a *App) startRename(b *buffer.Buffer) {
	word := b.WordUnderCursor()
	if word == "" {
		a.StatusMsg = "cursor precisa estar em cima de uma palavra"
		return
	}
	orig := make([]string, len(b.Lines))
	copy(orig, b.Lines)

	b.MarkUndoPoint() // um único ponto de undo pra sessão de rename inteira

	a.RenameActive = true
	a.RenameWord = word
	a.RenameNew = word // começa com o nome original intacto (só destacado, como o VS Code)
	a.RenameCursor = len(word)
	a.RenameOrigLines = orig
	a.RenamePaneBuf = a.Panes[a.ActivePane]
	a.updateRenamePreview()
}

// updateRenamePreview recalcula o texto (a partir do snapshot original)
// com o nome já digitado até agora, e atualiza o destaque das ocorrências.
func (a *App) updateRenamePreview() {
	b := a.Buffers[a.RenamePaneBuf]
	newLines, occs := buffer.ReplaceWholeWordPreview(a.RenameOrigLines, a.RenameWord, a.RenameNew)
	b.Lines = newLines
	a.RenameOccs = occs
	b.Dirty = true
	if len(occs) > 0 {
		b.CursorY = occs[0].Y
		b.CursorX = occs[0].X1
	}
}

func (a *App) handleRenameKey(ev *tcell.EventKey) {
	switch ev.Key() {
	case tcell.KeyEnter:
		a.commitRename()
		return
	case tcell.KeyEsc:
		a.cancelRename()
		return
	case tcell.KeyLeft:
		if a.RenameCursor > 0 {
			_, size := utf8.DecodeLastRuneInString(a.RenameNew[:a.RenameCursor])
			a.RenameCursor -= size
		}
		return
	case tcell.KeyRight:
		if a.RenameCursor < len(a.RenameNew) {
			_, size := utf8.DecodeRuneInString(a.RenameNew[a.RenameCursor:])
			a.RenameCursor += size
		}
		return
	case tcell.KeyHome:
		a.RenameCursor = 0
		return
	case tcell.KeyEnd:
		a.RenameCursor = len(a.RenameNew)
		return
	case tcell.KeyBackspace, tcell.KeyBackspace2:
		if a.RenameCursor > 0 {
			_, size := utf8.DecodeLastRuneInString(a.RenameNew[:a.RenameCursor])
			a.RenameNew = a.RenameNew[:a.RenameCursor-size] + a.RenameNew[a.RenameCursor:]
			a.RenameCursor -= size
			a.updateRenamePreview()
		}
		return
	case tcell.KeyDelete:
		if a.RenameCursor < len(a.RenameNew) {
			_, size := utf8.DecodeRuneInString(a.RenameNew[a.RenameCursor:])
			a.RenameNew = a.RenameNew[:a.RenameCursor] + a.RenameNew[a.RenameCursor+size:]
			a.updateRenamePreview()
		}
		return
	case tcell.KeyInsert:
		a.OverwriteMode = !a.OverwriteMode
		return
	case tcell.KeyRune:
		r := string(ev.Rune())
		if a.OverwriteMode && a.RenameCursor < len(a.RenameNew) {
			// respeita o modo overwrite do editor: substitui o caractere
			// sob o cursor em vez de empurrar o resto pra frente.
			_, size := utf8.DecodeRuneInString(a.RenameNew[a.RenameCursor:])
			a.RenameNew = a.RenameNew[:a.RenameCursor] + r + a.RenameNew[a.RenameCursor+size:]
		} else {
			a.RenameNew = a.RenameNew[:a.RenameCursor] + r + a.RenameNew[a.RenameCursor:]
		}
		a.RenameCursor += len(r)
		a.updateRenamePreview()
		return
	}
}

func (a *App) commitRename() {
	b := a.Buffers[a.RenamePaneBuf]
	if a.RenameNew == "" || a.RenameNew == a.RenameWord {
		// nome vazio ou igual ao original: nada de fato mudou, restaura
		// o texto original pra não deixar uma alteração vazia no undo.
		b.Lines = a.RenameOrigLines
		b.Dirty = len(a.RenameOrigLines) > 0 && b.Dirty // mantém o estado anterior
		a.StatusMsg = "renomear cancelado (nome vazio ou igual)"
	} else {
		a.StatusMsg = fmt.Sprintf("%d ocorrência(s) de '%s' renomeada(s) para '%s'",
			len(a.RenameOccs), a.RenameWord, a.RenameNew)
	}
	a.RenameActive = false
	a.RenameOccs = nil
	a.RenameOrigLines = nil
}

func (a *App) cancelRename() {
	b := a.Buffers[a.RenamePaneBuf]
	b.Lines = a.RenameOrigLines
	a.RenameActive = false
	a.RenameOccs = nil
	a.RenameOrigLines = nil
	a.StatusMsg = "renomear cancelado"
}
