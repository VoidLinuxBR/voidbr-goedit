package ui

import (
	"fmt"
	"strings"

	"github.com/gdamore/tcell/v2"
	"github.com/mattn/go-runewidth"

	"goedit/internal/buffer"
	"goedit/internal/syntax"
)

var (
	styleDefault       = tcell.StyleDefault
	styleStatus        = tcell.StyleDefault.Background(tcell.ColorDarkSlateGray).Foreground(tcell.ColorWhite)
	styleTabActive     = tcell.StyleDefault.Background(tcell.ColorSteelBlue).Foreground(tcell.ColorWhite).Bold(true)
	styleTabIdle       = tcell.StyleDefault.Background(tcell.ColorDarkSlateGray).Foreground(tcell.ColorLightGray)
	styleSidebar       = tcell.StyleDefault.Foreground(tcell.ColorLightGray)
	styleSidebarSel    = tcell.StyleDefault.Background(tcell.ColorSteelBlue).Foreground(tcell.ColorWhite)
	styleSidebarSelDim = tcell.StyleDefault.Background(tcell.ColorDimGray).Foreground(tcell.ColorWhite)
	styleContextMenu   = tcell.StyleDefault.Background(tcell.ColorWhite).Foreground(tcell.ColorBlack)
	styleLineNum       = tcell.StyleDefault.Foreground(tcell.ColorGray)
	styleDirty         = tcell.StyleDefault.Foreground(tcell.ColorOrange)
	styleSelection     = tcell.StyleDefault.Background(tcell.ColorDimGray)
	styleRename        = tcell.StyleDefault.Background(tcell.ColorDarkGoldenrod).Foreground(tcell.ColorBlack)

	// segmentos coloridos da barra de status (estilo airline/lightline) —
	// cores vívidas e variadas, não só tons de azul
	styleModeIns   = tcell.StyleDefault.Background(tcell.ColorYellow).Foreground(tcell.ColorBlack).Bold(true)
	styleModeOvr   = tcell.StyleDefault.Background(tcell.ColorRed).Foreground(tcell.ColorWhite).Bold(true)
	styleStatusMid = tcell.StyleDefault.Background(tcell.ColorNavy).Foreground(tcell.ColorWhite)
	styleAccentEnc = tcell.StyleDefault.Background(tcell.ColorDarkTurquoise).Foreground(tcell.ColorBlack).Bold(true)
	styleAccentPos = tcell.StyleDefault.Background(tcell.ColorFuchsia).Foreground(tcell.ColorWhite).Bold(true)
)

func drawText(s tcell.Screen, x, y int, style tcell.Style, text string) int {
	for _, r := range text {
		s.SetContent(x, y, r, nil, style)
		x += runewidth.RuneWidth(r)
	}
	return x
}

// Render desenha a tela inteira a partir do estado atual do App.
func (a *App) Render() {
	w, h := a.Screen.Size()
	if w < 20 || h < 5 {
		a.Screen.Show()
		return
	}

	editorTop := 0
	editorBottom := h - 2 // deixa 1 linha pra status, 1 pra prompt/mensagem
	editorLeft := 0

	layout := RenderLayout{}

	if a.ShowSidebar {
		closeX0, closeX1 := a.drawSidebar(0, editorTop, a.SidebarWidth, editorBottom)
		editorLeft = a.SidebarWidth + 1
		layout.SidebarVisible = true
		layout.SidebarX0, layout.SidebarY0 = 0, editorTop
		layout.SidebarX1, layout.SidebarY1 = a.SidebarWidth, editorTop+editorBottom
		layout.SidebarRowY0 = editorTop + 1
		layout.SidebarBorderX = a.SidebarWidth // coluna do "│", arrastável pra redimensionar
		layout.SidebarCloseX0, layout.SidebarCloseX1 = closeX0, closeX1
	}

	paneCount := len(a.Panes)
	paneWidth := (w - editorLeft) / paneCount
	layout.Panes = make([]PaneLayout, paneCount)
	for i, bufIdx := range a.Panes {
		px := editorLeft + i*paneWidth
		pw := paneWidth
		if i == paneCount-1 {
			pw = w - px
		}
		pl := a.drawPane(bufIdx, px, editorTop, pw, editorBottom, i == a.ActivePane && !a.SidebarFocused)
		layout.Panes[i] = pl
	}
	a.Layout = layout

	a.drawStatusBar(0, h-2, w)
	a.drawBottomLine(0, h-1, w)

	// posiciona o cursor visível do terminal — segue o texto principal
	// sempre, inclusive durante o renomear (F2): o cursor fica na
	// ocorrência de origem, inline, nunca numa linha separada.
	if !a.PromptActive && !a.SidebarFocused && !a.ContextMenuActive {
		bufIdx := a.Panes[a.ActivePane]
		b := a.Buffers[bufIdx]
		paneX := editorLeft + a.ActivePane*paneWidth
		gutter := lineNumWidth(len(b.Lines))
		tabWidth := a.Settings.TabWidth
		if tabWidth <= 0 {
			tabWidth = 4
		}
		cursorVCol := visualColOf(b.Lines[b.CursorY], b.CursorX, tabWidth)
		cx := paneX + gutter + (cursorVCol - b.OffsetX)
		cy := editorTop + 1 + (b.CursorY - b.OffsetY) // +1: a linha de abas fica acima do texto
		a.Screen.ShowCursor(cx, cy)
	} else {
		a.Screen.HideCursor()
	}

	a.drawContextMenu()

	a.Screen.Show()
}

// contextMenuBox calcula a posição e o tamanho do menu de contexto,
// ajustando pra caber na tela (abre pra cima/esquerda se não couber pra
// baixo/direita a partir do ponto do clique). Usado tanto pra desenhar
// quanto pra saber em qual item um clique caiu — nunca deve divergir
// entre as duas contas, por isso é uma função só.
func (a *App) contextMenuBox() (x, y, width, height int) {
	for _, it := range a.ContextMenuItems {
		if l := len(it.Label) + 2; l > width {
			width = l
		}
	}
	height = len(a.ContextMenuItems)
	w, h := a.Screen.Size()
	x, y = a.ContextMenuX, a.ContextMenuY
	if x+width > w {
		x = w - width
	}
	if x < 0 {
		x = 0
	}
	if y+height > h {
		y = h - height
	}
	if y < 0 {
		y = 0
	}
	return x, y, width, height
}

func (a *App) drawContextMenu() {
	if !a.ContextMenuActive || len(a.ContextMenuItems) == 0 {
		return
	}
	x, y, width, _ := a.contextMenuBox()
	for i, it := range a.ContextMenuItems {
		row := y + i
		label := truncate(" "+it.Label, width)
		for len(label) < width {
			label += " "
		}
		drawText(a.Screen, x, row, styleContextMenu, label)
	}
}

// visualColOf calcula a coluna visual (na tela) correspondente a um índice
// de byte dentro da linha, respeitando tab-stops — necessário porque uma
// tabulação ocupa mais de 1 coluna, então índice de byte e coluna de tela
// divergem em qualquer linha que tenha \t.
func visualColOf(line string, byteIdx, tabWidth int) int {
	if byteIdx > len(line) {
		byteIdx = len(line)
	}
	if tabWidth <= 0 {
		tabWidth = 4
	}
	vcol := 0
	i := 0
	for _, r := range line {
		if i >= byteIdx {
			break
		}
		if r == '\t' {
			vcol += tabWidth - (vcol % tabWidth)
		} else {
			w := runewidth.RuneWidth(r)
			if w <= 0 {
				w = 1
			}
			vcol += w
		}
		i += len(string(r))
	}
	return vcol
}

// byteIndexForVisualCol é o inverso de visualColOf: dada uma coluna visual
// (coluna de tela) alvo, acha o índice de byte na linha que corresponde a
// ela — necessário pra saber em qual caractere um clique do mouse caiu,
// já que tabs ocupam mais de 1 coluna de tela.
func byteIndexForVisualCol(line string, targetVCol, tabWidth int) int {
	if tabWidth <= 0 {
		tabWidth = 4
	}
	vcol := 0
	i := 0
	for _, r := range line {
		if vcol >= targetVCol {
			return i
		}
		if r == '\t' {
			vcol += tabWidth - (vcol % tabWidth)
		} else {
			w := runewidth.RuneWidth(r)
			if w <= 0 {
				w = 1
			}
			vcol += w
		}
		i += len(string(r))
	}
	return len(line)
}

func lineNumWidth(nlines int) int {
	digits := 2
	n := nlines
	for n >= 10 {
		digits++
		n /= 10
	}
	if digits < 4 {
		digits = 4
	}
	return digits
}

func (a *App) drawSidebar(x, y, width, height int) (closeX0, closeX1 int) {
	style := styleSidebar
	headerStyle := styleTabActive // mesma cor do nome de arquivo na aba ativa
	cx := drawText(a.Screen, x, y, headerStyle, truncate(" SIDEBAR", width))
	for cx < x+width {
		a.Screen.SetContent(cx, y, ' ', nil, headerStyle)
		cx++
	}
	// "x" de fechar no canto direito do título, clicável.
	closeX0, closeX1 = x+width-2, x+width-1
	if closeX0 > cx-3 { // só desenha se realmente sobrar espaço depois de "SIDEBAR"
		a.Screen.SetContent(closeX0, y, 'x', nil, headerStyle.Bold(true))
	} else {
		closeX0, closeX1 = -1, -1
	}
	for row := 1; row < height; row++ {
		for c := 0; c < width; c++ {
			a.Screen.SetContent(x+c, y+row, ' ', nil, styleDefault)
		}
	}

	visibleRows := height - 1 // linha 0 é o cabeçalho "SIDEBAR"
	if visibleRows < 1 {
		visibleRows = 1
	}
	// mantém a seleção sempre visível, rolando a lista quando preciso —
	// mesma lógica do scroll vertical do texto principal.
	if a.SidebarSel < a.SidebarOffset {
		a.SidebarOffset = a.SidebarSel
	}
	if a.SidebarSel >= a.SidebarOffset+visibleRows {
		a.SidebarOffset = a.SidebarSel - visibleRows + 1
	}
	if a.SidebarOffset < 0 {
		a.SidebarOffset = 0
	}
	maxOffset := len(a.SidebarEntries) - visibleRows
	if maxOffset < 0 {
		maxOffset = 0
	}
	if a.SidebarOffset > maxOffset {
		a.SidebarOffset = maxOffset
	}

	for row := 0; row < visibleRows; row++ {
		i := a.SidebarOffset + row
		if i >= len(a.SidebarEntries) {
			break
		}
		e := a.SidebarEntries[i]
		sy := y + 1 + row
		name := e.Name()
		if e.IsDir() {
			name += "/"
		}
		st := style
		if i == a.SidebarSel {
			if a.SidebarFocused {
				st = styleSidebarSel
			} else {
				st = styleSidebarSelDim
			}
		}
		line := truncate(" "+name, width)
		for len(line) < width {
			line += " "
		}
		drawText(a.Screen, x, sy, st, line)
	}
	// borda direita
	for row := y; row < y+height; row++ {
		a.Screen.SetContent(x+width, row, '│', nil, styleSidebar)
	}
	return closeX0, closeX1
}

func (a *App) drawPane(bufIdx, x, y, width, height int, focused bool) PaneLayout {
	b := a.Buffers[bufIdx]
	tabRanges := a.drawTabs(bufIdx, x, y, width)

	gutter := lineNumWidth(len(b.Lines))
	textTop := y + 1
	textHeight := height - 1
	textWidth := width - gutter
	if textWidth < 1 {
		textWidth = 1
	}

	tabWidth := a.Settings.TabWidth
	if tabWidth <= 0 {
		tabWidth = 4
	}

	// ajusta scroll vertical/horizontal pra manter o cursor visível.
	// O scroll horizontal trabalha em COLUNA VISUAL (considerando o
	// espaço que uma tabulação ocupa na tela), não em índice bruto do
	// texto — senão uma linha com \t rola errado.
	if b.CursorY < b.OffsetY {
		b.OffsetY = b.CursorY
	}
	if b.CursorY >= b.OffsetY+textHeight {
		b.OffsetY = b.CursorY - textHeight + 1
	}
	cursorVCol := visualColOf(b.Lines[b.CursorY], b.CursorX, tabWidth)
	if cursorVCol < b.OffsetX {
		b.OffsetX = cursorVCol
	}
	if cursorVCol >= b.OffsetX+textWidth {
		b.OffsetX = cursorVCol - textWidth + 1
	}
	if b.OffsetY < 0 {
		b.OffsetY = 0
	}
	if b.OffsetX < 0 {
		b.OffsetX = 0
	}

	var selSY, selSX, selEY, selEX int
	hasSel := b.Selecting
	if hasSel {
		selSY, selSX, selEY, selEX = selectionRange(b.SelStartY, b.SelStartX, b.CursorY, b.CursorX)
	}

	renaming := a.RenameActive && bufIdx == a.RenamePaneBuf

	for row := 0; row < textHeight; row++ {
		lineIdx := b.OffsetY + row
		sy := textTop + row
		if lineIdx >= len(b.Lines) {
			cx := drawText(a.Screen, x, sy, styleLineNum, fmt.Sprintf("%*s ", gutter-1, "~"))
			for cx < x+width {
				a.Screen.SetContent(cx, sy, ' ', nil, styleDefault)
				cx++
			}
			continue
		}
		numStr := fmt.Sprintf("%*d ", gutter-1, lineIdx+1)
		drawText(a.Screen, x, sy, styleLineNum, numStr)

		segs := syntax.HighlightLine(b.Path, b.Lines[0], b.Lines[lineIdx])
		cx := x + gutter
		vcol := 0   // coluna visual (considera largura de tab) desde o início da linha
		byteAt := 0 // posição em bytes desde o início da linha (bate com CursorX/SelStartX)
		for _, seg := range segs {
			for _, r := range seg.Text {
				runeBytes := len(string(r))
				st := seg.Style
				if hasSel && inSelection(lineIdx, byteAt, selSY, selSX, selEY, selEX) {
					st = styleSelection
				}
				if renaming {
					if idx, inOcc := renameOccurrenceIndexAt(lineIdx, byteAt, a.RenameOccs); inOcc {
						if idx == a.RenameOriginOccIdx && a.RenameSelecting {
							o := a.RenameOccs[idx]
							relPos := byteAt - o.X0
							selS, selE := a.RenameSelStart, a.RenameCursor
							if selS > selE {
								selS, selE = selE, selS
							}
							if relPos >= selS && relPos < selE {
								st = styleSelection
							} else {
								st = styleRename
							}
						} else {
							st = styleRename
						}
					}
				}
				if r == '\t' {
					stop := tabWidth - (vcol % tabWidth)
					for k := 0; k < stop; k++ {
						if vcol >= b.OffsetX && cx < x+width {
							a.Screen.SetContent(cx, sy, ' ', nil, st)
							cx++
						}
						vcol++
					}
				} else {
					w := runewidth.RuneWidth(r)
					if w <= 0 {
						w = 1
					}
					if vcol >= b.OffsetX && cx < x+width {
						a.Screen.SetContent(cx, sy, r, nil, st)
						cx += w
					}
					vcol += w
				}
				byteAt += runeBytes
			}
		}
		for cx < x+width {
			a.Screen.SetContent(cx, sy, ' ', nil, styleDefault)
			cx++
		}
	}

	return PaneLayout{
		BufIdx:     bufIdx,
		X:          x,
		TabY:       y,
		TextTop:    textTop,
		TextX:      x + gutter,
		Width:      width,
		TextHeight: textHeight,
		Gutter:     gutter,
		TabRanges:  tabRanges,
	}
}

// selectionRange normaliza dois pontos (início/fim) na ordem em que aparecem no texto.
func selectionRange(sy, sx, ey, ex int) (int, int, int, int) {
	if sy > ey || (sy == ey && sx > ex) {
		return ey, ex, sy, sx
	}
	return sy, sx, ey, ex
}

// inSelection diz se a posição (linha, coluna) está dentro do intervalo selecionado.
func inSelection(y, x, sy, sx, ey, ex int) bool {
	if y < sy || y > ey {
		return false
	}
	if sy == ey {
		return x >= sx && x < ex
	}
	if y == sy {
		return x >= sx
	}
	if y == ey {
		return x < ex
	}
	return true
}

// renameOccurrenceIndexAt diz se a posição (linha, byte) cai dentro de
// alguma ocorrência destacada pelo modo de renomear ao vivo (F2), e
// devolve o índice dela em occs (pra saber se é a ocorrência de origem).
func renameOccurrenceIndexAt(y, x int, occs []buffer.WordOccurrence) (int, bool) {
	for i, o := range occs {
		if o.Y == y && x >= o.X0 && x < o.X1 {
			return i, true
		}
	}
	return -1, false
}

func (a *App) drawTabs(activeBufIdx, x, y, width int) []TabRange {
	cx := x
	var ranges []TabRange
	for i, b := range a.Buffers {
		name := b.Name()
		if b.Dirty {
			name = "*" + name
		}
		label := " " + name + " "
		st := styleTabIdle
		if i == activeBufIdx {
			st = styleTabActive
		}
		if cx+len(label) > x+width {
			break
		}
		x0 := cx
		cx = drawText(a.Screen, cx, y, st, label)
		ranges = append(ranges, TabRange{BufIdx: i, X0: x0, X1: cx})
	}
	for cx < x+width {
		a.Screen.SetContent(cx, y, ' ', nil, styleTabIdle)
		cx++
	}
	return ranges
}

func (a *App) drawStatusBar(x, y, width int) {
	b := a.ActiveBuffer()

	// preenche a linha toda com o fundo "do meio" primeiro
	for c := x; c < x+width; c++ {
		a.Screen.SetContent(c, y, ' ', nil, styleStatusMid)
	}
	cx := x

	// bloco do modo (cor muda: azul = inserir, laranja = sobrescrever)
	modeLabel, modeStyle := " INSERT ", styleModeIns
	if a.OverwriteMode {
		modeLabel, modeStyle = " OVERWRITE ", styleModeOvr
	}
	cx = drawText(a.Screen, cx, y, modeStyle, modeLabel)

	// nome do arquivo + indicador de alteração
	dirty := ""
	if b.Dirty {
		dirty = " [+]"
	}
	cx = drawText(a.Screen, cx, y, styleStatusMid, fmt.Sprintf(" %s%s ", b.Name(), dirty))

	// tipo de arquivo (linguagem detectada pelo highlight)
	filetype := strings.ToLower(syntax.DebugLexerName(b.Path, firstLineOf(b)))
	if filetype != "" && filetype != "nenhum" {
		cx = drawText(a.Screen, cx, y, styleStatusMid, filetype+" ")
	}

	// monta o bloco direito primeiro, pra saber a largura e alinhar à direita
	wordCount := countWords(b.Lines)
	percent := 0
	if len(b.Lines) > 1 {
		percent = b.CursorY * 100 / (len(b.Lines) - 1)
	}
	rightPlain := fmt.Sprintf(" %d palavras  %d%% ", wordCount, percent)
	posLabel := fmt.Sprintf(" Ln %d, Col %d ", b.CursorY+1, b.CursorX+1)
	encLabel := " utf-8[unix] "

	rightWidth := len(encLabel) + len(rightPlain) + len(posLabel)
	// preenche o espaço do meio com o fundo padrão até sobrar só o bloco direito
	for cx < x+width-rightWidth {
		a.Screen.SetContent(cx, y, ' ', nil, styleStatusMid)
		cx++
	}
	if cx > x+width-rightWidth {
		return // tela estreita demais pro bloco direito inteiro — deixa como está
	}
	cx = drawText(a.Screen, cx, y, styleAccentEnc, truncate(encLabel, x+width-cx))
	cx = drawText(a.Screen, cx, y, styleStatusMid, truncate(rightPlain, x+width-cx))
	drawText(a.Screen, cx, y, styleAccentPos, truncate(posLabel, x+width-cx))
}

// firstLineOf devolve a primeira linha do buffer (protegido contra buffer vazio).
func firstLineOf(b *buffer.Buffer) string {
	if len(b.Lines) == 0 {
		return ""
	}
	return b.Lines[0]
}

// countWords conta palavras (tokens separados por espaço em branco) no buffer inteiro.
func countWords(lines []string) int {
	count := 0
	for _, line := range lines {
		count += len(strings.Fields(line))
	}
	return count
}

func (a *App) drawBottomLine(x, y, width int) {
	// sem o Clear() global, precisamos limpar essa linha nós mesmos antes
	// de desenhar — senão um prompt/mensagem anterior mais longo deixa
	// sobra de texto nas células que o desenho de agora não toca.
	for c := x; c < x+width; c++ {
		a.Screen.SetContent(c, y, ' ', nil, styleDefault)
	}

	if a.RenameActive {
		n := len(a.RenameOccs)
		label := fmt.Sprintf("Renomeando '%s' → '%s' (%d ocorrência(s)) — Enter confirma · Esc cancela",
			a.RenameWord, a.RenameNew, n)
		drawText(a.Screen, x, y, styleRename, truncate(label, width))
		return
	}
	if a.PromptActive {
		text := a.PromptLabel + a.PromptInput
		drawText(a.Screen, x, y, styleDefault, truncate(text, width))
		return
	}
	if a.StatusMsg != "" {
		drawText(a.Screen, x, y, styleDirty, truncate(a.StatusMsg, width))
	}
}

func truncate(s string, width int) string {
	if width <= 0 {
		return ""
	}
	r := []rune(s)
	if len(r) <= width {
		return s
	}
	return string(r[:width])
}
