/*
   goedit
   Editor de texto para terminal (TUI), com realce de sintaxe, plugins Lua, seleção em bloco e mais
   Site:      https://chililinux.com
   Site:      https://voidbr.org
   Site:      https://voidlinux.com.br
   GitHub:    https://github.com/voidlinuxbr/voidbr-goedit
   Created:   dom 16 ago 2026 10:15:33 -04
   Updated:   seg 24 ago 2026 14:30:00 -04
   Version:   0.41.0
   Copyright (C) 2019-2026 Vilmar Catafesta <vcatafesta@gmail.com>
*/

package ui

import (
	"fmt"
	"os"

	"github.com/gdamore/tcell/v2"
)

// tryNanoKey trata as teclas do estilo "nano" (settings.json:
// "keymap": "nano") — chamada antes do despacho normal (estilo
// vscode, o padrão do goedit) sempre que esse estilo estiver ativo.
// Devolve true se tratou a tecla (nesse caso, o despacho normal nem
// roda pra essa tecla); false pra deixar cair no comportamento normal
// (digitação, setas, Home/End sem Ctrl, Delete, Backspace sem Ctrl,
// Page Up/Down sem Ctrl — tudo isso já funciona igual em qualquer
// estilo, sem precisar de tratamento especial aqui).
//
// Cobre o subconjunto mais usado do nano de verdade — não inclui
// coisas como justificar parágrafo (Ctrl+J) ou corretor ortográfico
// (Ctrl+T), que fazem pouco sentido num editor voltado a código.
func (a *App) tryNanoKey(ev *tcell.EventKey) bool {
	km := a.Settings.Keymap
	if km != "nano" && km != "nano-hibrido" {
		return false
	}
	if ev.Key() != tcell.KeyCtrlK {
		a.nanoCutStreak = false // qualquer tecla que não seja Ctrl+K quebra a sequência de corte
		a.nanoCutHitEnd = false
	}
	b := a.ActiveBuffer()

	// Ctrl+K (corta, acumulando em sequência) e Ctrl+U (cola o que foi
	// cortado) valem nos dois perfis nano — formam um par: sem os dois
	// juntos, cortar várias linhas com Ctrl+K e colar com Ctrl+U só
	// traria a última (no nano-híbrido, Ctrl+U sozinho continuaria
	// sendo "desfazer", que desfaz um corte de cada vez, não o bloco
	// inteiro de uma vez).
	if ev.Key() == tcell.KeyCtrlK {
		if b.Selecting {
			// tem bloco/texto marcado (Ctrl+^ ou seleção normal) —
			// corta o bloco inteiro, não a linha. É uma ação à parte,
			// não acumula com corte de linha em sequência.
			a.copyToClipboard(b.SelectedText())
			b.DeleteSelection()
			a.nanoCutStreak = false
			return true
		}
		// Cut — sempre a linha inteira (não parcial pelo cursor).
		// Ctrl+K seguido de Ctrl+K de novo (sem nenhuma outra tecla no
		// meio) ACRESCENTA a linha cortada ao que já tinha, em vez de
		// substituir — segurar Ctrl+K vai apagando linha por linha
		// PRA BAIXO a partir de onde o cursor estava. Nunca afeta
		// linhas acima de onde o cursor começou: se a sequência já
		// cortou até a última linha do arquivo, um Ctrl+K a mais (sem
		// soltar) não faz nada — sem essa checagem, o cursor "recua"
		// pra linha anterior (por não sobrar mais nada embaixo pra
		// ocupar aquela posição) e o próximo corte pegaria uma linha
		// que ficou ACIMA de onde tudo começou.
		if a.nanoCutStreak && a.nanoCutHitEnd {
			return true
		}
		eraUltimaLinha := b.CursorY == len(b.Lines)-1
		var cortado string
		if a.nanoCutStreak {
			cortado = a.Clipboard + b.Lines[b.CursorY] + "\n"
		} else {
			cortado = b.Lines[b.CursorY] + "\n"
		}
		a.copyToClipboard(cortado)
		if eraUltimaLinha {
			// última linha do arquivo: só limpa o conteúdo, sem
			// remover a linha — não sobra nada embaixo pra "puxar" o
			// cursor de volta, então ele fica onde estava.
			b.ClearLastLineInPlace()
		} else {
			b.DeleteLine()
		}
		a.nanoCutStreak = true
		a.nanoCutHitEnd = eraUltimaLinha
		return true
	}
	if ev.Key() == tcell.KeyCtrlU {
		// UnCut = colar (não "desfazer" — isso continua em Ctrl+Z)
		if text := a.pasteFromClipboard(); text != "" {
			b.InsertTextAtCursor(text)
		}
		return true
	}
	if km != "nano" {
		return false // as teclas abaixo (Ctrl+G, Ctrl+O, Ctrl+A...) só valem no nano clássico
	}

	switch ev.Key() {
	case tcell.KeyCtrlG:
		// nano de verdade: Ctrl+G é ajuda (não "ir pra linha", que no
		// goedit em estilo vscode usa essa tecla)
		a.HelpActive = true
		a.HelpScroll = 0
		return true
	case tcell.KeyCtrlO:
		// WriteOut = salvar
		a.doSave()
		return true
	case tcell.KeyCtrlR:
		// Read File = insere o conteúdo de outro arquivo no cursor
		a.startPrompt("Ler arquivo: ", func(path string) {
			if path == "" {
				return
			}
			data, err := os.ReadFile(path)
			if err != nil {
				a.SetStatusMsg("erro ao ler arquivo: " + err.Error())
				return
			}
			b.InsertTextAtCursor(string(data))
		}, nil)
		return true
	case tcell.KeyCtrlW:
		// Where Is = buscar
		a.startSearchPrompt()
		return true
	case tcell.KeyCtrlBackslash:
		// Replace
		a.startPrompt("Substituir - buscar: ", func(find string) {
			a.startPrompt("Substituir por: ", func(repl string) {
				n := b.ReplaceAll(find, repl)
				a.SetStatusMsg(fmt.Sprintf("%d substituição(ões) feita(s)", n))
			}, nil)
		}, nil)
		return true
	case tcell.KeyCtrlC:
		// Cur Pos = mostra a posição atual (não copia, isso é Ctrl+^
		// pra marcar seleção + outra tecla pra copiar, no nano de
		// verdade — mas copiar seleção via Ctrl+C já não existe nele)
		a.SetStatusMsg(fmt.Sprintf("linha %d de %d, coluna %d", b.CursorY+1, len(b.Lines), b.CursorX+1))
		return true
	case tcell.KeyCtrlUnderscore:
		// Go To Line (mesmo código de Ctrl+/ na maioria dos terminais
		// — em estilo nano, comentar linha fica sem atalho de Ctrl
		// dedicado, já que não é um conceito do nano)
		a.startPrompt("Ir para linha: ", func(input string) {
			var n int
			if _, err := fmt.Sscanf(input, "%d", &n); err == nil {
				b.GoToLine(n)
			}
		}, nil)
		return true
	case tcell.KeyCtrlCarat: // Ctrl+^ / Ctrl+6 — Mark Set
		if b.Selecting {
			b.ClearSelection()
			a.SetStatusMsg("seleção cancelada")
		} else {
			b.StartSelection()
			a.SetStatusMsg("marcação iniciada")
		}
		return true
	case tcell.KeyCtrlA:
		// Home (início da linha) — não "selecionar tudo", que é o
		// estilo vscode
		b.ClearSelection()
		b.CursorX = 0
		return true
	case tcell.KeyCtrlE:
		// End (fim da linha)
		b.ClearSelection()
		b.CursorX = len(b.Lines[b.CursorY])
		return true
	case tcell.KeyCtrlY:
		// Prev Page
		b.ClearSelection()
		h := a.pageHeight()
		for i := 0; i < h; i++ {
			b.MoveCursor(0, -1)
		}
		b.OffsetY -= h
		if b.OffsetY < 0 {
			b.OffsetY = 0
		}
		return true
	case tcell.KeyCtrlV:
		// Next Page (não colar — isso é Ctrl+U em estilo nano)
		b.ClearSelection()
		h := a.pageHeight()
		for i := 0; i < h; i++ {
			b.MoveCursor(0, 1)
		}
		b.OffsetY += h
		if maxOffset := len(b.Lines) - h; b.OffsetY > maxOffset {
			b.OffsetY = maxOffset
		}
		if b.OffsetY < 0 {
			b.OffsetY = 0
		}
		return true
	case tcell.KeyCtrlD:
		// apaga o caractere sob o cursor (não duplicar linha, que é
		// o estilo vscode)
		b.DeleteForward()
		return true
	case tcell.KeyCtrlH:
		// Backspace (não substituir, que é Ctrl+\ em estilo nano)
		b.Backspace()
		return true
	}
	return false
}
