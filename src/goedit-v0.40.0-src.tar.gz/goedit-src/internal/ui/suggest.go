/*
   goedit
   Editor de texto para terminal (TUI), com realce de sintaxe, plugins Lua, seleção em bloco e mais
   Site:      https://chililinux.com
   Site:      https://voidbr.org
   Site:      https://voidlinux.com.br
   GitHub:    https://github.com/voidlinuxbr/voidbr-goedit
   Created:   dom 16 ago 2026 10:15:33 -04
   Updated:   sex 21 ago 2026 11:30:00 -04
   Version:   0.40.0
   Copyright (C) 2019-2026 Vilmar Catafesta <vcatafesta@gmail.com>
*/

package ui

import (
	"strings"
	"unicode"
	"unicode/utf8"

	"github.com/gdamore/tcell/v2"
)

// isIdentChar decide o que conta como parte de um identificador pro
// autocompletar — diferente do critério do F2 (que só corta em espaço),
// aqui usamos o padrão de identificador de código de verdade: letras,
// dígitos e underscore. É isso que faz "func" não incluir o "(" que vier
// logo depois, por exemplo.
func isIdentChar(r rune) bool {
	return r == '_' || unicode.IsLetter(r) || unicode.IsDigit(r)
}

const suggestMinPrefix = 2 // não sugere nada até digitar pelo menos 2 letras
const suggestMaxItems = 8

// updateSuggestions recalcula a lista de sugestões a partir da posição
// atual do cursor. Se não houver pelo menos suggestMinPrefix caracteres
// de identificador digitados, ou nenhuma palavra do buffer bater, o
// popup fica desativado.
func (a *App) updateSuggestions() {
	b := a.ActiveBuffer()
	y, x := b.CursorY, b.CursorX
	line := b.Lines[y]
	if x > len(line) {
		x = len(line)
	}

	start := x
	for start > 0 {
		r, size := utf8.DecodeLastRuneInString(line[:start])
		if !isIdentChar(r) {
			break
		}
		start -= size
	}
	word := line[start:x]
	if len(word) < suggestMinPrefix {
		a.SuggestActive = false
		return
	}

	matches := collectBufferWords(b.Lines, word, y, start, x)
	if len(matches) == 0 {
		a.SuggestActive = false
		return
	}
	a.SuggestActive = true
	a.SuggestItems = matches
	if a.SuggestIndex >= len(matches) {
		a.SuggestIndex = 0
	}
	a.SuggestPrefix = word
	a.SuggestStartX = start
	a.SuggestY = y
}

// collectBufferWords varre o buffer inteiro coletando identificadores
// distintos que começam com prefix, na ordem em que aparecem primeiro,
// até suggestMaxItems. Pula a própria ocorrência que está sendo digitada
// (curY/curStartX/curEndX) e nunca sugere o prefixo igual a si mesmo.
// suggestScanCharLimit é o teto de caracteres varridos por chamada — sem
// isso, digitar um prefixo raro (que não bate com quase nada) obrigava
// varrer o arquivo inteiro em toda tecla, mesmo em arquivos de milhares
// de linhas, só pra concluir "não achei quase nada".
const suggestScanCharLimit = 200_000

func collectBufferWords(lines []string, prefix string, curY, curStartX, curEndX int) []string {
	seen := map[string]bool{}
	var out []string
	scanned := 0
	for y, line := range lines {
		scanned += len(line)
		if scanned > suggestScanCharLimit {
			break
		}
		i := 0
		for i < len(line) {
			r, size := utf8.DecodeRuneInString(line[i:])
			if !isIdentChar(r) {
				i += size
				continue
			}
			j := i
			for j < len(line) {
				r2, size2 := utf8.DecodeRuneInString(line[j:])
				if !isIdentChar(r2) {
					break
				}
				j += size2
			}
			word := line[i:j]
			if y == curY && i == curStartX && j == curEndX {
				i = j
				continue // a própria palavra sendo digitada agora, não conta
			}
			if word != prefix && strings.HasPrefix(word, prefix) && !seen[word] {
				seen[word] = true
				out = append(out, word)
				if len(out) >= suggestMaxItems {
					return out
				}
			}
			i = j
		}
	}
	return out
}

// handleSuggestKey trata as teclas de navegação/confirmação do popup de
// sugestões. Devolve true se tratou a tecla (o chamador não deve fazer
// mais nada com ela); false significa "não era uma tecla do popup,
// segue o fluxo normal de edição".
func (a *App) handleSuggestKey(ev *tcell.EventKey) bool {
	switch ev.Key() {
	case tcell.KeyDown:
		a.SuggestIndex = (a.SuggestIndex + 1) % len(a.SuggestItems)
		return true
	case tcell.KeyUp:
		a.SuggestIndex = (a.SuggestIndex - 1 + len(a.SuggestItems)) % len(a.SuggestItems)
		return true
	case tcell.KeyEnter, tcell.KeyTab:
		a.acceptSuggestion()
		return true
	case tcell.KeyEsc:
		a.SuggestActive = false
		return true
	}
	return false
}

// acceptSuggestion troca a palavra parcial pela sugestão escolhida, como
// uma única alteração de undo.
func (a *App) acceptSuggestion() {
	defer func() { a.SuggestActive = false }()
	if a.SuggestIndex < 0 || a.SuggestIndex >= len(a.SuggestItems) {
		return
	}
	b := a.ActiveBuffer()
	if b.CursorY != a.SuggestY {
		return // o cursor saiu da linha da sugestão — não faz sentido aplicar
	}
	chosen := a.SuggestItems[a.SuggestIndex]
	b.ReplaceRange(a.SuggestY, a.SuggestStartX, b.CursorX, chosen)
}

// syncSuggestionsAfterKey decide, depois que uma tecla de edição normal
// já foi processada, se deve recalcular as sugestões (digitou uma letra
// ou apagou um caractere) ou simplesmente cancelar o popup (qualquer
// outra tecla — mover cursor, atalhos, etc).
func (a *App) syncSuggestionsAfterKey(ev *tcell.EventKey) {
	if a.Pasting {
		a.SuggestActive = false // evita abrir/fechar a sugestão a cada caractere do texto colado
		return
	}
	switch ev.Key() {
	case tcell.KeyRune, tcell.KeyBackspace, tcell.KeyBackspace2:
		a.updateSuggestions()
	default:
		a.SuggestActive = false
	}
}
