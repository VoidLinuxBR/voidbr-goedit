/*
   goedit
   Editor de texto para terminal (TUI), com realce de sintaxe, plugins Lua, seleção em bloco e mais
   Site:      https://chililinux.com
   Site:      https://voidbr.org
   Site:      https://voidlinux.com.br
   GitHub:    https://github.com/voidlinuxbr/voidbr-goedit
   Created:   dom 16 ago 2026 10:15:33 -04
   Updated:   sex 21 ago 2026 11:30:00 -04
   Version:   0.31.0
   Copyright (C) 2019-2026 Vilmar Catafesta <vcatafesta@gmail.com>
*/

package ui

import (
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"github.com/gdamore/tcell/v2"

	"goedit/internal/buffer"
	"goedit/internal/config"
	"goedit/internal/plugin"
	"goedit/internal/sysclip"
)

// App é o estado global do editor.
type App struct {
	Screen tcell.Screen

	// cache da contagem de palavras da barra de status — recontar o
	// arquivo inteiro em TODO frame (mesmo sem editar nada) era um
	// desperdício real, medido em ~1-3ms por tecla em arquivos grandes.
	wcCacheBufIdx int
	wcCacheCount  int
	wcCacheAt     time.Time

	Buffers    []*buffer.Buffer
	Panes      []int // índice do buffer mostrado em cada painel (1 ou 2 painéis)
	ActivePane int

	ShowSidebar    bool
	SidebarFocused bool
	SidebarPath    string
	SidebarEntries []os.DirEntry
	SidebarSel     int
	SidebarOffset  int // rolagem vertical da lista de arquivos
	SidebarWidth   int

	// busca incremental por digitação (type-ahead): digitar letras pula
	// pro primeiro arquivo/pasta cujo nome começa com o que foi
	// digitado; pausar um instante reinicia a busca do zero.
	SidebarSearchBuf  string
	SidebarSearchTime time.Time

	// prompt genérico (usado por save-as, abrir arquivo, busca, substituir, paleta de comandos)
	PromptActive bool
	PromptLabel  string
	PromptInput  string
	onSubmit     func(input string)
	onCancel     func()

	LastSearch string
	// SearchHistory guarda os termos buscados (mais antigo primeiro),
	// persistido em ~/.config/goedit/search_history.json — ver
	// SetActivePrompt/handlePromptKey pra navegação com ↑/↓ e
	// commitSearchHistory pra quando um termo novo é adicionado.
	SearchHistory []string
	// PromptIsSearch: true quando o prompt aberto no momento é de
	// busca (Ctrl+F/Ctrl+W) — só nesse caso ↑/↓ navegam o histórico
	// em vez de fazerem outra coisa (ou nada).
	PromptIsSearch bool
	// searchHistoryPos: posição atual na navegação do histórico
	// (índice em SearchHistory); len(SearchHistory) significa "não
	// está navegando, o texto é o que a pessoa digitou por conta".
	searchHistoryPos int
	StatusMsg        string
	// StatusMsgExpiry: quando a mensagem atual deve sumir sozinha da
	// barra de status — ver SetStatusMsg.
	StatusMsgExpiry time.Time
	Clipboard       string

	Settings      config.Settings
	OverwriteMode bool

	// Posição de cursor (linha/coluna) salva por arquivo — restaurada
	// ao reabrir, salva ao fechar (aba ou app inteiro). Chave é o
	// caminho absoluto do arquivo.
	Positions map[string]config.Position

	// Estado do "renomear ao vivo" (F2) — mostra todas as ocorrências da
	// palavra destacadas e vai atualizando o texto conforme o usuário
	// digita o novo nome, como o Rename Symbol do VS Code.
	RenameActive       bool
	RenameWord         string
	RenameNew          string
	RenameCursor       int  // posição do cursor dentro de RenameNew (em bytes)
	RenameSelecting    bool // true se há um trecho marcado dentro do campo
	RenameSelStart     int  // âncora da marcação dentro do campo (em bytes)
	RenameOrigLines    []string
	RenamePaneBuf      int // índice do buffer sendo renomeado
	RenameOccs         []buffer.WordOccurrence
	RenameOriginOccIdx int // índice em RenameOccs da ocorrência onde o F2 foi apertado — é onde o cursor fica

	Plugins *plugin.Manager

	Quit bool

	// Autocompletar por palavras do buffer (estilo Vim/keyword completion —
	// não é IntelliSense semântico, é busca de palavras já usadas no
	// texto). Ativa depois de digitar algumas letras de um identificador;
	// setas navegam, Tab/Enter aceita, Esc ou continuar digitando fora
	// do padrão cancela.
	SuggestActive bool
	SuggestItems  []string
	SuggestIndex  int

	// Pasting: true entre o início e o fim de um paste nativo do
	// terminal (bracketed paste) — enquanto isso, HandleKey ainda
	// recebe o texto colado tecla por tecla, mas evita trabalho por
	// caractere que não faz sentido no meio de um colar (sugestões,
	// redesenho — ver main.go). PasteBuf acumula o texto colado
	// (ver accumulatePasteKey/FinishPaste) pra aplicar tudo de uma
	// vez só no fim — processar cada caractere colado pelo caminho
	// normal (InsertRune/InsertNewline, um snapshot de undo cada) era
	// O(n²) e deixava colar um texto grande visivelmente lento (~11s
	// medidos pra 20 mil linhas antes dessa correção).
	Pasting       bool
	PasteBuf      strings.Builder
	SuggestPrefix string
	SuggestStartX int // coluna onde a palavra sendo completada começa
	SuggestY      int // linha da palavra sendo completada

	// Seleção em bloco/coluna (Ctrl+Shift+setas) — marca um retângulo de
	// texto (mesma faixa de colunas em várias linhas) e permite trocar
	// aquele pedaço em todas as linhas de uma vez, digitando uma única
	// vez. Parecido com o F2, mas na vertical em vez de "todas as
	// ocorrências da palavra".
	BlockActive    bool // true enquanto ainda está só marcando (antes de digitar)
	BlockEditing   bool // true depois que já começou a digitar (linhas/colunas travadas)
	BlockAnchorY   int  // linha onde a marcação começou
	BlockAnchorX   int  // coluna onde a marcação começou
	BlockRowStart  int  // linha inicial do retângulo (travada ao começar a editar)
	BlockRowEnd    int  // linha final do retângulo (inclusive)
	BlockColWidth  int  // largura da faixa de colunas marcada (0 = só um ponto de inserção)
	BlockTyped     string
	BlockOrigLines []string
	BlockPaneBuf   int

	// Destaque do termo buscado (Ctrl+F / F3) — persiste até a próxima
	// busca, editar algo, ou Esc.
	SearchHighlightActive bool
	SearchHighlightBuf    int
	SearchHighlightY      int
	SearchHighlightX0     int
	SearchHighlightX1     int

	// Tela de ajuda (F1) — lista de atalhos, com rolagem.
	HelpActive bool
	HelpScroll int

	// Menu de contexto (botão direito do mouse, ou teclado — ver
	// handleContextMenuKey) — usado tanto nas abas do editor quanto no
	// título da sidebar.
	ContextMenuActive bool
	ContextMenuX      int // canto superior esquerdo do menu, em coluna de tela
	ContextMenuY      int
	ContextMenuItems  []ContextMenuItem
	ContextMenuIndex  int // item destacado (navegação por seta/Enter, sem precisar de mouse)

	// Redimensionamento da sidebar por arrasto do mouse na divisória.
	ResizingSidebar bool

	// Layout guarda onde cada elemento foi desenhado no último Render(),
	// pra HandleMouse saber o que está embaixo de um clique.
	Layout RenderLayout
}

// ContextMenuItem é uma opção do menu de contexto (botão direito).
type ContextMenuItem struct {
	Label  string
	Action func(a *App)
}

// OpenContextMenu abre o menu de contexto na posição dada, com os itens
// passados. Fecha qualquer menu que já estivesse aberto antes.
func (a *App) OpenContextMenu(x, y int, items []ContextMenuItem) {
	a.ContextMenuActive = true
	a.ContextMenuX = x
	a.ContextMenuY = y
	a.ContextMenuItems = items
	a.ContextMenuIndex = 0
}

// CloseContextMenu fecha o menu de contexto sem executar nada.
func (a *App) CloseContextMenu() {
	a.ContextMenuActive = false
	a.ContextMenuItems = nil
}

// PaneLayout é a área ocupada por um painel na última renderização.
type PaneLayout struct {
	BufIdx            int
	X, TabY           int // coluna inicial do painel; linha da barra de abas
	TextTop, TextX    int // linha onde o texto começa; coluna onde o texto começa (depois do gutter)
	Width, TextHeight int
	Gutter            int
	TabRanges         []TabRange // faixas de coluna [X0,X1) de cada aba desenhada, pra saber em qual clicou
}

// TabRange é a faixa horizontal ocupada pelo rótulo de uma aba na barra de abas.
type TabRange struct {
	BufIdx           int
	X0, X1           int
	CloseX0, CloseX1 int // faixa do "x" de fechar, dentro da aba
}

// RenderLayout é o layout inteiro da última tela desenhada.
type RenderLayout struct {
	SidebarX0, SidebarY0, SidebarX1, SidebarY1 int
	SidebarVisible                             bool
	SidebarRowY0                               int // linha da primeira entrada da lista (depois do cabeçalho)
	SidebarCloseX0, SidebarCloseX1             int // faixa do "x" de fechar no título da sidebar
	SidebarBorderX                             int // coluna da divisória (│) entre a sidebar e o texto — arrastável
	Panes                                      []PaneLayout
}

// NewApp cria o app com um buffer inicial (arquivo passado por argumento, ou vazio).
func NewApp(screen tcell.Screen, initialPaths []string) *App {
	a := &App{
		Screen:        screen,
		ShowSidebar:   len(initialPaths) == 0, // sem arquivo: abre com a sidebar; com arquivo: como já era
		SidebarWidth:  28,
		Settings:      config.LoadSettings(),
		Positions:     config.LoadPositions(),
		SearchHistory: config.LoadSearchHistory(),
	}

	var buf *buffer.Buffer
	if len(initialPaths) > 0 {
		b, err := buffer.Open(initialPaths[0])
		if err != nil {
			buf = buffer.New()
			a.SetStatusMsg(fmt.Sprintf("erro ao abrir %s: %v", initialPaths[0], err))
		} else {
			a.restorePosition(b)
			buf = b
		}
	} else {
		buf = buffer.New()
	}
	a.Buffers = append(a.Buffers, buf)
	a.Panes = []int{0}

	// arquivos extras (ex: "goedit *.sh" expandido pelo shell em vários
	// argumentos) abrem como abas a mais, sem tirar o foco do primeiro.
	var openErrs []string
	for i := 1; i < len(initialPaths); i++ {
		p := initialPaths[i]
		b, err := buffer.Open(p)
		if err != nil {
			openErrs = append(openErrs, p)
			continue
		}
		a.restorePosition(b)
		a.Buffers = append(a.Buffers, b)
	}
	if len(openErrs) > 0 {
		a.SetStatusMsg(fmt.Sprintf("erro ao abrir: %s", strings.Join(openErrs, ", ")))
	}
	a.Panes[0] = 0 // garante que o primeiro arquivo passado fica ativo, não o último aberto

	cwd, _ := os.Getwd()
	if len(initialPaths) > 0 {
		if abs, err := filepath.Abs(filepath.Dir(initialPaths[0])); err == nil {
			cwd = abs
		}
	}
	a.SidebarPath = cwd
	a.reloadSidebar()
	a.SidebarFocused = a.ShowSidebar // já abre navegável quando começa visível

	a.Plugins = plugin.NewManager(a, config.PluginDir())
	if errs := a.Plugins.LoadAll(); len(errs) > 0 {
		a.SetStatusMsg(fmt.Sprintf("erro carregando plugin: %v", errs[0]))
	}

	return a
}

// copyToClipboard grava o texto no clipboard interno do goedit e tenta
// também no clipboard do sistema (via wl-copy) — usado em todo lugar
// que copia ou corta algo, pra manter os dois sincronizados.
// statusMsgDuration é quanto tempo uma mensagem de status (ex: "salvo")
// fica visível na barra de status antes de sumir sozinha.
const statusMsgDuration = 3 * time.Second

// SetStatusMsg mostra uma mensagem na barra de status por um tempo
// limitado — depois disso ela some sozinha e a barra volta a mostrar
// nome do arquivo/tipo normalmente, mesmo sem nenhuma tecla ser
// apertada nesse meio tempo (agenda um evento pra acordar o loop
// principal e forçar um redesenho na hora certa).
func (a *App) SetStatusMsg(msg string) {
	a.StatusMsg = msg
	a.StatusMsgExpiry = time.Now().Add(statusMsgDuration)
	if a.Screen != nil {
		time.AfterFunc(statusMsgDuration+50*time.Millisecond, func() {
			a.Screen.PostEvent(tcell.NewEventInterrupt(nil))
		})
	}
}

// pageHeight devolve a altura de texto visível do painel ativo — pro
// Page Up/Down rolarem exatamente uma tela cheia, igual o nano faz,
// em vez de um número fixo que não bate com o tamanho real do
// terminal. Cai pra um valor razoável se o layout ainda não tiver
// sido calculado nenhuma vez (não deveria acontecer na prática: o
// primeiro Render() roda antes do laço principal de eventos, em
// main.go).
// cyclableKeymaps são os perfis que o F9 alterna — só os que já têm
// teclas implementadas (vim/emacs ficam de fora por enquanto).
var cyclableKeymaps = []string{"vscode", "nano", "nano-hibrido"}

// CycleKeymap troca pro próximo perfil de teclado da lista (F9) e
// salva a escolha em ~/.config/goedit/settings.json, pra persistir
// entre sessões sem precisar editar o arquivo na mão.
func (a *App) CycleKeymap() {
	cur := -1
	for i, k := range cyclableKeymaps {
		if k == a.Settings.Keymap {
			cur = i
			break
		}
	}
	next := cyclableKeymaps[(cur+1)%len(cyclableKeymaps)]
	a.Settings.Keymap = next
	if err := config.SaveSettings(a.Settings); err != nil {
		a.SetStatusMsg("perfil de teclas: " + next + " (não salvou no settings.json: " + err.Error() + ")")
		return
	}
	a.SetStatusMsg("perfil de teclas: " + next)
}

func (a *App) pageHeight() int {
	if a.ActivePane < len(a.Layout.Panes) {
		if h := a.Layout.Panes[a.ActivePane].TextHeight; h > 0 {
			return h
		}
	}
	return 20
}

func (a *App) copyToClipboard(text string) {
	a.Clipboard = text
	sysclip.Copy(text)
}

// pasteFromClipboard devolve o texto a colar: tenta o clipboard do
// sistema primeiro (via wl-paste), pra pegar coisa copiada de fora do
// goedit também; se não conseguir (ferramenta ausente, sem compositor
// Wayland, ou clipboard do sistema vazio), cai pro clipboard interno.
func (a *App) pasteFromClipboard() string {
	if text, ok := sysclip.Paste(); ok && text != "" {
		return text
	}
	return a.Clipboard
}

// restorePosition posiciona o cursor de um buffer recém-aberto na
// última posição salva pra esse arquivo (se houver), com os limites
// corrigidos pro conteúdo atual — o arquivo pode ter mudado de tamanho
// desde a última vez.
func (a *App) restorePosition(b *buffer.Buffer) {
	if b.Path == "" {
		return
	}
	abs, err := filepath.Abs(b.Path)
	if err != nil {
		return
	}
	pos, ok := a.Positions[abs]
	if !ok {
		return
	}
	y := pos.Line
	if y < 0 {
		y = 0
	}
	if y >= len(b.Lines) {
		y = len(b.Lines) - 1
	}
	x := pos.Col
	if x < 0 {
		x = 0
	}
	if x > len(b.Lines[y]) {
		x = len(b.Lines[y])
	}
	b.CursorY, b.CursorX = y, x
}

// recordPosition guarda a posição atual do cursor de um buffer no mapa
// em memória (não grava em disco ainda — ver persistPositions).
func (a *App) recordPosition(b *buffer.Buffer) {
	if b.Path == "" {
		return
	}
	abs, err := filepath.Abs(b.Path)
	if err != nil {
		return
	}
	if a.Positions == nil {
		a.Positions = map[string]config.Position{}
	}
	a.Positions[abs] = config.Position{Line: b.CursorY, Col: b.CursorX}
}

// persistPositions grava o mapa de posições em disco. Erros são
// silenciosos — perder a posição salva não é grave o bastante pra
// atrapalhar o fluxo de fechar um arquivo ou sair do editor.
func (a *App) persistPositions() {
	_ = config.SavePositions(a.Positions)
}

// SaveAllOpenPositions grava a posição atual de todos os buffers com
// arquivo aberto (ignora buffers "sem nome") — chamado ao sair do
// editor inteiro, pra não perder a posição de nenhuma aba.
func (a *App) SaveAllOpenPositions() {
	for _, b := range a.Buffers {
		a.recordPosition(b)
	}
	a.persistPositions()
}

// ActiveBuffer devolve o buffer mostrado no painel com foco.
func (a *App) ActiveBuffer() *buffer.Buffer {
	return a.Buffers[a.Panes[a.ActivePane]]
}

// parentDirEntry é uma entrada sintética ".." que aparece no topo da
// listagem da sidebar (quando não estamos na raiz do sistema de
// arquivos), pra dar um jeito óbvio e clicável de voltar pra pasta
// anterior — sem isso, só dava pra voltar com Backspace, o que não é
// nada óbvio de descobrir.
type parentDirEntry struct{}

func (parentDirEntry) Name() string               { return ".." }
func (parentDirEntry) IsDir() bool                { return true }
func (parentDirEntry) Type() os.FileMode          { return os.ModeDir }
func (parentDirEntry) Info() (os.FileInfo, error) { return nil, nil }

func (a *App) reloadSidebar() {
	entries, err := os.ReadDir(a.SidebarPath)
	if err != nil {
		a.SidebarEntries = nil
		return
	}
	sort.Slice(entries, func(i, j int) bool {
		di, dj := entries[i].IsDir(), entries[j].IsDir()
		if di != dj {
			return di // diretórios primeiro
		}
		return entries[i].Name() < entries[j].Name()
	})
	if filepath.Dir(a.SidebarPath) != a.SidebarPath {
		// não estamos na raiz ("/" já é o próprio pai dela mesma)
		full := make([]os.DirEntry, 0, len(entries)+1)
		full = append(full, parentDirEntry{})
		full = append(full, entries...)
		entries = full
	}
	a.SidebarEntries = entries
	if a.SidebarSel >= len(a.SidebarEntries) {
		a.SidebarSel = 0
	}
	a.SidebarOffset = 0
}

// openSidebarEntry abre a entrada selecionada: entra na pasta (ou volta
// pra pasta anterior, se for a entrada ".."), ou abre o arquivo. Usado
// tanto pelo Enter do teclado quanto pelo clique do mouse, pra manter
// os dois com o mesmo comportamento.
func (a *App) openSidebarEntry(e os.DirEntry) {
	if e.Name() == ".." {
		a.SidebarPath = filepath.Dir(a.SidebarPath)
		a.SidebarSel = 0
		a.reloadSidebar()
		return
	}
	full := filepath.Join(a.SidebarPath, e.Name())
	if e.IsDir() {
		a.SidebarPath = full
		a.SidebarSel = 0
		a.reloadSidebar()
	} else {
		a.OpenFile(full)
		a.SidebarFocused = false
	}
}
func (a *App) OpenFile(path string) {
	for i, b := range a.Buffers {
		if b.Path == path {
			a.Panes[a.ActivePane] = i
			return
		}
	}
	b, err := buffer.Open(path)
	if err != nil {
		a.SetStatusMsg(fmt.Sprintf("erro ao abrir %s: %v", path, err))
		return
	}
	a.restorePosition(b)
	a.Buffers = append(a.Buffers, b)
	a.Panes[a.ActivePane] = len(a.Buffers) - 1
}

// NewBuffer cria uma aba nova vazia.
func (a *App) NewBuffer() {
	a.Buffers = append(a.Buffers, buffer.New())
	a.Panes[a.ActivePane] = len(a.Buffers) - 1
}

// closeTabViaX trata o fechamento de uma aba pelo "x" (mouse) ou pelo
// Ctrl+W (teclado) — mesma lógica pros dois, pra funcionar igual com ou
// sem mouse (TTY puro sem X11/Wayland). Se houver outras abas abertas,
// comportamento normal (fecha só essa aba). Se for a única aba (o
// goedit inteiro fecharia de qualquer forma): sem alteração no
// conteúdo, fecha direto; com alteração, pergunta se quer salvar antes
// (menu navegável por teclado — seta/Enter — ou mouse) e só fecha
// depois da escolha.
func (a *App) closeTabViaX(idx, menuX, menuY int) {
	if idx < 0 || idx >= len(a.Buffers) {
		return
	}
	if len(a.Buffers) > 1 {
		a.CloseBufferAt(idx)
		return
	}
	b := a.Buffers[idx]
	if !b.Dirty {
		a.Quit = true
		return
	}
	a.OpenContextMenu(menuX, menuY, []ContextMenuItem{
		{Label: "Salvar e fechar", Action: func(a *App) {
			if b.Path == "" {
				a.startPrompt("Salvar como: ", func(path string) {
					if path == "" {
						return // cancelou — não fecha
					}
					if err := b.SaveAs(path); err != nil {
						a.SetStatusMsg("erro ao salvar: " + err.Error())
						return
					}
					a.SetStatusMsg("salvo em " + path)
					a.Quit = true
				}, nil)
				return
			}
			if err := b.Save(); err != nil {
				a.SetStatusMsg("erro ao salvar: " + err.Error())
				return
			}
			a.Quit = true
		}},
		{Label: "Fechar sem salvar", Action: func(a *App) {
			a.Quit = true
		}},
	})
}

// closeActiveTabWithConfirm é a versão de closeTabViaX pro teclado
// (Ctrl+W) — acha a posição da aba ativa no último layout desenhado
// pra abrir o menu (se precisar) bem perto dela; se não achar por
// algum motivo, usa uma posição padrão razoável.
func (a *App) closeActiveTabWithConfirm() {
	idx := a.Panes[a.ActivePane]
	menuX, menuY := 2, 1
	if a.ActivePane < len(a.Layout.Panes) {
		pl := a.Layout.Panes[a.ActivePane]
		for _, tr := range pl.TabRanges {
			if tr.BufIdx == idx {
				menuX, menuY = tr.CloseX0, pl.TabY+1
				break
			}
		}
	}
	a.closeTabViaX(idx, menuX, menuY)
}

// CloseActiveBuffer fecha a aba ativa do painel focado.
func (a *App) CloseActiveBuffer() {
	a.CloseBufferAt(a.Panes[a.ActivePane])
}

// CloseBufferAt fecha o buffer no índice dado (usado tanto pelo Ctrl+W
// quanto pelo menu de contexto das abas, que pode fechar uma aba
// diferente da que está ativa no momento).
func (a *App) CloseBufferAt(idx int) {
	if idx < 0 || idx >= len(a.Buffers) {
		return
	}
	a.recordPosition(a.Buffers[idx])
	a.persistPositions()
	if len(a.Buffers) == 1 {
		a.Buffers[0] = buffer.New()
		return
	}
	a.Buffers = append(a.Buffers[:idx], a.Buffers[idx+1:]...)
	for i := range a.Panes {
		if a.Panes[i] >= len(a.Buffers) {
			a.Panes[i] = len(a.Buffers) - 1
		} else if a.Panes[i] > idx {
			a.Panes[i]--
		}
	}
}

// CloseOtherBuffersAt fecha todos os buffers menos o do índice dado.
func (a *App) CloseOtherBuffersAt(idx int) {
	if idx < 0 || idx >= len(a.Buffers) {
		return
	}
	keep := a.Buffers[idx]
	for i, b := range a.Buffers {
		if i != idx {
			a.recordPosition(b)
		}
	}
	a.persistPositions()
	a.Buffers = []*buffer.Buffer{keep}
	for i := range a.Panes {
		a.Panes[i] = 0
	}
}

// CloseAllBuffers fecha todas as abas, voltando pra um único buffer novo.
func (a *App) CloseAllBuffers() {
	for _, b := range a.Buffers {
		a.recordPosition(b)
	}
	a.persistPositions()
	a.Buffers = []*buffer.Buffer{buffer.New()}
	for i := range a.Panes {
		a.Panes[i] = 0
	}
}

// SaveBufferAt salva o buffer no índice dado (troca o foco pra ele
// primeiro, já que o fluxo de salvar-como usa o buffer ativo).
func (a *App) SaveBufferAt(idx int) {
	if idx < 0 || idx >= len(a.Buffers) {
		return
	}
	a.Panes[a.ActivePane] = idx
	a.doSave()
}

// NextTab avança pra próxima aba no painel ativo.
func (a *App) NextTab() {
	idx := a.Panes[a.ActivePane]
	idx = (idx + 1) % len(a.Buffers)
	a.Panes[a.ActivePane] = idx
}

// PrevTab volta pra aba anterior no painel ativo.
func (a *App) PrevTab() {
	idx := a.Panes[a.ActivePane]
	idx = (idx - 1 + len(a.Buffers)) % len(a.Buffers)
	a.Panes[a.ActivePane] = idx
}

// ToggleSplit ativa ou desativa o segundo painel.
func (a *App) ToggleSplit() {
	if len(a.Panes) == 1 {
		a.Panes = append(a.Panes, a.Panes[0])
	} else {
		a.Panes = a.Panes[:1]
		a.ActivePane = 0
	}
}

// SwitchPaneFocus alterna o foco entre os painéis abertos.
func (a *App) SwitchPaneFocus() {
	if len(a.Panes) < 2 {
		return
	}
	a.ActivePane = (a.ActivePane + 1) % len(a.Panes)
}

// startPrompt abre uma caixa de entrada na barra inferior.
func (a *App) startPrompt(label string, onSubmit func(string), onCancel func()) {
	a.PromptActive = true
	a.PromptLabel = label
	a.PromptInput = ""
	a.PromptIsSearch = false // só startSearchPrompt liga isso de novo
	a.onSubmit = onSubmit
	a.onCancel = onCancel
}

// startSearchPrompt abre o prompt de busca com suporte a histórico —
// ↑/↓ navegam buscas anteriores (ver handlePromptKey). Usado pelos
// atalhos que abrem busca (Ctrl+F em vscode, Ctrl+W em
// nano/nano-híbrido) em vez de startPrompt direto.
func (a *App) startSearchPrompt() {
	a.startPrompt("Buscar: ", func(input string) {
		if input != "" {
			a.commitSearchHistory(input)
		}
		a.LastSearch = input
		a.doFind(false)
	}, nil)
	a.PromptIsSearch = true
	a.searchHistoryPos = len(a.SearchHistory)
}

// commitSearchHistory adiciona um termo buscado ao histórico (se for
// diferente do último) e salva em disco na hora — histórico de busca
// não é algo que vale a pena perder se o programa fechar sem avisar.
func (a *App) commitSearchHistory(term string) {
	if len(a.SearchHistory) > 0 && a.SearchHistory[len(a.SearchHistory)-1] == term {
		return
	}
	a.SearchHistory = append(a.SearchHistory, term)
	_ = config.SaveSearchHistory(a.SearchHistory)
}

func (a *App) cancelPrompt() {
	a.PromptActive = false
	if a.onCancel != nil {
		a.onCancel()
	}
}

func (a *App) submitPrompt() {
	a.PromptActive = false
	if a.onSubmit != nil {
		a.onSubmit(a.PromptInput)
	}
}
