/*
   goedit
   Editor de texto para terminal (TUI), com realce de sintaxe, plugins Lua, seleção em bloco e mais
   Site:      https://chililinux.com
   Site:      https://voidbr.org
   Site:      https://voidlinux.com.br
   GitHub:    https://github.com/voidlinuxbr/voidbr-goedit
   Created:   dom 16 ago 2026 10:15:33 -04
   Updated:   sex 21 ago 2026 11:30:00 -04
   Version:   0.31.0
   Copyright (C) 2019-2026 Vilmar Catafesta <vcatafesta@gmail.com>
*/

package ui

import (
	"github.com/gdamore/tcell/v2"
)

// mouseDragging indica se o botão esquerdo está sendo segurado desde um
// clique anterior no texto — usado pra saber se um movimento de mouse com
// botão pressionado deve estender a seleção.
var mouseDragging bool

// --- Entrada principal ---

// HandleMouse processa clique, arrasto e roda do mouse. Ordem de
// despacho: arrasto de redimensionamento em andamento tem prioridade
// total (captura o mouse até soltar); depois o menu de contexto, se
// estiver aberto; depois clique direito (abre menu); depois roda;
// depois clique na sidebar; por fim clique em aba/texto de algum painel.
func (a *App) HandleMouse(ev *tcell.EventMouse) {
	if a.PromptActive {
		return // prompts não reagem a mouse por enquanto
	}
	if a.HelpActive {
		helpBtn := ev.Buttons()
		switch {
		case helpBtn&tcell.WheelUp != 0:
			if a.HelpScroll > 0 {
				a.HelpScroll--
			}
		case helpBtn&tcell.WheelDown != 0:
			a.HelpScroll++
		case helpBtn&tcell.Button1 != 0:
			a.HelpActive = false // clique (não rolagem) fecha a ajuda
		}
		return
	}
	a.SuggestActive = false // qualquer interação de mouse cancela sugestão pendente
	if a.BlockActive {
		a.cancelBlockSelect() // mouse também cancela a seleção em bloco pendente
	}

	x, y := ev.Position()
	btn := ev.Buttons()

	if a.ResizingSidebar {
		a.continueResizeSidebar(x, btn)
		return
	}

	if a.ContextMenuActive {
		a.handleContextMenuClick(x, y, btn)
		return
	}

	if btn&tcell.Button2 != 0 { // botão direito: abre menu de contexto
		a.handleRightClick(x, y)
		return
	}

	if delta, ok := wheelDelta(btn); ok {
		a.handleWheel(x, y, delta)
		return
	}

	if a.pointInSidebar(x, y) {
		a.handleSidebarClick(x, y, btn)
		return
	}

	if btn&tcell.Button1 != 0 && a.Layout.SidebarVisible && x == a.Layout.SidebarBorderX {
		a.ResizingSidebar = true
		return
	}

	a.handlePaneClick(x, y, btn, ev.Modifiers()&tcell.ModShift != 0)
}

// wheelDelta traduz o estado dos botões num delta de rolagem (+3 pra
// baixo, -3 pra cima), ou ok=false se o evento não é de roda.
func wheelDelta(btn tcell.ButtonMask) (delta int, ok bool) {
	switch {
	case btn&tcell.WheelUp != 0:
		return -3, true
	case btn&tcell.WheelDown != 0:
		return 3, true
	default:
		return 0, false
	}
}

// handleWheel rola a sidebar se o ponteiro estiver em cima dela, senão
// rola o painel de texto sob o ponteiro.
func (a *App) handleWheel(x, y, delta int) {
	if a.scrollSidebarAt(x, y, delta) {
		return
	}
	a.scrollPaneAt(x, y, delta)
}

// pointInSidebar diz se a coordenada de tela cai dentro da área visível
// da sidebar (usado pra clique, roda do mouse e início do redimensionamento).
func (a *App) pointInSidebar(x, y int) bool {
	return a.Layout.SidebarVisible &&
		x >= a.Layout.SidebarX0 && x < a.Layout.SidebarX1 &&
		y >= a.Layout.SidebarY0 && y < a.Layout.SidebarY1
}

// --- Redimensionamento da sidebar por arrasto ---

// continueResizeSidebar atualiza a largura da sidebar enquanto o botão
// segue pressionado, e encerra o arrasto quando o botão é solto.
func (a *App) continueResizeSidebar(x int, btn tcell.ButtonMask) {
	if btn&tcell.Button1 == 0 {
		a.ResizingSidebar = false
		return
	}
	const minWidth, maxWidth = 12, 80
	a.SidebarWidth = clamp(x, minWidth, maxWidth)
}

// --- Menu de contexto ---

// handleRightClick decide qual menu abrir (se algum) de acordo com o que
// está embaixo do clique direito: título da sidebar, uma aba, ou o
// texto principal de algum painel.
func (a *App) handleRightClick(x, y int) {
	if a.Layout.SidebarVisible && a.pointInSidebar(x, y) && y == a.Layout.SidebarY0 {
		a.OpenContextMenu(x, y+1, a.sidebarContextMenuItems())
		return
	}
	for i, pl := range a.Layout.Panes {
		if x < pl.X || x >= pl.X+pl.Width {
			continue
		}
		if y == pl.TabY {
			for _, tr := range pl.TabRanges {
				if x >= tr.X0 && x < tr.X1 {
					a.OpenContextMenu(x, y+1, a.tabContextMenuItems(tr.BufIdx))
					return
				}
			}
			return
		}
		if y >= pl.TextTop && y < pl.TextTop+pl.TextHeight {
			a.ActivePane = i
			a.rightClickInText(pl, x, y)
			a.OpenContextMenu(x, y+1, a.textContextMenuItems())
			return
		}
	}
}

// rightClickInText posiciona o cursor no ponto do clique direito, a não
// ser que o clique tenha caído dentro de uma seleção já existente — nesse
// caso mantém a seleção intacta, pra Copiar/Cortar poderem usar ela
// (igual a maioria dos editores gráficos faz).
func (a *App) rightClickInText(pl PaneLayout, x, y int) {
	b := a.Buffers[pl.BufIdx]
	if b.Selecting {
		lineIdx := clamp(b.OffsetY+(y-pl.TextTop), 0, len(b.Lines)-1)
		tabWidth := a.Settings.TabWidth
		if tabWidth <= 0 {
			tabWidth = 4
		}
		targetVCol := b.OffsetX + (x - pl.TextX)
		if targetVCol < 0 {
			targetVCol = 0
		}
		col := byteIndexForVisualCol(b.Lines[lineIdx], targetVCol, tabWidth)
		sy, sx, ey, ex := selectionRange(b.SelStartY, b.SelStartX, b.CursorY, b.CursorX)
		if inSelection(lineIdx, col, sy, sx, ey, ex) {
			return // clique dentro da seleção: preserva ela
		}
	}
	mouseDragging = false
	a.clickText(pl, x, y, false)
}

// textContextMenuItems monta as opções do menu de contexto do texto
// principal — copiar segue o mesmo comportamento do Ctrl+C, cortar do
// Alt+X (linha atual inteira, se não houver seleção).
func (a *App) textContextMenuItems() []ContextMenuItem {
	return []ContextMenuItem{
		{Label: "Copiar          Ctrl+C", Action: func(a *App) {
			b := a.ActiveBuffer()
			if b.Selecting {
				a.copyToClipboard(b.SelectedText())
			} else {
				a.copyToClipboard(b.Lines[b.CursorY] + "\n")
			}
		}},
		{Label: "Cortar          Alt+X", Action: func(a *App) {
			b := a.ActiveBuffer()
			if b.Selecting {
				a.copyToClipboard(b.SelectedText())
				b.DeleteSelection()
			} else {
				a.copyToClipboard(b.Lines[b.CursorY] + "\n")
				b.DeleteLine()
			}
		}},
		{Label: "Colar           Ctrl+V", Action: func(a *App) {
			if text := a.pasteFromClipboard(); text != "" {
				a.ActiveBuffer().InsertTextAtCursor(text)
			}
		}},
		{Label: "Selecionar tudo Ctrl+A", Action: func(a *App) {
			a.ActiveBuffer().SelectAll()
		}},
		{Label: "Formatar código Shift+Alt+F", Action: func(a *App) {
			a.FormatActiveBuffer()
		}},
	}
}

// tabContextMenuItems monta as opções do menu de contexto de uma aba.
func (a *App) tabContextMenuItems(bufIdx int) []ContextMenuItem {
	return []ContextMenuItem{
		{Label: "Fechar          Ctrl+W", Action: func(a *App) { a.CloseBufferAt(bufIdx) }},
		{Label: "Fechar outras", Action: func(a *App) { a.CloseOtherBuffersAt(bufIdx) }},
		{Label: "Fechar todas", Action: func(a *App) { a.CloseAllBuffers() }},
		{Label: "Salvar          Ctrl+S", Action: func(a *App) { a.SaveBufferAt(bufIdx) }},
	}
}

// sidebarContextMenuItems monta as opções do menu de contexto do título
// da sidebar.
func (a *App) sidebarContextMenuItems() []ContextMenuItem {
	return []ContextMenuItem{
		{Label: "Fechar    Ctrl+B", Action: func(a *App) {
			a.ShowSidebar = false
			a.SidebarFocused = false
		}},
		{Label: "Atualizar", Action: func(a *App) { a.reloadSidebar() }},
	}
}

// handleContextMenuClick resolve um clique enquanto o menu de contexto
// está aberto: clicar num item executa a ação dele; clicar em qualquer
// outro lugar só fecha o menu, sem fazer nada.
func (a *App) handleContextMenuClick(x, y int, btn tcell.ButtonMask) {
	if btn&tcell.Button1 == 0 {
		return // só reage a clique de verdade (press), não a soltura
	}
	mx, my, mw, _ := a.contextMenuBox()
	row := y - my
	if row >= 0 && row < len(a.ContextMenuItems) && x >= mx && x < mx+mw {
		action := a.ContextMenuItems[row].Action
		a.CloseContextMenu()
		if action != nil {
			action(a)
		}
		return
	}
	a.CloseContextMenu()
}

// --- Sidebar: clique normal (fora do menu de contexto) ---

// handleSidebarClick trata clique esquerdo em qualquer parte da sidebar:
// o "x" de fechar no título, ou uma entrada da lista de arquivos.
func (a *App) handleSidebarClick(x, y int, btn tcell.ButtonMask) {
	if btn&tcell.Button1 == 0 {
		return
	}
	if y == a.Layout.SidebarY0 && a.Layout.SidebarCloseX0 >= 0 &&
		x >= a.Layout.SidebarCloseX0 && x < a.Layout.SidebarCloseX1 {
		a.ShowSidebar = false
		a.SidebarFocused = false
		return
	}
	a.clickSidebar(y)
}

// clickSidebar seleciona e abre a entrada clicada. Abrir um arquivo pelo
// mouse funciona igual ao Enter do teclado: abre numa aba e mantém a
// sidebar aberta (só perde o foco) — ela só fecha de verdade quando o
// usuário aperta Ctrl+B (ou o "x" do título) de novo, nunca sozinha por
// causa de um clique num arquivo.
func (a *App) clickSidebar(y int) {
	idx := a.SidebarOffset + (y - a.Layout.SidebarRowY0)
	if idx < 0 || idx >= len(a.SidebarEntries) {
		return
	}
	a.SidebarSel = idx
	a.SidebarFocused = true
	a.openSidebarEntry(a.SidebarEntries[idx])
}

// scrollSidebarAt rola a lista de arquivos da sidebar quando o mouse está
// em cima dela. Devolve false se o ponteiro não está sobre a sidebar (pra
// o chamador tentar rolar o painel de texto em vez disso).
func (a *App) scrollSidebarAt(x, y, delta int) bool {
	if !a.pointInSidebar(x, y) {
		return false
	}
	a.SidebarSel = clamp(a.SidebarSel+delta, 0, len(a.SidebarEntries)-1)
	return true
}

// --- Abas e texto ---

// handlePaneClick trata clique/arrasto/soltura de botão esquerdo dentro
// de algum painel de edição (aba ou texto).
func (a *App) handlePaneClick(x, y int, btn tcell.ButtonMask, extendSelection bool) {
	for i, pl := range a.Layout.Panes {
		if x < pl.X || x >= pl.X+pl.Width {
			continue
		}
		if btn&tcell.Button1 == 0 {
			// botão solto: encerra o arrasto de seleção, se houver
			mouseDragging = false
			return
		}

		a.ActivePane = i
		a.SidebarFocused = false

		if y == pl.TabY {
			a.clickTabAt(pl, x)
			mouseDragging = false
			return
		}
		if y >= pl.TextTop && y < pl.TextTop+pl.TextHeight {
			a.clickText(pl, x, y, extendSelection)
			return
		}
		return
	}
}

func (a *App) clickTabAt(pl PaneLayout, x int) {
	for _, tr := range pl.TabRanges {
		if x >= tr.CloseX0 && x < tr.CloseX1 {
			a.closeTabViaX(tr.BufIdx, x, pl.TabY+1)
			return
		}
		if x >= tr.X0 && x < tr.X1 {
			a.Panes[a.ActivePane] = tr.BufIdx
			return
		}
	}
}

// closeTabViaX trata o clique no "x" de fechar de uma aba. Se houver
// outras abas abertas, comportamento normal (fecha só essa aba). Se for
// a única aba (o goedit inteiro fecharia de qualquer forma): sem
// alteração no conteúdo, fecha direto; com alteração, pergunta se quer
// salvar antes (menu com duas opções) e só fecha depois da escolha.
// clickText posiciona o cursor (ou estende a seleção) na posição de
// texto correspondente à coordenada de tela clicada, considerando
// scroll horizontal/vertical e largura de tabulação.
func (a *App) clickText(pl PaneLayout, x, y int, extendSelection bool) {
	b := a.Buffers[pl.BufIdx]

	lineIdx := clamp(b.OffsetY+(y-pl.TextTop), 0, len(b.Lines)-1)

	tabWidth := a.Settings.TabWidth
	if tabWidth <= 0 {
		tabWidth = 4
	}
	targetVCol := b.OffsetX + (x - pl.TextX)
	if targetVCol < 0 {
		targetVCol = 0
	}
	col := byteIndexForVisualCol(b.Lines[lineIdx], targetVCol, tabWidth)

	if extendSelection || mouseDragging {
		if !b.Selecting {
			// início de um arrasto nunca marcado: ancora na posição
			// atual do cursor antes de mover
			b.StartSelection()
		}
	} else {
		b.ClearSelection()
	}
	b.CursorY = lineIdx
	b.CursorX = col
	mouseDragging = true
}

// scrollPaneAt rola o painel de texto sob o cursor do mouse, movendo o
// cursor junto (o auto-scroll da renderização segue a posição do cursor,
// então não dá pra rolar a viewport sem mover o cursor também neste
// editor) — o cursor fica sempre na mesma linha de tela onde o ponteiro
// está, não foge pras extremidades.
func (a *App) scrollPaneAt(x, y, delta int) {
	for i, pl := range a.Layout.Panes {
		if x < pl.X || x >= pl.X+pl.Width {
			continue
		}
		if y < pl.TextTop || y >= pl.TextTop+pl.TextHeight {
			continue
		}
		b := a.Buffers[pl.BufIdx]
		b.ClearSelection()

		mouseLineIdx := b.OffsetY + (y - pl.TextTop)

		maxOffset := len(b.Lines) - pl.TextHeight
		if maxOffset < 0 {
			maxOffset = 0
		}
		b.OffsetY = clamp(b.OffsetY+delta, 0, maxOffset)
		b.CursorY = clamp(mouseLineIdx+delta, 0, len(b.Lines)-1)
		b.CursorX = 0

		a.ActivePane = i
		return
	}
}

// clamp restringe v ao intervalo [lo, hi]. Se hi < lo (ex: lista vazia,
// len-1 = -1), devolve lo.
func clamp(v, lo, hi int) int {
	if v < lo {
		return lo
	}
	if hi >= lo && v > hi {
		return hi
	}
	return v
}
