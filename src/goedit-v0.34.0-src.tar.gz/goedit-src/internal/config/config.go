/*
   goedit
   Editor de texto para terminal (TUI), com realce de sintaxe, plugins Lua, seleção em bloco e mais
   Site:      https://chililinux.com
   Site:      https://voidbr.org
   Site:      https://voidlinux.com.br
   GitHub:    https://github.com/voidlinuxbr/voidbr-goedit
   Created:   dom 16 ago 2026 10:15:33 -04
   Updated:   sex 21 ago 2026 11:30:00 -04
   Version:   0.34.0
   Copyright (C) 2019-2026 Vilmar Catafesta <vcatafesta@gmail.com>
*/

package config

import (
	"encoding/json"
	"os"
	"path/filepath"
)

// PluginDir devolve ~/.config/goedit/plugins, criando o diretório se preciso.
func PluginDir() string {
	home, err := os.UserHomeDir()
	if err != nil {
		return "plugins"
	}
	dir := filepath.Join(home, ".config", "goedit", "plugins")
	_ = os.MkdirAll(dir, 0o755)
	return dir
}

// Settings são as preferências configuráveis do editor.
// Ficam em ~/.config/goedit/settings.json — o arquivo não existe até o
// usuário criar um (LoadSettings devolve os padrões nesse caso).
type Settings struct {
	// TabWidth é quantas colunas uma tabulação ocupa na tela, e também
	// quantos espaços a tecla Tab insere quando InsertSpaces é true.
	TabWidth int `json:"tabWidth"`
	// InsertSpaces: true insere espaços ao apertar Tab (padrão da maioria
	// dos editores modernos); false insere um caractere de tabulação real.
	InsertSpaces bool `json:"insertSpaces"`
	// Keymap escolhe o "estilo" de atalhos de teclado do editor —
	// "vscode" (padrão), "nano", "vim" ou "emacs". Valor desconhecido
	// ou ausente cai pro padrão "vscode".
	Keymap string `json:"keymap"`
}

// ValidKeymaps lista os valores aceitos pra "keymap" no settings.json.
var ValidKeymaps = []string{"vscode", "nano", "nano-hibrido", "vim", "emacs"}

// rawSettings usa ponteiros pra distinguir "campo ausente no JSON" de
// "campo presente com valor zero" — um settings.json com só tabWidth não
// deve zerar insertSpaces sem querer.
type rawSettings struct {
	TabWidth     *int    `json:"tabWidth"`
	InsertSpaces *bool   `json:"insertSpaces"`
	Keymap       *string `json:"keymap"`
}

func defaultSettings() Settings {
	return Settings{TabWidth: 4, InsertSpaces: true, Keymap: "nano-hibrido"}
}

// settingsPath devolve ~/.config/goedit/settings.json.
func settingsPath() string {
	home, err := os.UserHomeDir()
	if err != nil {
		return "settings.json"
	}
	return filepath.Join(home, ".config", "goedit", "settings.json")
}

// LoadSettings lê ~/.config/goedit/settings.json. Se o arquivo não existir
// ou tiver erro de leitura/parse, devolve os padrões (TabWidth: 4,
// InsertSpaces: true) sem quebrar a inicialização do editor. Campos
// SaveSettings grava as configurações em ~/.config/goedit/settings.json
// — usado pra persistir mudanças feitas em tempo real (ex: trocar o
// perfil de teclado com F9), sem precisar editar o arquivo na mão.
func SaveSettings(s Settings) error {
	home, err := os.UserHomeDir()
	if err != nil {
		return err
	}
	dir := filepath.Join(home, ".config", "goedit")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return err
	}
	data, err := json.MarshalIndent(s, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(settingsPath(), data, 0o644)
}

// ausentes no JSON mantêm o valor padrão.
func LoadSettings() Settings {
	s := defaultSettings()
	data, err := os.ReadFile(settingsPath())
	if err != nil {
		return s
	}
	var raw rawSettings
	if err := json.Unmarshal(data, &raw); err != nil {
		return s
	}
	if raw.TabWidth != nil && *raw.TabWidth > 0 {
		s.TabWidth = *raw.TabWidth
	}
	if raw.InsertSpaces != nil {
		s.InsertSpaces = *raw.InsertSpaces
	}
	if raw.Keymap != nil {
		valid := false
		for _, k := range ValidKeymaps {
			if *raw.Keymap == k {
				valid = true
				break
			}
		}
		if valid {
			s.Keymap = *raw.Keymap
		}
	}
	return s
}

// --- Posição de cursor por arquivo (linha/coluna) ---

// Position é a última posição do cursor num arquivo, salva ao fechar
// (aba ou app) e restaurada ao reabrir o mesmo arquivo.
type Position struct {
	Line int `json:"line"`
	Col  int `json:"col"`
}

// positionsPath devolve ~/.config/goedit/positions.json.
func positionsPath() string {
	home, err := os.UserHomeDir()
	if err != nil {
		return "positions.json"
	}
	return filepath.Join(home, ".config", "goedit", "positions.json")
}

// LoadPositions lê ~/.config/goedit/positions.json (chave = caminho
// absoluto do arquivo). Se não existir ou der erro, devolve um mapa
// vazio sem quebrar a inicialização.
func LoadPositions() map[string]Position {
	positions := map[string]Position{}
	data, err := os.ReadFile(positionsPath())
	if err != nil {
		return positions
	}
	_ = json.Unmarshal(data, &positions) // erro de parse: só fica vazio mesmo
	return positions
}

// SavePositions grava o mapa inteiro de volta em
// ~/.config/goedit/positions.json — sobrescreve o arquivo, então quem
// chama precisa carregar (LoadPositions), atualizar as entradas que
// mudaram, e só então salvar o mapa completo.
func SavePositions(positions map[string]Position) error {
	home, err := os.UserHomeDir()
	if err != nil {
		return err
	}
	dir := filepath.Join(home, ".config", "goedit")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return err
	}
	data, err := json.MarshalIndent(positions, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(positionsPath(), data, 0o644)
}

// --- Histórico de busca ---

// searchHistoryMax é quantos termos ficam guardados no máximo — mais
// que isso e os mais antigos vão saindo (fila).
const searchHistoryMax = 50

func searchHistoryPath() string {
	home, err := os.UserHomeDir()
	if err != nil {
		return "search_history.json"
	}
	return filepath.Join(home, ".config", "goedit", "search_history.json")
}

// LoadSearchHistory lê ~/.config/goedit/search_history.json — do mais
// antigo pro mais recente. Se não existir ou der erro, devolve vazio
// sem quebrar a inicialização.
func LoadSearchHistory() []string {
	var history []string
	data, err := os.ReadFile(searchHistoryPath())
	if err != nil {
		return history
	}
	_ = json.Unmarshal(data, &history)
	return history
}

// SaveSearchHistory grava a lista inteira de volta — sobrescreve o
// arquivo, então quem chama precisa ter a lista completa (carregada +
// atualizada) antes de chamar. Corta os mais antigos se passar de
// searchHistoryMax.
func SaveSearchHistory(history []string) error {
	if len(history) > searchHistoryMax {
		history = history[len(history)-searchHistoryMax:]
	}
	home, err := os.UserHomeDir()
	if err != nil {
		return err
	}
	dir := filepath.Join(home, ".config", "goedit")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return err
	}
	data, err := json.MarshalIndent(history, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(searchHistoryPath(), data, 0o644)
}
