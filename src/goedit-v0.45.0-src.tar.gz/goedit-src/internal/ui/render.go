/*
   goedit
   Editor de texto para terminal (TUI), com realce de sintaxe, plugins Lua, seleção em bloco e mais
   Site:      https://chililinux.com
   Site:      https://voidbr.org
   Site:      https://voidlinux.com.br
   GitHub:    https://github.com/voidlinuxbr/voidbr-goedit
   Created:   dom 16 ago 2026 10:15:33 -04
   Updated:   ter 20 out 2026 21:27:16 -04
   Version:   0.45.0
   Copyright (C) 2019-2026 Vilmar Catafesta <vcatafesta@gmail.com>
*/

package ui

import (
	"fmt"
	"strings"
	"time"

	"github.com/gdamore/tcell/v2"
	"github.com/mattn/go-runewidth"

	"goedit/internal/buffer"
	"goedit/internal/markdown"
	"goedit/internal/syntax"
)

var (
	styleDefault       = tcell.StyleDefault
	styleStatus        = tcell.StyleDefault.Background(tcell.ColorDarkSlateGray).Foreground(tcell.ColorWhite)
	styleTabActive     = tcell.StyleDefault.Background(tcell.ColorSteelBlue).Foreground(tcell.ColorWhite).Bold(true)
	styleTabIdle       = tcell.StyleDefault.Background(tcell.ColorDarkSlateGray).Foreground(tcell.ColorLightGray)
	styleAppTitle      = tcell.StyleDefault.Background(tcell.ColorDarkSlateGray).Foreground(tcell.ColorWhite).Bold(true)
	styleSidebar       = tcell.StyleDefault.Foreground(tcell.ColorLightGray)
	styleSidebarSel    = tcell.StyleDefault.Background(tcell.ColorSteelBlue).Foreground(tcell.ColorWhite)
	styleSidebarSelDim = tcell.StyleDefault.Background(tcell.ColorDimGray).Foreground(tcell.ColorWhite)
	styleContextMenu   = tcell.StyleDefault.
				Background(tcell.NewRGBColor(0x24, 0x28, 0x3b)). // Tokyo Night: fundo do menu
				Foreground(tcell.NewRGBColor(0xc0, 0xca, 0xf5))  // Tokyo Night: texto lavanda claro
	styleContextMenuSel = tcell.StyleDefault.
				Background(tcell.NewRGBColor(0x3d, 0x59, 0xa1)). // Tokyo Night: azul de seleção
				Foreground(tcell.ColorWhite).Bold(true)
	styleSuggestItem = tcell.StyleDefault.Background(tcell.ColorGray).Foreground(tcell.ColorBlack)
	styleSuggestSel  = tcell.StyleDefault.Background(tcell.ColorDodgerBlue).Foreground(tcell.ColorWhite).Bold(true)
	styleLineNum     = tcell.StyleDefault.Foreground(tcell.ColorGray)
	styleDirty       = tcell.StyleDefault.Background(tcell.ColorNavy).Foreground(tcell.ColorOrange)
	styleSelection   = tcell.StyleDefault.Background(tcell.ColorDimGray)
	styleSearchHit   = tcell.StyleDefault.Background(tcell.ColorYellow).Foreground(tcell.ColorBlack)
	styleRename      = tcell.StyleDefault.Background(tcell.ColorDarkGoldenrod).Foreground(tcell.ColorBlack)

	// segmentos coloridos da barra de status (estilo airline/lightline) —
	// cores vívidas e variadas, não só tons de azul
	styleModeIns     = tcell.StyleDefault.Background(tcell.ColorYellow).Foreground(tcell.ColorBlack).Bold(true)
	styleModeOvr     = tcell.StyleDefault.Background(tcell.ColorRed).Foreground(tcell.ColorWhite).Bold(true)
	styleModePreview = tcell.StyleDefault.Background(tcell.ColorGreen).Foreground(tcell.ColorBlack).Bold(true)
	styleStatusMid   = tcell.StyleDefault.Background(tcell.ColorNavy).Foreground(tcell.ColorWhite)
	styleAccentEnc   = tcell.StyleDefault.Background(tcell.ColorDarkTurquoise).Foreground(tcell.ColorBlack).Bold(true)
	styleAccentPos   = tcell.StyleDefault.Background(tcell.ColorFuchsia).Foreground(tcell.ColorWhite).Bold(true)
	styleKeymapTag   = tcell.StyleDefault.Background(tcell.ColorPurple).Foreground(tcell.ColorWhite).Bold(true)
)

func drawText(s tcell.Screen, x, y int, style tcell.Style, text string) int {
	for _, r := range text {
		s.SetContent(x, y, r, nil, style)
		x += runewidth.RuneWidth(r)
	}
	return x
}

// Render desenha a tela inteira a partir do estado atual do App.
func (a *App) Render() {
	w, h := a.Screen.Size()
	if w < 20 || h < 5 {
		a.Screen.Show()
		return
	}

	editorTop := 0
	editorBottom := h - 1 // barra de status sempre na última linha — mensagens e prompts agora aparecem nela mesma
	editorLeft := 0

	layout := RenderLayout{}

	if a.ShowSidebar {
		closeX0, closeX1 := a.drawSidebar(0, editorTop, a.SidebarWidth, editorBottom)
		editorLeft = a.SidebarWidth + 1
		layout.SidebarVisible = true
		layout.SidebarX0, layout.SidebarY0 = 0, editorTop
		layout.SidebarX1, layout.SidebarY1 = a.SidebarWidth, editorTop+editorBottom
		layout.SidebarRowY0 = editorTop + 1
		layout.SidebarBorderX = a.SidebarWidth // coluna do "│", arrastável pra redimensionar
		layout.SidebarCloseX0, layout.SidebarCloseX1 = closeX0, closeX1
	}

	paneCount := len(a.Panes)
	paneWidth := (w - editorLeft) / paneCount
	layout.Panes = make([]PaneLayout, paneCount)
	for i, bufIdx := range a.Panes {
		px := editorLeft + i*paneWidth
		pw := paneWidth
		if i == paneCount-1 {
			pw = w - px
		}
		pl := a.drawPane(bufIdx, px, editorTop, pw, editorBottom, i == a.ActivePane && !a.SidebarFocused)
		layout.Panes[i] = pl
	}
	a.Layout = layout

	a.drawStatusBar(0, editorBottom, w)

	// posiciona o cursor visível do terminal — segue o texto principal
	// sempre, inclusive durante o renomear (F2): o cursor fica na
	// ocorrência de origem, inline, nunca numa linha separada.
	if !a.PromptActive && !a.SidebarFocused && !a.ContextMenuActive && !a.HelpActive && !a.ActiveBuffer().Preview {
		bufIdx := a.Panes[a.ActivePane]
		b := a.Buffers[bufIdx]
		paneX := editorLeft + a.ActivePane*paneWidth
		gutter := 0
		if a.ShowLineNumbers {
			gutter = lineNumWidth(len(b.Lines))
		}
		tabWidth := a.Settings.TabWidth
		if tabWidth <= 0 {
			tabWidth = 4
		}
		cursorVCol := visualColOf(b.Lines[b.CursorY], b.CursorX, tabWidth)
		cx := paneX + gutter + (cursorVCol - b.OffsetX)
		cy := editorTop + 1 + (b.CursorY - b.OffsetY) // +1: a linha de abas fica acima do texto
		a.Screen.ShowCursor(cx, cy)
	} else {
		a.Screen.HideCursor()
	}

	a.drawSuggestBox()
	a.drawContextMenu()
	a.drawPalette()
	a.drawHelp()

	a.Screen.Show()
}

// suggestBox calcula a posição e o tamanho do popup de sugestões, logo
// abaixo do cursor (ou acima, se não couber embaixo), ajustando pra
// caber na largura da tela.
func (a *App) suggestBox() (x, y, width, height int) {
	for _, item := range a.SuggestItems {
		if l := len(item) + 1; l > width {
			width = l
		}
	}
	height = len(a.SuggestItems)

	if a.ActivePane >= len(a.Layout.Panes) {
		return 0, 0, 0, 0
	}
	pl := a.Layout.Panes[a.ActivePane]
	b := a.ActiveBuffer()
	tabWidth := a.Settings.TabWidth
	if tabWidth <= 0 {
		tabWidth = 4
	}
	cursorVCol := visualColOf(b.Lines[b.CursorY], b.CursorX, tabWidth)
	x = pl.TextX + (cursorVCol - b.OffsetX)
	cursorRow := pl.TextTop + (b.CursorY - b.OffsetY)
	y = cursorRow + 1 // abre 1 linha abaixo do cursor, por padrão

	w, h := a.Screen.Size()
	if x+width > w {
		x = w - width
	}
	if x < 0 {
		x = 0
	}
	if y+height > h-2 { // h-2: não invade a barra de status/linha de baixo
		y = cursorRow - height // abre pra cima em vez de embaixo
	}
	if y < 0 {
		y = 0
	}
	return x, y, width, height
}

func (a *App) drawSuggestBox() {
	if !a.SuggestActive || len(a.SuggestItems) == 0 ||
		a.RenameActive || a.PromptActive || a.SidebarFocused || a.ContextMenuActive {
		return
	}
	x, y, width, _ := a.suggestBox()
	if width == 0 {
		return
	}
	for i, item := range a.SuggestItems {
		row := y + i
		st := styleSuggestItem
		if i == a.SuggestIndex {
			st = styleSuggestSel
		}
		label := truncate(" "+item, width)
		for len(label) < width {
			label += " "
		}
		drawText(a.Screen, x, row, st, label)
	}
}

// contextMenuBox calcula a posição e o tamanho do menu de contexto,
// ajustando pra caber na tela (abre pra cima/esquerda se não couber pra
// baixo/direita a partir do ponto do clique). Usado tanto pra desenhar
// quanto pra saber em qual item um clique caiu — nunca deve divergir
// entre as duas contas, por isso é uma função só.
// contextMenuBox devolve a área de CONTEÚDO do menu (dentro da moldura) —
// a largura é calculada em colunas visuais, não em bytes, senão um
// rótulo com acento (tipo "código") desalinha os outros, que são só
// ASCII. Usado tanto pra desenhar quanto pra saber em qual item um
// clique caiu — nunca deve divergir entre as duas contas.
func (a *App) contextMenuBox() (x, y, width, height int) {
	for _, it := range a.ContextMenuItems {
		if l := runewidth.StringWidth(it.Label) + 1; l > width { // +1: espaço de margem à esquerda
			width = l
		}
	}
	height = len(a.ContextMenuItems)

	w, h := a.Screen.Size()
	totalW, totalH := width+2, height+2 // +2 de cada: a moldura (1 char de cada lado)
	boxX, boxY := a.ContextMenuX, a.ContextMenuY
	if boxX+totalW > w {
		boxX = w - totalW
	}
	if boxX < 0 {
		boxX = 0
	}
	if boxY+totalH > h {
		boxY = h - totalH
	}
	if boxY < 0 {
		boxY = 0
	}
	return boxX + 1, boxY + 1, width, height
}

// drawPalette desenha a paleta de comandos (Ctrl+P) — caixa
// centralizada na tela, com o filtro digitado no topo e a lista de
// comandos que batem com ele embaixo, item destacado navegável.
func (a *App) drawPalette() {
	if !a.PaletteActive {
		return
	}
	screenW, screenH := a.Screen.Size()

	width := 50
	if width > screenW-4 {
		width = screenW - 4
	}
	maxVisible := 12
	visible := len(a.PaletteItems)
	if visible > maxVisible {
		visible = maxVisible
	}
	if visible < 1 {
		visible = 1
	}
	height := visible + 2 // +2: linha do filtro + separador

	x := (screenW - width) / 2
	if x < 1 {
		x = 1
	}
	y := (screenH - height) / 2
	if y < 1 {
		y = 1
	}
	bx, by := x-1, y-1

	a.Screen.SetContent(bx, by, '┌', nil, styleContextMenu)
	for c := 0; c < width; c++ {
		a.Screen.SetContent(bx+1+c, by, '─', nil, styleContextMenu)
	}
	a.Screen.SetContent(bx+width+1, by, '┐', nil, styleContextMenu)

	filterRow := y
	a.Screen.SetContent(bx, filterRow, '│', nil, styleContextMenu)
	drawText(a.Screen, x, filterRow, styleContextMenu, padVisual(" Comando: "+a.PaletteFilter, width))
	a.Screen.SetContent(bx+width+1, filterRow, '│', nil, styleContextMenu)

	sepRow := y + 1
	a.Screen.SetContent(bx, sepRow, '├', nil, styleContextMenu)
	for c := 0; c < width; c++ {
		a.Screen.SetContent(bx+1+c, sepRow, '─', nil, styleContextMenu)
	}
	a.Screen.SetContent(bx+width+1, sepRow, '┤', nil, styleContextMenu)

	if len(a.PaletteItems) == 0 {
		row := sepRow + 1
		a.Screen.SetContent(bx, row, '│', nil, styleContextMenu)
		drawText(a.Screen, x, row, styleContextMenu, padVisual(" (nenhum comando encontrado)", width))
		a.Screen.SetContent(bx+width+1, row, '│', nil, styleContextMenu)
	} else {
		// rolagem: mantém o item destacado sempre visível na janela
		start := 0
		if a.PaletteSel >= visible {
			start = a.PaletteSel - visible + 1
		}
		if start > len(a.PaletteItems)-visible {
			start = len(a.PaletteItems) - visible
		}
		if start < 0 {
			start = 0
		}
		for i := 0; i < visible; i++ {
			idx := start + i
			row := sepRow + 1 + i
			a.Screen.SetContent(bx, row, '│', nil, styleContextMenu)
			itemStyle := styleContextMenu
			if idx == a.PaletteSel {
				itemStyle = styleContextMenuSel
			}
			drawText(a.Screen, x, row, itemStyle, padVisual(" "+a.PaletteItems[idx], width))
			a.Screen.SetContent(bx+width+1, row, '│', nil, styleContextMenu)
		}
	}

	byBottom := y + height
	a.Screen.SetContent(bx, byBottom, '└', nil, styleContextMenu)
	for c := 0; c < width; c++ {
		a.Screen.SetContent(bx+1+c, byBottom, '─', nil, styleContextMenu)
	}
	a.Screen.SetContent(bx+width+1, byBottom, '┘', nil, styleContextMenu)
}

func (a *App) drawContextMenu() {
	if !a.ContextMenuActive || len(a.ContextMenuItems) == 0 {
		return
	}
	x, y, width, height := a.contextMenuBox()
	bx, by := x-1, y-1

	a.Screen.SetContent(bx, by, '┌', nil, styleContextMenu)
	for c := 0; c < width; c++ {
		a.Screen.SetContent(bx+1+c, by, '─', nil, styleContextMenu)
	}
	a.Screen.SetContent(bx+width+1, by, '┐', nil, styleContextMenu)

	for i, it := range a.ContextMenuItems {
		row := y + i
		a.Screen.SetContent(bx, row, '│', nil, styleContextMenu)
		itemStyle := styleContextMenu
		if i == a.ContextMenuIndex {
			itemStyle = styleContextMenuSel
		}
		label := padVisual(" "+it.Label, width)
		drawText(a.Screen, x, row, itemStyle, label)
		a.Screen.SetContent(bx+width+1, row, '│', nil, styleContextMenu)
	}

	byBottom := y + height
	a.Screen.SetContent(bx, byBottom, '└', nil, styleContextMenu)
	for c := 0; c < width; c++ {
		a.Screen.SetContent(bx+1+c, byBottom, '─', nil, styleContextMenu)
	}
	a.Screen.SetContent(bx+width+1, byBottom, '┘', nil, styleContextMenu)
}

// padVisual completa s com espaços até ocupar width colunas visuais
// (não bytes) — trunca se, por algum motivo, já passar da largura.
func padVisual(s string, width int) string {
	for runewidth.StringWidth(s) > width {
		r := []rune(s)
		if len(r) == 0 {
			break
		}
		s = string(r[:len(r)-1])
	}
	for runewidth.StringWidth(s) < width {
		s += " "
	}
	return s
}

// visualColOf calcula a coluna visual (na tela) correspondente a um índice
// de byte dentro da linha, respeitando tab-stops — necessário porque uma
// tabulação ocupa mais de 1 coluna, então índice de byte e coluna de tela
// divergem em qualquer linha que tenha \t.
func visualColOf(line string, byteIdx, tabWidth int) int {
	if byteIdx > len(line) {
		byteIdx = len(line)
	}
	if tabWidth <= 0 {
		tabWidth = 4
	}
	vcol := 0
	i := 0
	for _, r := range line {
		if i >= byteIdx {
			break
		}
		if r == '\t' {
			vcol += tabWidth - (vcol % tabWidth)
		} else {
			w := runewidth.RuneWidth(r)
			if w <= 0 {
				w = 1
			}
			vcol += w
		}
		i += len(string(r))
	}
	return vcol
}

// byteIndexForVisualCol é o inverso de visualColOf: dada uma coluna visual
// (coluna de tela) alvo, acha o índice de byte na linha que corresponde a
// ela — necessário pra saber em qual caractere um clique do mouse caiu,
// já que tabs ocupam mais de 1 coluna de tela.
func byteIndexForVisualCol(line string, targetVCol, tabWidth int) int {
	if tabWidth <= 0 {
		tabWidth = 4
	}
	vcol := 0
	i := 0
	for _, r := range line {
		if vcol >= targetVCol {
			return i
		}
		if r == '\t' {
			vcol += tabWidth - (vcol % tabWidth)
		} else {
			w := runewidth.RuneWidth(r)
			if w <= 0 {
				w = 1
			}
			vcol += w
		}
		i += len(string(r))
	}
	return len(line)
}

func lineNumWidth(nlines int) int {
	digits := 2
	n := nlines
	for n >= 10 {
		digits++
		n /= 10
	}
	if digits < 4 {
		digits = 4
	}
	return digits
}

func (a *App) drawSidebar(x, y, width, height int) (closeX0, closeX1 int) {
	style := styleSidebar
	headerStyle := styleTabActive // mesma cor do nome de arquivo na aba ativa
	cx := drawText(a.Screen, x, y, headerStyle, truncate(" SIDEBAR", width))
	for cx < x+width {
		a.Screen.SetContent(cx, y, ' ', nil, headerStyle)
		cx++
	}
	// "x" de fechar no canto direito do título, clicável.
	closeX0, closeX1 = x+width-2, x+width-1
	if closeX0 > cx-3 { // só desenha se realmente sobrar espaço depois de "SIDEBAR"
		a.Screen.SetContent(closeX0, y, 'x', nil, headerStyle.Bold(true))
	} else {
		closeX0, closeX1 = -1, -1
	}
	for row := 1; row < height; row++ {
		for c := 0; c < width; c++ {
			a.Screen.SetContent(x+c, y+row, ' ', nil, styleDefault)
		}
	}

	visibleRows := height - 1 // linha 0 é o cabeçalho "SIDEBAR"
	if visibleRows < 1 {
		visibleRows = 1
	}
	// mantém a seleção sempre visível, rolando a lista quando preciso —
	// mesma lógica do scroll vertical do texto principal.
	if a.SidebarSel < a.SidebarOffset {
		a.SidebarOffset = a.SidebarSel
	}
	if a.SidebarSel >= a.SidebarOffset+visibleRows {
		a.SidebarOffset = a.SidebarSel - visibleRows + 1
	}
	if a.SidebarOffset < 0 {
		a.SidebarOffset = 0
	}
	maxOffset := len(a.SidebarEntries) - visibleRows
	if maxOffset < 0 {
		maxOffset = 0
	}
	if a.SidebarOffset > maxOffset {
		a.SidebarOffset = maxOffset
	}

	for row := 0; row < visibleRows; row++ {
		i := a.SidebarOffset + row
		if i >= len(a.SidebarEntries) {
			break
		}
		e := a.SidebarEntries[i]
		sy := y + 1 + row
		name := e.Name()
		if e.IsDir() {
			name += "/"
		}
		st := style
		if i == a.SidebarSel {
			if a.SidebarFocused {
				st = styleSidebarSel
			} else {
				st = styleSidebarSelDim
			}
		}
		line := truncate(" "+name, width)
		for len(line) < width {
			line += " "
		}
		drawText(a.Screen, x, sy, st, line)
	}
	// borda direita
	for row := y; row < y+height; row++ {
		a.Screen.SetContent(x+width, row, '│', nil, styleSidebar)
	}
	return closeX0, closeX1
}

func (a *App) drawPane(bufIdx, x, y, width, height int, focused bool) PaneLayout {
	b := a.Buffers[bufIdx]
	tabRanges := a.drawTabs(bufIdx, x, y, width)
	if b.Preview {
		return a.drawPreview(bufIdx, x, y, width, height, tabRanges)
	}

	gutter := 0
	if a.ShowLineNumbers {
		gutter = lineNumWidth(len(b.Lines))
	}
	textTop := y + 1
	textHeight := height - 1
	textWidth := width - gutter
	if textWidth < 1 {
		textWidth = 1
	}

	tabWidth := a.Settings.TabWidth
	if tabWidth <= 0 {
		tabWidth = 4
	}

	// resolve UMA vez por painel (não por linha) qual bloco do .nanorc
	// customizado bate com esse arquivo — se o modo estiver desligado,
	// ou nada bater, cai pro realce padrão (chroma) linha por linha.
	var customSyn *syntax.NanorcSyntax
	if a.UseCustomNanorc && len(a.customNanorcSyntaxes) > 0 {
		customSyn = syntax.MatchNanorcSyntax(a.customNanorcSyntaxes, b.Path, b.Lines[0])
	}
	isMD := customSyn == nil && markdown.IsMarkdown(b.Path)

	// ajusta scroll vertical/horizontal pra manter o cursor visível.
	// O scroll horizontal trabalha em COLUNA VISUAL (considerando o
	// espaço que uma tabulação ocupa na tela), não em índice bruto do
	// texto — senão uma linha com \t rola errado.
	if b.CursorY < b.OffsetY {
		b.OffsetY = b.CursorY
	}
	if b.CursorY >= b.OffsetY+textHeight {
		b.OffsetY = b.CursorY - textHeight + 1
	}
	cursorVCol := visualColOf(b.Lines[b.CursorY], b.CursorX, tabWidth)
	if cursorVCol < b.OffsetX {
		b.OffsetX = cursorVCol
	}
	if cursorVCol >= b.OffsetX+textWidth {
		b.OffsetX = cursorVCol - textWidth + 1
	}
	if b.OffsetY < 0 {
		b.OffsetY = 0
	}
	if b.OffsetX < 0 {
		b.OffsetX = 0
	}

	var selSY, selSX, selEY, selEX int
	hasSel := b.Selecting
	if hasSel {
		selSY, selSX, selEY, selEX = selectionRange(b.SelStartY, b.SelStartX, b.CursorY, b.CursorX)
	}

	renaming := a.RenameActive && bufIdx == a.RenamePaneBuf
	blockOn := (a.BlockActive || a.BlockEditing) && bufIdx == a.BlockPaneBuf
	var blockRowStart, blockRowEnd, blockColStart, blockColEnd int
	if blockOn {
		blockRowStart, blockRowEnd, blockColStart, blockColEnd = a.blockRange()
		if blockColEnd <= blockColStart {
			blockColEnd = blockColStart + 1 // largura 0 (só ponto de inserção): mostra 1 coluna mesmo assim
		}
	}

	// Markdown: realce por bloco (cercas de código, tabelas, listas...)
	// calculado de uma vez pras linhas visíveis — depende do contexto
	// das linhas de cima, não dá pra fazer linha a linha isolada.
	var mdSegs [][]syntax.Segment
	if isMD {
		mdSegs = markdown.HighlightRange(b.Lines, b.OffsetY, b.OffsetY+textHeight-1)
	}

	for row := 0; row < textHeight; row++ {
		lineIdx := b.OffsetY + row
		sy := textTop + row
		if lineIdx >= len(b.Lines) {
			if a.ShowLineNumbers {
				cx := drawText(a.Screen, x, sy, styleLineNum, fmt.Sprintf("%*s ", gutter-1, "~"))
				for cx < x+width {
					a.Screen.SetContent(cx, sy, ' ', nil, styleDefault)
					cx++
				}
			} else {
				for cx := x; cx < x+width; cx++ {
					a.Screen.SetContent(cx, sy, ' ', nil, styleDefault)
				}
			}
			continue
		}
		if a.ShowLineNumbers {
			numStr := fmt.Sprintf("%*d ", gutter-1, lineIdx+1)
			drawText(a.Screen, x, sy, styleLineNum, numStr)
		}

		var segs []syntax.Segment
		if customSyn != nil {
			segs = syntax.HighlightLineNanorc(customSyn, b.Lines[lineIdx])
		} else if isMD && row < len(mdSegs) {
			segs = mdSegs[row]
		} else {
			segs = syntax.HighlightLine(b.Path, b.Lines[0], b.Lines[lineIdx])
		}
		cx := x + gutter
		vcol := 0   // coluna visual (considera largura de tab) desde o início da linha
		byteAt := 0 // posição em bytes desde o início da linha (bate com CursorX/SelStartX)
		for _, seg := range segs {
			for _, r := range seg.Text {
				runeBytes := len(string(r))
				st := seg.Style
				if hasSel && inSelection(lineIdx, byteAt, selSY, selSX, selEY, selEX) {
					st = styleSelection
				}
				if blockOn && lineIdx >= blockRowStart && lineIdx <= blockRowEnd &&
					byteAt >= blockColStart && byteAt < blockColEnd {
					st = styleSelection
				}
				if a.SearchHighlightActive && bufIdx == a.SearchHighlightBuf && lineIdx == a.SearchHighlightY &&
					byteAt >= a.SearchHighlightX0 && byteAt < a.SearchHighlightX1 {
					st = styleSearchHit
				}
				if renaming {
					if idx, inOcc := renameOccurrenceIndexAt(lineIdx, byteAt, a.RenameOccs); inOcc {
						if idx == a.RenameOriginOccIdx && a.RenameSelecting {
							o := a.RenameOccs[idx]
							relPos := byteAt - o.X0
							selS, selE := a.RenameSelStart, a.RenameCursor
							if selS > selE {
								selS, selE = selE, selS
							}
							if relPos >= selS && relPos < selE {
								st = styleSelection
							} else {
								st = styleRename
							}
						} else {
							st = styleRename
						}
					}
				}
				if r == '\t' {
					stop := tabWidth - (vcol % tabWidth)
					for k := 0; k < stop; k++ {
						if vcol >= b.OffsetX && cx < x+width {
							a.Screen.SetContent(cx, sy, ' ', nil, st)
							cx++
						}
						vcol++
					}
				} else {
					w := runewidth.RuneWidth(r)
					if w <= 0 {
						w = 1
					}
					if vcol >= b.OffsetX && cx < x+width {
						a.Screen.SetContent(cx, sy, r, nil, st)
						cx += w
					}
					vcol += w
				}
				byteAt += runeBytes
			}
		}
		for cx < x+width {
			a.Screen.SetContent(cx, sy, ' ', nil, styleDefault)
			cx++
		}
	}

	return PaneLayout{
		BufIdx:     bufIdx,
		X:          x,
		TabY:       y,
		TextTop:    textTop,
		TextX:      x + gutter,
		Width:      width,
		TextHeight: textHeight,
		Gutter:     gutter,
		TabRanges:  tabRanges,
	}
}

// selectionRange normaliza dois pontos (início/fim) na ordem em que aparecem no texto.
func selectionRange(sy, sx, ey, ex int) (int, int, int, int) {
	if sy > ey || (sy == ey && sx > ex) {
		return ey, ex, sy, sx
	}
	return sy, sx, ey, ex
}

// inSelection diz se a posição (linha, coluna) está dentro do intervalo selecionado.
func inSelection(y, x, sy, sx, ey, ex int) bool {
	if y < sy || y > ey {
		return false
	}
	if sy == ey {
		return x >= sx && x < ex
	}
	if y == sy {
		return x >= sx
	}
	if y == ey {
		return x < ex
	}
	return true
}

// renameOccurrenceIndexAt diz se a posição (linha, byte) cai dentro de
// alguma ocorrência destacada pelo modo de renomear ao vivo (F2), e
// devolve o índice dela em occs (pra saber se é a ocorrência de origem).
func renameOccurrenceIndexAt(y, x int, occs []buffer.WordOccurrence) (int, bool) {
	for i, o := range occs {
		if o.Y == y && x >= o.X0 && x < o.X1 {
			return i, true
		}
	}
	return -1, false
}

func (a *App) drawTabs(activeBufIdx, x, y, width int) []TabRange {
	cx := x
	var ranges []TabRange
	for i, b := range a.Buffers {
		name := b.Name()
		if b.Dirty {
			name = "*" + name
		}
		label := " " + name + " x "
		st := styleTabIdle
		if i == activeBufIdx {
			st = styleTabActive
		}
		if cx+len(label) > x+width {
			break
		}
		x0 := cx
		closeX1 := cx + len(label)
		closeX0 := closeX1 - 2 // o "x" fica logo antes do último espaço
		cx = drawText(a.Screen, cx, y, st, label)
		ranges = append(ranges, TabRange{BufIdx: i, X0: x0, X1: cx, CloseX0: closeX0, CloseX1: closeX0 + 1})
	}
	for cx < x+width {
		a.Screen.SetContent(cx, y, ' ', nil, styleTabIdle)
		cx++
	}

	// título: nome do app + versão, alinhado à direita da barra de abas —
	// só aparece se couber sem cobrir nenhuma aba.
	title := " " + AppName + " v" + Version + " "
	tx := x + width - runewidth.StringWidth(title)
	if len(ranges) == 0 || tx > ranges[len(ranges)-1].X1 {
		drawText(a.Screen, tx, y, styleAppTitle, title)
	}
	return ranges
}

func (a *App) drawStatusBar(x, y, width int) {
	b := a.ActiveBuffer()

	// mensagem de status expira sozinha depois de um tempo (ver
	// SetStatusMsg) — checa aqui, no único lugar que desenha a barra,
	// se já passou da validade.
	if a.StatusMsg != "" && time.Now().After(a.StatusMsgExpiry) {
		a.StatusMsg = ""
	}

	// preenche a linha toda com o fundo "do meio" primeiro
	for c := x; c < x+width; c++ {
		a.Screen.SetContent(c, y, ' ', nil, styleStatusMid)
	}
	cx := x

	// bloco do modo (cor muda: azul = inserir, laranja = sobrescrever)
	modeLabel, modeStyle := " INSERT ", styleModeIns
	if a.OverwriteMode {
		modeLabel, modeStyle = " OVERWRITE ", styleModeOvr
	}
	if b.Preview {
		modeLabel, modeStyle = " PREVIEW ", styleModePreview
	}
	cx = drawText(a.Screen, cx, y, modeStyle, modeLabel)

	// perfil de teclas ativo (F9 alterna) — só mostra quando não é o
	// padrão, pra não poluir a barra à toa no caso mais comum.
	if a.Settings.Keymap != "" {
		cx = drawText(a.Screen, cx, y, styleKeymapTag, " "+a.Settings.Keymap+" ")
	}

	// prompt (buscar, salvar como, substituir...), renomear ao vivo (F2),
	// ou mensagem de status ocupam o lugar do nome do arquivo + tipo —
	// só um desses três aparece por vez, na ordem de prioridade abaixo.
	switch {
	case a.RenameActive:
		n := len(a.RenameOccs)
		label := fmt.Sprintf(" Renomeando '%s' → '%s' (%d ocorrência(s)) — Enter confirma · Esc cancela ",
			a.RenameWord, a.RenameNew, n)
		cx = drawText(a.Screen, cx, y, styleStatusMid, label)
	case a.PromptActive:
		label := " " + a.PromptLabel + a.PromptInput + " "
		cx = drawText(a.Screen, cx, y, styleStatusMid, label)
	case a.StatusMsg != "":
		cx = drawText(a.Screen, cx, y, styleDirty, " "+a.StatusMsg+" ")
	default:
		dirty := ""
		if b.Dirty {
			dirty = " [+]"
		}
		cx = drawText(a.Screen, cx, y, styleStatusMid, fmt.Sprintf(" [%s]%s ", b.Name(), dirty))

		// tipo de arquivo (linguagem detectada pelo highlight)
		filetype := strings.ToLower(syntax.DebugLexerName(b.Path, firstLineOf(b)))
		if filetype != "" && filetype != "nenhum" {
			cx = drawText(a.Screen, cx, y, styleStatusMid, filetype+" ")
		}
	}

	// monta o bloco direito primeiro, pra saber a largura e alinhar à direita —
	// a contagem de palavras usa um cache com limite de tempo: recontar o
	// arquivo inteiro em todo frame era desperdício real (~1-3ms por
	// tecla, medido, em arquivos de milhares de linhas).
	bufIdxForWC := a.Panes[a.ActivePane]
	var wordCount int
	if bufIdxForWC == a.wcCacheBufIdx && time.Since(a.wcCacheAt) < 600*time.Millisecond {
		wordCount = a.wcCacheCount
	} else {
		wordCount = countWords(b.Lines)
		a.wcCacheBufIdx = bufIdxForWC
		a.wcCacheCount = wordCount
		a.wcCacheAt = time.Now()
	}
	percent := 0
	if len(b.Lines) > 1 {
		percent = b.CursorY * 100 / (len(b.Lines) - 1)
	}
	rightPlain := fmt.Sprintf(" %d palavras  %d%% ", wordCount, percent)
	posLabel := fmt.Sprintf(" Ln %d, Col %d ", b.CursorY+1, b.CursorX+1)
	encLabel := " utf-8[unix] "

	rightWidth := len(encLabel) + len(rightPlain) + len(posLabel)
	// preenche o espaço do meio com o fundo padrão até sobrar só o bloco direito
	for cx < x+width-rightWidth {
		a.Screen.SetContent(cx, y, ' ', nil, styleStatusMid)
		cx++
	}
	if cx > x+width-rightWidth {
		return // tela estreita demais pro bloco direito inteiro — deixa como está
	}
	cx = drawText(a.Screen, cx, y, styleAccentEnc, truncate(encLabel, x+width-cx))
	cx = drawText(a.Screen, cx, y, styleStatusMid, truncate(rightPlain, x+width-cx))
	drawText(a.Screen, cx, y, styleAccentPos, truncate(posLabel, x+width-cx))
}

// firstLineOf devolve a primeira linha do buffer (protegido contra buffer vazio).
func firstLineOf(b *buffer.Buffer) string {
	if len(b.Lines) == 0 {
		return ""
	}
	return b.Lines[0]
}

// countWords conta palavras (tokens separados por espaço em branco) no buffer inteiro.
func countWords(lines []string) int {
	count := 0
	for _, line := range lines {
		count += len(strings.Fields(line))
	}
	return count
}

func truncate(s string, width int) string {
	if width <= 0 {
		return ""
	}
	r := []rune(s)
	if len(r) <= width {
		return s
	}
	return string(r[:width])
}
