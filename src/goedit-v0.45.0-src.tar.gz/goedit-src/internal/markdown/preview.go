/*
   goedit
   Editor de texto para terminal (TUI), com realce de sintaxe, plugins Lua, seleção em bloco e mais
   Site:      https://chililinux.com
   Site:      https://voidbr.org
   Site:      https://voidlinux.com.br
   GitHub:    https://github.com/voidlinuxbr/voidbr-goedit
   Created:   ter 20 out 2026 21:11:29 -04
   Updated:   ter 20 out 2026 21:27:16 -04
   Version:   0.45.0
   Copyright (C) 2019-2026 Vilmar Catafesta <vcatafesta@gmail.com>
*/

package markdown

import (
	"strings"

	"github.com/gdamore/tcell/v2"
	"github.com/mattn/go-runewidth"

	"goedit/internal/syntax"
)

// Line é uma linha já formatada do preview. Src é a linha do arquivo
// de onde ela veio — usada pra manter a posição ao alternar entre
// editar e visualizar (F5).
type Line struct {
	Segs []syntax.Segment
	Src  int
}

type cell struct {
	r   rune
	st  tcell.Style
	src int
}

func previewStyle(f flag, b tcell.Style) tcell.Style {
	switch {
	case f&fHTML != 0:
		return stHTML
	case f&fCode != 0:
		return b.Foreground(cOrange).Background(cInlBg)
	case f&fURL != 0:
		return tcell.StyleDefault.Foreground(cDim).Underline(true)
	case f&fImage != 0:
		b = b.Foreground(cGreen).Italic(true)
	case f&fLink != 0:
		b = b.Foreground(cBlue).Underline(true)
	}
	if f&fBold != 0 {
		b = b.Bold(true)
	}
	if f&fItalic != 0 {
		b = b.Italic(true)
	}
	if f&fStrike != 0 {
		b = b.StrikeThrough(true).Foreground(cDim)
	}
	return b
}

// inlineCells formata um trecho inline pro preview: marcadores somem,
// links mostram o texto sublinhado seguido da URL apagadinha, imagens
// viram "[imagem: alt]".
func inlineCells(s string, b tcell.Style, src int) []cell {
	spans := parseInline(s, 0)
	var out []cell
	add := func(t string, st tcell.Style) {
		for _, r := range t {
			if r == '\t' {
				r = ' '
			}
			out = append(out, cell{r, st, src})
		}
	}
	for i := 0; i < len(spans); i++ {
		sp := spans[i]
		switch {
		case sp.f&fMarker != 0:
			if sp.f&fImage != 0 && sp.text == "![" {
				add("[imagem: ", previewStyle(fImage, b))
			}
			if sp.f&fImage != 0 && sp.text == ")" {
				add("]", previewStyle(fImage, b))
			}
			continue
		case sp.f&fURL != 0 && sp.f&fImage != 0:
			continue
		case sp.f&fURL != 0 && sp.f&fLink == 0:
			// url de [texto](url): mostra só se for diferente do texto
			prevText := ""
			for k := i - 1; k >= 0 && spans[k].f&fLink != 0; k-- {
				if spans[k].f&fMarker == 0 {
					prevText = spans[k].text + prevText
				}
			}
			if sp.text != "" && sp.text != prevText {
				add(" ("+sp.text+")", previewStyle(fURL, b))
			}
			continue
		}
		add(sp.text, previewStyle(sp.f, b))
	}
	return out
}

func cellsWidth(cs []cell) int {
	w := 0
	for _, c := range cs {
		w += runewidth.RuneWidth(c.r)
	}
	return w
}

func toSegs(cs []cell) []syntax.Segment {
	var segs []syntax.Segment
	var cur strings.Builder
	var st tcell.Style
	for i, c := range cs {
		if i > 0 && c.st != st {
			segs = append(segs, syntax.Segment{Text: cur.String(), Style: st})
			cur.Reset()
		}
		st = c.st
		cur.WriteRune(c.r)
	}
	if cur.Len() > 0 {
		segs = append(segs, syntax.Segment{Text: cur.String(), Style: st})
	}
	return segs
}

func textCells(t string, st tcell.Style, src int) []cell {
	var cs []cell
	for _, r := range t {
		cs = append(cs, cell{r, st, src})
	}
	return cs
}

// wrap quebra as células em linhas de até width colunas, só nos
// espaços (palavra maior que a linha é cortada no meio). first é o
// prefixo da 1ª linha (marcador de lista, barra de citação...) e cont
// o das seguintes. Uma célula '\n' força quebra (quebra dura do md).
func wrap(cs []cell, width int, first, cont []cell, src int) []Line {
	var out []Line
	cur := append([]cell(nil), first...)
	curW := cellsWidth(cur)
	prefW := curW
	lineSrc := src
	hasContent := false
	push := func() {
		out = append(out, Line{Segs: toSegs(cur), Src: lineSrc})
		cur = append([]cell(nil), cont...)
		curW = cellsWidth(cur)
		prefW = curW
		hasContent = false
	}
	i := 0
	for i < len(cs) {
		if cs[i].r == '\n' {
			push()
			i++
			continue
		}
		// separador (espaços)
		j := i
		for j < len(cs) && cs[j].r == ' ' {
			j++
		}
		sep := cs[i:j]
		k := j
		for k < len(cs) && cs[k].r != ' ' && cs[k].r != '\n' {
			k++
		}
		word := cs[j:k]
		i = k
		if len(word) == 0 {
			continue
		}
		wW := cellsWidth(word)
		sepW := 0
		if hasContent && len(sep) > 0 {
			sepW = 1
		}
		if hasContent && curW+sepW+wW > width {
			push()
			sepW = 0
		}
		if sepW > 0 {
			cur = append(cur, sep[0])
			curW++
		}
		for _, c := range word {
			w := runewidth.RuneWidth(c.r)
			if curW+w > width && curW > prefW {
				push()
			}
			if !hasContent {
				hasContent = true
				lineSrc = c.src
			}
			cur = append(cur, c)
			curW += w
		}
	}
	if hasContent || len(out) == 0 {
		out = append(out, Line{Segs: toSegs(cur), Src: lineSrc})
	}
	return out
}

func rule(r rune, n int, st tcell.Style, src int) Line {
	if n < 0 {
		n = 0
	}
	return Line{Segs: []syntax.Segment{{Text: strings.Repeat(string(r), n), Style: st}}, Src: src}
}

func headingText(line string, level int) string {
	t := strings.TrimSpace(line)
	t = strings.TrimSpace(t[level:])
	// "## Título ##" — os # de fechamento são opcionais e somem
	if s := strings.TrimRight(t, "#"); s != t && (s == "" || strings.HasSuffix(s, " ")) {
		t = strings.TrimSpace(s)
	}
	return t
}

func expandTabs(s string, tw int) string {
	if !strings.Contains(s, "\t") {
		return s
	}
	var b strings.Builder
	col := 0
	for _, r := range s {
		if r == '\t' {
			n := tw - col%tw
			b.WriteString(strings.Repeat(" ", n))
			col += n
			continue
		}
		b.WriteRune(r)
		col += runewidth.RuneWidth(r)
	}
	return b.String()
}

// codeBlock desenha um bloco de código numa caixa de fundo escuro,
// com o nome da linguagem no topo e realce do chroma.
func codeBlock(lines []string, srcs []int, lang string, width int) []Line {
	bg := stBase.Background(cCodeBg)
	fb := bg.Foreground(rgb(0xa9b1d6))
	var out []Line
	pad := func(segs []syntax.Segment, used int, src int) Line {
		if used < width {
			segs = append(segs, syntax.Segment{Text: strings.Repeat(" ", width-used), Style: bg})
		}
		return Line{Segs: segs, Src: src}
	}
	top := srcs[0]
	if lang != "" {
		label := " " + lang + " "
		out = append(out, pad([]syntax.Segment{{Text: label, Style: bg.Foreground(cDim).Italic(true)}}, runewidth.StringWidth(label), top))
	} else {
		out = append(out, pad(nil, 0, top))
	}
	for i, l := range lines {
		l = expandTabs(l, 4)
		segs := []syntax.Segment{{Text: "  ", Style: bg}}
		used := 2
		for _, s := range syntax.HighlightCode(lang, l, fb) {
			// corta no limite da largura (código não quebra linha)
			txt := s.Text
			if used+runewidth.StringWidth(txt) > width {
				txt = runewidth.Truncate(txt, width-used, "")
			}
			if txt == "" {
				break
			}
			segs = append(segs, syntax.Segment{Text: txt, Style: s.Style})
			used += runewidth.StringWidth(txt)
		}
		out = append(out, pad(segs, used, srcs[i]))
	}
	last := top
	if len(srcs) > 0 {
		last = srcs[len(srcs)-1]
	}
	out = append(out, pad(nil, 0, last))
	return out
}

// table desenha uma tabela GFM com bordas de caixa.
func table(rows [][]string, aligns []byte, srcs []int, width int) []Line {
	ncol := len(aligns)
	for _, r := range rows {
		if len(r) > ncol {
			ncol = len(r)
		}
	}
	for len(aligns) < ncol {
		aligns = append(aligns, 'l')
	}
	cellsOf := make([][][]cell, len(rows))
	colW := make([]int, ncol)
	for ri, r := range rows {
		st := stBase
		if ri == 0 {
			st = st.Bold(true).Foreground(cBlue)
		}
		cellsOf[ri] = make([][]cell, ncol)
		for ci := 0; ci < ncol; ci++ {
			txt := ""
			if ci < len(r) {
				txt = strings.TrimSpace(r[ci])
			}
			cs := inlineCells(txt, st, srcs[ri])
			cellsOf[ri][ci] = cs
			if w := cellsWidth(cs); w > colW[ci] {
				colW[ci] = w
			}
		}
	}
	bd := stBase.Foreground(cBorder)
	border := func(l, m, r rune, src int) Line {
		var b strings.Builder
		b.WriteRune(l)
		for ci, w := range colW {
			b.WriteString(strings.Repeat("─", w+2))
			if ci < ncol-1 {
				b.WriteRune(m)
			}
		}
		b.WriteRune(r)
		return Line{Segs: []syntax.Segment{{Text: b.String(), Style: bd}}, Src: src}
	}
	var out []Line
	out = append(out, border('┌', '┬', '┐', srcs[0]))
	for ri := range rows {
		var cs []cell
		cs = append(cs, cell{'│', bd, srcs[ri]})
		for ci := 0; ci < ncol; ci++ {
			c := cellsOf[ri][ci]
			gap := colW[ci] - cellsWidth(c)
			left := 0
			switch aligns[ci] {
			case 'r':
				left = gap
			case 'c':
				left = gap / 2
			}
			cs = append(cs, textCells(strings.Repeat(" ", left+1), stBase, srcs[ri])...)
			cs = append(cs, c...)
			cs = append(cs, textCells(strings.Repeat(" ", gap-left+1), stBase, srcs[ri])...)
			cs = append(cs, cell{'│', bd, srcs[ri]})
		}
		out = append(out, Line{Segs: toSegs(cs), Src: srcs[ri]})
		if ri == 0 {
			out = append(out, border('├', '┼', '┤', srcs[ri]))
		}
	}
	out = append(out, border('└', '┴', '┘', srcs[len(srcs)-1]))
	return out
}

func tableRow(line string) []string {
	cells := splitTableCells(strings.TrimSpace(line))
	if len(cells) > 0 && strings.TrimSpace(cells[0]) == "" {
		cells = cells[1:]
	}
	if len(cells) > 0 && strings.TrimSpace(cells[len(cells)-1]) == "" {
		cells = cells[:len(cells)-1]
	}
	for i := range cells {
		cells[i] = strings.ReplaceAll(cells[i], "\\|", "|")
	}
	return cells
}

func tableAligns(line string) []byte {
	var al []byte
	for _, c := range tableRow(line) {
		c = strings.TrimSpace(c)
		l, r := strings.HasPrefix(c, ":"), strings.HasSuffix(c, ":")
		switch {
		case l && r:
			al = append(al, 'c')
		case r:
			al = append(al, 'r')
		default:
			al = append(al, 'l')
		}
	}
	return al
}

// hardBreak: linha terminando com 2+ espaços ou "\" vira quebra dura.
func hardBreak(line string) (string, bool) {
	if strings.HasSuffix(line, "  ") {
		return strings.TrimRight(line, " "), true
	}
	if strings.HasSuffix(line, "\\") && !strings.HasSuffix(line, "\\\\") {
		return strings.TrimSuffix(line, "\\"), true
	}
	return line, false
}

// paragraphCells junta várias linhas do fonte num parágrafo só (quebra
// simples do md vira espaço; quebra dura vira '\n').
func paragraphCells(lines []string, srcs []int, st tcell.Style) []cell {
	var cs []cell
	for i, l := range lines {
		l = strings.TrimSpace(l)
		l2, hard := hardBreak(l)
		if i > 0 && len(cs) > 0 && cs[len(cs)-1].r != '\n' {
			cs = append(cs, cell{' ', stBase, srcs[i]})
		}
		cs = append(cs, inlineCells(strings.TrimSpace(l2), st, srcs[i])...)
		if hard && i < len(lines)-1 {
			cs = append(cs, cell{'\n', stBase, srcs[i]})
		}
	}
	return cs
}

var bullets = []string{"•", "◦", "▪", "‣"}

// Render formata o documento inteiro pro preview, numa largura dada.
func Render(lines []string, width int) []Line {
	if width < 10 {
		width = 10
	}
	info := classify(lines, len(lines)-1)
	var out []Line
	lastBlank := true
	blank := func(src int) {
		if !lastBlank {
			out = append(out, Line{Src: src})
			lastBlank = true
		}
	}
	emit := func(ls ...Line) {
		out = append(out, ls...)
		lastBlank = false
	}

	for i := 0; i < len(lines); {
		li := info[i]
		switch li.kind {
		case kBlank, kSetextUnder, kHTML, kFenceClose:
			if li.kind == kBlank {
				blank(i)
			}
			i++

		case kFront:
			i++ // front matter (YAML) não aparece no documento renderizado

		case kHeading, kSetextText:
			blank(i)
			txt := strings.TrimSpace(lines[i])
			if li.kind == kHeading {
				txt = headingText(lines[i], li.level)
			}
			hs := headingStyle(li.level)
			var prefix []cell
			if li.level >= 3 {
				prefix = textCells(strings.Repeat("#", li.level)+" ", hs.Dim(true), i)
			}
			emit(wrap(inlineCells(txt, hs, i), width, prefix, nil, i)...)
			switch li.level {
			case 1:
				emit(rule('━', width, stBase.Foreground(headingColors[0]), i))
			case 2:
				emit(rule('─', width, stBase.Foreground(cBorder), i))
			}
			blank(i)
			i++

		case kHR:
			blank(i)
			emit(rule('─', width, stBase.Foreground(cBorder), i))
			blank(i)
			i++

		case kFenceOpen, kIndCode:
			var code []string
			var srcs []int
			lang := li.lang
			start := i
			if li.kind == kFenceOpen {
				i++
				for i < len(lines) && info[i].kind == kCode {
					code = append(code, lines[i])
					srcs = append(srcs, i)
					i++
				}
				if i < len(lines) && info[i].kind == kFenceClose {
					i++
				}
			} else {
				for i < len(lines) && info[i].kind == kIndCode {
					l := lines[i]
					if strings.HasPrefix(l, "\t") {
						l = l[1:]
					} else if len(l) >= 4 {
						l = l[4:]
					}
					code = append(code, l)
					srcs = append(srcs, i)
					i++
				}
			}
			if len(srcs) == 0 {
				srcs = []int{start}
				code = []string{""}
			}
			blank(start)
			emit(codeBlock(code, srcs, lang, width)...)
			blank(i - 1)

		case kTable:
			var rows [][]string
			var srcs []int
			var aligns []byte
			for i < len(lines) && (info[i].kind == kTable || info[i].kind == kTableDelim) {
				if info[i].kind == kTableDelim {
					if aligns == nil {
						aligns = tableAligns(lines[i])
					}
				} else {
					rows = append(rows, tableRow(lines[i]))
					srcs = append(srcs, i)
				}
				i++
			}
			if len(rows) == 0 {
				continue
			}
			blank(srcs[0])
			emit(table(rows, aligns, srcs, width)...)
			blank(i - 1)

		case kQuote:
			// junta as linhas da citação em parágrafos (linha "> " vazia
			// separa parágrafo), com a barra lateral no começo de cada linha
			var para []string
			var psrc []int
			level := 1
			flushQ := func() {
				if len(para) == 0 {
					return
				}
				bar := textCells(strings.Repeat("▌ ", level), stQuote, psrc[0])
				emit(wrap(paragraphCells(para, psrc, stBase.Foreground(cQuote).Italic(true)), width, bar, bar, psrc[0])...)
				para, psrc = nil, nil
			}
			blank(i)
			for i < len(lines) && info[i].kind == kQuote {
				l := strings.TrimLeft(lines[i], " ")
				lv := 0
				for strings.HasPrefix(l, ">") {
					lv++
					l = strings.TrimPrefix(strings.TrimPrefix(l, ">"), " ")
				}
				if lv != level && len(para) > 0 {
					flushQ()
				}
				level = lv
				if strings.TrimSpace(l) == "" {
					flushQ()
					bar := textCells(strings.Repeat("▌ ", level), stQuote, i)
					emit(Line{Segs: toSegs(bar), Src: i})
				} else {
					para = append(para, l)
					psrc = append(psrc, i)
				}
				i++
			}
			flushQ()
			blank(i - 1)

		case kList:
			if !lastBlank && len(out) > 0 && i > 0 && info[i-1].kind != kList && info[i-1].kind != kText {
				blank(i)
			}
			for i < len(lines) && info[i].kind == kList {
				ind, marker, rest, _ := listMarker(lines[i])
				indent := 0
				for _, ch := range lines[i][:ind] {
					if ch == '\t' {
						indent += 4
					} else {
						indent++
					}
				}
				depth := indent / 2
				var mk []cell
				pad := strings.Repeat(" ", depth*2)
				body := lines[i][rest:]
				if marker[0] >= '0' && marker[0] <= '9' {
					mk = textCells(pad+marker+" ", stBullet, i)
				} else {
					mk = textCells(pad+bullets[(indent/2)%len(bullets)]+" ", stBullet, i)
				}
				if len(body) >= 3 && body[0] == '[' && body[2] == ']' && strings.ContainsRune(" xX", rune(body[1])) {
					if body[1] == ' ' {
						mk = append(mk, textCells("☐ ", stDim, i)...)
					} else {
						mk = append(mk, textCells("☑ ", stBase.Foreground(cGreen).Bold(true), i)...)
					}
					body = strings.TrimLeft(body[3:], " ")
				}
				para := []string{body}
				psrc := []int{i}
				i++
				// linhas de continuação do item (texto recuado logo abaixo)
				for i < len(lines) && info[i].kind == kText && isContinuation(lines[i]) {
					para = append(para, lines[i])
					psrc = append(psrc, i)
					i++
				}
				st := stBase
				cont := textCells(strings.Repeat(" ", cellsWidth(mk)), st, psrc[0])
				emit(wrap(paragraphCells(para, psrc, st), width, mk, cont, psrc[0])...)
				// linhas em branco entre itens da mesma lista não quebram a lista
				if i+1 < len(lines) && info[i].kind == kBlank && info[i+1].kind == kList {
					i++
				}
			}
			blank(i - 1)

		default: // parágrafo
			var para []string
			var psrc []int
			for i < len(lines) && info[i].kind == kText {
				para = append(para, lines[i])
				psrc = append(psrc, i)
				i++
			}
			if len(para) == 0 {
				i++ // linha órfã (não deveria acontecer) — pula pra não travar
				continue
			}
			emit(wrap(paragraphCells(para, psrc, stBase.Foreground(cFg)), width, nil, nil, psrc[0])...)
		}
	}
	return out
}

func isContinuation(line string) bool {
	return strings.HasPrefix(line, "  ") || strings.HasPrefix(line, "\t")
}
