/*
   goedit
   Editor de texto para terminal (TUI), com realce de sintaxe, plugins Lua, seleção em bloco e mais
   Site:      https://chililinux.com
   Site:      https://voidbr.org
   Site:      https://voidlinux.com.br
   GitHub:    https://github.com/voidlinuxbr/voidbr-goedit
   Created:   ter 20 out 2026 21:11:29 -04
   Updated:   ter 20 out 2026 21:27:16 -04
   Version:   0.45.0
   Copyright (C) 2019-2026 Vilmar Catafesta <vcatafesta@gmail.com>
*/

// Package markdown dá suporte a arquivos .md no goedit: realce de
// sintaxe consciente de blocos (cercas de código, tabelas, listas,
// citações...) no modo de edição, e um modo preview que renderiza o
// documento formatado no próprio terminal (F5 alterna).
package markdown

import (
	"path/filepath"
	"strings"
)

// IsMarkdown diz se o arquivo é Markdown pela extensão.
func IsMarkdown(path string) bool {
	switch strings.ToLower(filepath.Ext(path)) {
	case ".md", ".markdown", ".mdown", ".mkd", ".mkdn", ".mdwn", ".mdx":
		return true
	}
	return false
}

// flag marca o "tipo" de um pedaço de texto inline.
type flag uint16

const (
	fBold flag = 1 << iota
	fItalic
	fStrike
	fCode
	fLink
	fURL
	fMarker // sintaxe do markdown (**, `, [, ](...) — some no preview
	fImage
	fHTML
)

type span struct {
	text string
	f    flag
}

func isSpaceB(c byte) bool { return c == ' ' || c == '\t' }
func isAlnumB(c byte) bool {
	return c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || c >= 0x80
}
func isPunctB(c byte) bool { return strings.IndexByte("!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~", c) >= 0 }

func runLen(s string, i int, c byte) int {
	j := i
	for j < len(s) && s[j] == c {
		j++
	}
	return j - i
}

// findCodeClose acha a sequência de crases de mesmo tamanho que fecha
// um `código inline`.
func findCodeClose(s string, from, n int) int {
	for k := from; k < len(s); {
		if s[k] == '`' {
			r := runLen(s, k, '`')
			if r == n {
				return k
			}
			k += r
			continue
		}
		k++
	}
	return -1
}

// findEmphClose acha o fechamento de uma ênfase (*, **, _, __...) com
// o mesmo número de marcadores, pulando código inline e escapes.
func findEmphClose(s string, from int, c byte, n int) int {
	for k := from; k < len(s); {
		switch s[k] {
		case '`':
			r := runLen(s, k, '`')
			if j := findCodeClose(s, k+r, r); j >= 0 {
				k = j + r
			} else {
				k += r
			}
			continue
		case '\\':
			k += 2
			continue
		case c:
			r := runLen(s, k, c)
			if r == n && k > from && !isSpaceB(s[k-1]) &&
				(c != '_' || k+r >= len(s) || !isAlnumB(s[k+r])) {
				return k
			}
			k += r
			continue
		}
		k++
	}
	return -1
}

// parseLinkAt reconhece [texto](url) a partir de s[i] == '['.
func parseLinkAt(s string, i int) (text, url string, end int, ok bool) {
	depth, j := 0, i
	closed := false
	for ; j < len(s) && !closed; j++ {
		switch s[j] {
		case '\\':
			j++
		case '[':
			depth++
		case ']':
			depth--
			if depth == 0 {
				closed = true
				j-- // compensa o j++ do for
			}
		}
	}
	if !closed || j+1 >= len(s) || s[j+1] != '(' {
		return "", "", 0, false
	}
	depth = 0
	for k := j + 1; k < len(s); k++ {
		switch s[k] {
		case '(':
			depth++
		case ')':
			depth--
			if depth == 0 {
				return s[i+1 : j], s[j+2 : k], k + 1, true
			}
		}
	}
	return "", "", 0, false
}

func isAutolink(s string) bool {
	return strings.HasPrefix(s, "http://") || strings.HasPrefix(s, "https://") ||
		strings.HasPrefix(s, "mailto:") || (strings.Contains(s, "@") && !strings.ContainsAny(s, " <>"))
}

func isHTMLTag(s string) bool {
	if s == "" {
		return false
	}
	t := strings.TrimPrefix(s, "/")
	return t != "" && (t[0] >= 'a' && t[0] <= 'z' || t[0] >= 'A' && t[0] <= 'Z')
}

// parseInline quebra uma linha (ou parágrafo) em pedaços marcados com o
// tipo de formatação inline. Os marcadores da sintaxe (**, `, etc.)
// viram pedaços próprios com fMarker — o realce de edição mostra eles
// apagadinhos, o preview simplesmente pula.
func parseInline(s string, f flag) []span {
	var out []span
	var lit strings.Builder
	flush := func() {
		if lit.Len() > 0 {
			out = append(out, span{lit.String(), f})
			lit.Reset()
		}
	}
	emit := func(t string, ff flag) {
		flush()
		if t != "" {
			out = append(out, span{t, ff})
		}
	}
	nest := func(t string, ff flag) {
		flush()
		out = append(out, parseInline(t, ff)...)
	}

	for i := 0; i < len(s); {
		c := s[i]
		if f&fCode != 0 {
			lit.WriteByte(c)
			i++
			continue
		}
		switch {
		case c == '\\' && i+1 < len(s) && isPunctB(s[i+1]):
			emit("\\", f|fMarker)
			lit.WriteByte(s[i+1])
			i += 2
			continue

		case c == '`':
			n := runLen(s, i, '`')
			if j := findCodeClose(s, i+n, n); j >= 0 {
				emit(s[i:i+n], f|fCode|fMarker)
				emit(s[i+n:j], f|fCode)
				emit(s[j:j+n], f|fCode|fMarker)
				i = j + n
				continue
			}
			lit.WriteString(s[i : i+n])
			i += n
			continue

		case c == '!' && i+1 < len(s) && s[i+1] == '[':
			if txt, url, end, ok := parseLinkAt(s, i+1); ok {
				emit("![", f|fMarker|fImage)
				nest(txt, f|fImage)
				emit("](", f|fMarker|fImage)
				emit(url, f|fURL|fImage)
				emit(")", f|fMarker|fImage)
				i = end
				continue
			}

		case c == '[':
			if txt, url, end, ok := parseLinkAt(s, i); ok {
				emit("[", f|fMarker|fLink)
				nest(txt, f|fLink)
				emit("](", f|fMarker|fLink)
				emit(url, f|fURL)
				emit(")", f|fMarker|fLink)
				i = end
				continue
			}

		case c == '<':
			if strings.HasPrefix(s[i:], "<!--") {
				j := strings.Index(s[i+4:], "-->")
				end := len(s)
				if j >= 0 {
					end = i + 4 + j + 3
				}
				emit(s[i:end], f|fHTML)
				i = end
				continue
			}
			if j := strings.IndexByte(s[i:], '>'); j > 0 {
				inner := s[i+1 : i+j]
				if isAutolink(inner) {
					emit("<", f|fMarker)
					emit(inner, f|fURL|fLink)
					emit(">", f|fMarker)
					i += j + 1
					continue
				}
				if isHTMLTag(inner) {
					emit(s[i:i+j+1], f|fHTML)
					i += j + 1
					continue
				}
			}

		case c == '*' || c == '_':
			r := runLen(s, i, c)
			opensOK := i+r < len(s) && !isSpaceB(s[i+r]) &&
				!(c == '_' && i > 0 && isAlnumB(s[i-1]))
			if opensOK && r <= 3 {
				if j := findEmphClose(s, i+r, c, r); j >= 0 {
					ff := f
					if r == 1 || r == 3 {
						ff |= fItalic
					}
					if r >= 2 {
						ff |= fBold
					}
					emit(s[i:i+r], f|fMarker)
					nest(s[i+r:j], ff)
					emit(s[j:j+r], f|fMarker)
					i = j + r
					continue
				}
			}
			lit.WriteString(s[i : i+r])
			i += r
			continue

		case c == '~' && strings.HasPrefix(s[i:], "~~"):
			if j := strings.Index(s[i+2:], "~~"); j > 0 {
				emit("~~", f|fMarker)
				nest(s[i+2:i+2+j], f|fStrike)
				emit("~~", f|fMarker)
				i = i + 2 + j + 2
				continue
			}

		case c == 'h' && (i == 0 || !isAlnumB(s[i-1])) &&
			(strings.HasPrefix(s[i:], "https://") || strings.HasPrefix(s[i:], "http://")):
			j := i
			for j < len(s) && !isSpaceB(s[j]) && s[j] != ')' && s[j] != '>' && s[j] != '|' {
				j++
			}
			for j > i && strings.IndexByte(".,;:!?", s[j-1]) >= 0 {
				j--
			}
			emit(s[i:j], f|fURL|fLink)
			i = j
			continue
		}
		lit.WriteByte(c)
		i++
	}
	flush()
	return out
}
