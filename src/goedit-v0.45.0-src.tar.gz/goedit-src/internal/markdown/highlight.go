/*
   goedit
   Editor de texto para terminal (TUI), com realce de sintaxe, plugins Lua, seleção em bloco e mais
   Site:      https://chililinux.com
   Site:      https://voidbr.org
   Site:      https://voidlinux.com.br
   GitHub:    https://github.com/voidlinuxbr/voidbr-goedit
   Created:   ter 20 out 2026 21:11:29 -04
   Updated:   ter 20 out 2026 21:27:16 -04
   Version:   0.45.0
   Copyright (C) 2019-2026 Vilmar Catafesta <vcatafesta@gmail.com>
*/

package markdown

import (
	"strings"

	"github.com/gdamore/tcell/v2"

	"goedit/internal/syntax"
)

// cores (tons do Tokyo Night)
func rgb(h int32) tcell.Color { return tcell.NewHexColor(h) }

var (
	cFg      = rgb(0xc0caf5)
	cDim     = rgb(0x565f89)
	cQuote   = rgb(0x9aa5ce)
	cOrange  = rgb(0xff9e64)
	cYellow  = rgb(0xe0af68)
	cGreen   = rgb(0x9ece6a)
	cBlue    = rgb(0x7aa2f7)
	cCyan    = rgb(0x7dcfff)
	cMagenta = rgb(0xbb9af7)
	cBorder  = rgb(0x3b4261)
	cCodeBg  = rgb(0x1f2335)
	cInlBg   = rgb(0x292e42)

	headingColors = []tcell.Color{rgb(0x7aa2f7), rgb(0xbb9af7), rgb(0x7dcfff), rgb(0x9ece6a), rgb(0xe0af68), rgb(0xff9e64)}

	stBase   = tcell.StyleDefault
	stDim    = tcell.StyleDefault.Foreground(cDim)
	stHTML   = tcell.StyleDefault.Foreground(cDim).Italic(true)
	stCode   = tcell.StyleDefault.Foreground(cOrange)
	stFence  = tcell.StyleDefault.Foreground(cDim)
	stLang   = tcell.StyleDefault.Foreground(cYellow).Italic(true)
	stBullet = tcell.StyleDefault.Foreground(cYellow).Bold(true)
	stQuote  = tcell.StyleDefault.Foreground(cMagenta)
	stPipe   = tcell.StyleDefault.Foreground(cBlue)
)

func headingStyle(level int) tcell.Style {
	if level < 1 {
		level = 1
	}
	if level > 6 {
		level = 6
	}
	return tcell.StyleDefault.Foreground(headingColors[level-1]).Bold(true)
}

// --- classificação de linhas (blocos) ---

type lineKind uint8

const (
	kText lineKind = iota
	kBlank
	kHeading
	kSetextText
	kSetextUnder
	kHR
	kFenceOpen
	kFenceClose
	kCode
	kIndCode
	kQuote
	kList
	kTable
	kTableDelim
	kHTML
	kFront
)

type lineInfo struct {
	kind  lineKind
	level int    // nível do título
	lang  string // linguagem do bloco cercado
}

func leadSpaces(s string) int {
	n := 0
	for n < len(s) && s[n] == ' ' {
		n++
	}
	return n
}

func fenceOpen(line string) (ch byte, n int, info string, ok bool) {
	ind := leadSpaces(line)
	if ind > 3 || ind >= len(line) {
		return 0, 0, "", false
	}
	c := line[ind]
	if c != '`' && c != '~' {
		return 0, 0, "", false
	}
	n = runLen(line, ind, c)
	if n < 3 {
		return 0, 0, "", false
	}
	info = strings.TrimSpace(line[ind+n:])
	if c == '`' && strings.Contains(info, "`") {
		return 0, 0, "", false
	}
	if f := strings.Fields(info); len(f) > 0 {
		info = strings.Trim(f[0], "{}.")
	}
	return c, n, info, true
}

func isFenceClose(line string, ch byte, n int) bool {
	ind := leadSpaces(line)
	if ind > 3 || ind >= len(line) || line[ind] != ch {
		return false
	}
	r := runLen(line, ind, ch)
	return r >= n && strings.TrimSpace(line[ind+r:]) == ""
}

func headingLevel(line string) int {
	ind := leadSpaces(line)
	if ind > 3 {
		return 0
	}
	n := runLen(line, ind, '#')
	if n < 1 || n > 6 {
		return 0
	}
	if ind+n < len(line) && line[ind+n] != ' ' && line[ind+n] != '\t' {
		return 0
	}
	return n
}

func isHR(line string) bool {
	t := strings.TrimSpace(line)
	if leadSpaces(line) > 3 || len(t) < 3 {
		return false
	}
	c := t[0]
	if c != '-' && c != '*' && c != '_' {
		return false
	}
	count := 0
	for i := 0; i < len(t); i++ {
		switch t[i] {
		case c:
			count++
		case ' ', '\t':
		default:
			return false
		}
	}
	return count >= 3
}

func setextLevel(line string) int {
	t := strings.TrimSpace(line)
	if leadSpaces(line) > 3 || t == "" {
		return 0
	}
	if strings.Trim(t, "=") == "" {
		return 1
	}
	if strings.Trim(t, "-") == "" {
		return 2
	}
	return 0
}

// listMarker devolve o fim do marcador (índice depois do espaço) e o
// marcador em si, ou ok=false se a linha não é item de lista.
func listMarker(line string) (indent int, marker string, rest int, ok bool) {
	i := 0
	for i < len(line) && (line[i] == ' ' || line[i] == '\t') {
		i++
	}
	if i >= len(line) {
		return 0, "", 0, false
	}
	start := i
	switch c := line[i]; {
	case c == '-' || c == '*' || c == '+':
		i++
	case c >= '0' && c <= '9':
		for i < len(line) && line[i] >= '0' && line[i] <= '9' && i-start < 9 {
			i++
		}
		if i >= len(line) || (line[i] != '.' && line[i] != ')') {
			return 0, "", 0, false
		}
		i++
	default:
		return 0, "", 0, false
	}
	if i < len(line) && line[i] != ' ' && line[i] != '\t' {
		return 0, "", 0, false
	}
	marker = line[start:i]
	for i < len(line) && (line[i] == ' ' || line[i] == '\t') {
		i++
	}
	return start, marker, i, true
}

func isQuote(line string) bool {
	ind := leadSpaces(line)
	return ind <= 3 && ind < len(line) && line[ind] == '>'
}

func isTableDelim(line string) bool {
	t := strings.TrimSpace(line)
	if !strings.Contains(t, "|") || !strings.Contains(t, "-") {
		return false
	}
	return strings.Trim(t, "|:- \t") == ""
}

func isIndented(line string) bool {
	return strings.HasPrefix(line, "    ") || strings.HasPrefix(line, "\t")
}

// classify percorre as linhas de cima até upto (inclusive) — o estado de
// bloco (dentro de cerca de código, tabela, comentário HTML...) depende
// de tudo o que veio antes, não dá pra decidir uma linha isolada.
func classify(lines []string, upto int) []lineInfo {
	if upto >= len(lines) {
		upto = len(lines) - 1
	}
	info := make([]lineInfo, upto+1)

	var fenceCh byte
	var fenceN int
	var fenceLang string
	inFence, inHTML, inFront, inTable, inList := false, false, false, false, false
	prev := kBlank

	for i := 0; i <= upto; i++ {
		line := lines[i]
		t := strings.TrimSpace(line)
		k := kText
		li := lineInfo{}

		switch {
		case inFront:
			k = kFront
			if i > 0 && (t == "---" || t == "...") {
				inFront = false
			}
		case inFence:
			if isFenceClose(line, fenceCh, fenceN) {
				k = kFenceClose
				inFence = false
			} else {
				k = kCode
				li.lang = fenceLang
			}
		case inHTML:
			k = kHTML
			if strings.Contains(line, "-->") {
				inHTML = false
			}
		case i == 0 && t == "---":
			k = kFront
			inFront = true
		case t == "":
			k = kBlank
			inTable = false
		default:
			if ch, n, lang, ok := fenceOpen(line); ok {
				k = kFenceOpen
				li.lang = lang
				inFence, fenceCh, fenceN, fenceLang = true, ch, n, lang
				break
			}
			if strings.HasPrefix(t, "<!--") {
				k = kHTML
				if !strings.Contains(t[4:], "-->") {
					inHTML = true
				}
				break
			}
			if lv := headingLevel(line); lv > 0 {
				k = kHeading
				li.level = lv
				break
			}
			if inTable {
				if isTableDelim(line) {
					k = kTableDelim
				} else if strings.Contains(line, "|") {
					k = kTable
				} else {
					inTable = false
				}
				if inTable {
					break
				}
			}
			if strings.Contains(line, "|") && i+1 < len(lines) && isTableDelim(lines[i+1]) {
				k = kTable
				inTable = true
				break
			}
			if lv := setextLevel(line); lv > 0 && prev == kText && i > 0 {
				k = kSetextUnder
				li.level = lv
				info[i-1].kind = kSetextText
				info[i-1].level = lv
				break
			}
			if isHR(line) {
				k = kHR
				break
			}
			if _, _, _, ok := listMarker(line); ok {
				k = kList
				inList = true
				break
			}
			if isQuote(line) {
				k = kQuote
				break
			}
			if isIndented(line) && !inList && (prev == kBlank || prev == kIndCode) {
				k = kIndCode
				break
			}
			if prev == kBlank && !isIndented(line) {
				inList = false
			}
		}
		li.kind = k
		info[i] = li
		if k != kBlank {
			prev = k
		} else {
			prev = kBlank
		}
	}
	return info
}

// --- realce do modo de edição ---

func editStyle(f flag, b tcell.Style) tcell.Style {
	switch {
	case f&fHTML != 0:
		return stHTML
	case f&fMarker != 0:
		if f&fCode != 0 {
			return stCode.Dim(true)
		}
		return stDim
	case f&fCode != 0:
		return stCode
	case f&fURL != 0:
		return tcell.StyleDefault.Foreground(cCyan).Underline(true)
	case f&fImage != 0:
		b = b.Foreground(cGreen)
	case f&fLink != 0:
		b = b.Foreground(cBlue).Underline(true)
	}
	if f&fBold != 0 {
		b = b.Bold(true)
	}
	if f&fItalic != 0 {
		b = b.Italic(true)
	}
	if f&fStrike != 0 {
		b = b.StrikeThrough(true).Foreground(cDim)
	}
	return b
}

func inlineSegs(s string, b tcell.Style) []syntax.Segment {
	var segs []syntax.Segment
	for _, sp := range parseInline(s, 0) {
		segs = append(segs, syntax.Segment{Text: sp.text, Style: editStyle(sp.f, b)})
	}
	return segs
}

// splitTableCells divide uma linha de tabela nos "|" que não estão
// escapados nem dentro de `código`. Devolve os pedaços entre pipes,
// incluindo as bordas (vazias se a linha começa/termina com "|").
func splitTableCells(line string) []string {
	var cells []string
	start, inCode := 0, false
	for i := 0; i < len(line); i++ {
		switch line[i] {
		case '\\':
			i++
		case '`':
			inCode = !inCode
		case '|':
			if !inCode {
				cells = append(cells, line[start:i])
				start = i + 1
			}
		}
	}
	return append(cells, line[start:])
}

func highlightLine(line string, li lineInfo, header bool) []syntax.Segment {
	switch li.kind {
	case kBlank:
		return []syntax.Segment{{Text: line, Style: stBase}}
	case kFront:
		t := strings.TrimSpace(line)
		if t == "---" || t == "..." {
			return []syntax.Segment{{Text: line, Style: stFence}}
		}
		return syntax.HighlightCode("yaml", line, stBase)
	case kFenceOpen:
		ind := leadSpaces(line)
		n := ind
		for n < len(line) && (line[n] == '`' || line[n] == '~') {
			n++
		}
		return []syntax.Segment{{Text: line[:n], Style: stFence}, {Text: line[n:], Style: stLang}}
	case kFenceClose:
		return []syntax.Segment{{Text: line, Style: stFence}}
	case kCode:
		return syntax.HighlightCode(li.lang, line, stBase.Foreground(rgb(0xa9b1d6)))
	case kIndCode:
		return []syntax.Segment{{Text: line, Style: stCode}}
	case kHTML:
		return []syntax.Segment{{Text: line, Style: stHTML}}
	case kHR, kTableDelim:
		return []syntax.Segment{{Text: line, Style: stDim}}
	case kSetextUnder:
		return []syntax.Segment{{Text: line, Style: headingStyle(li.level)}}
	case kSetextText:
		return inlineSegs(line, headingStyle(li.level))
	case kHeading:
		hs := headingStyle(li.level)
		ind := leadSpaces(line)
		n := ind + li.level
		return append([]syntax.Segment{{Text: line[:n], Style: hs.Dim(true)}}, inlineSegs(line[n:], hs)...)
	case kList:
		_, _, rest, _ := listMarker(line)
		segs := []syntax.Segment{{Text: line[:rest], Style: stBullet}}
		body := line[rest:]
		if len(body) >= 3 && body[0] == '[' && body[2] == ']' && strings.ContainsRune(" xX", rune(body[1])) {
			cb := stDim
			if body[1] != ' ' {
				cb = tcell.StyleDefault.Foreground(cGreen).Bold(true)
			}
			segs = append(segs, syntax.Segment{Text: body[:3], Style: cb})
			body = body[3:]
		}
		return append(segs, inlineSegs(body, stBase)...)
	case kQuote:
		i := 0
		for i < len(line) && (line[i] == '>' || line[i] == ' ') {
			i++
		}
		return append([]syntax.Segment{{Text: line[:i], Style: stQuote.Bold(true)}},
			inlineSegs(line[i:], stBase.Foreground(cQuote).Italic(true))...)
	case kTable:
		b := stBase
		if header {
			b = b.Bold(true)
		}
		var segs []syntax.Segment
		for ci, cell := range splitTableCells(line) {
			if ci > 0 {
				segs = append(segs, syntax.Segment{Text: "|", Style: stPipe})
			}
			segs = append(segs, inlineSegs(cell, b)...)
		}
		return segs
	}
	return inlineSegs(line, stBase)
}

// HighlightRange devolve o realce das linhas [from, to] de um arquivo
// Markdown, levando em conta o contexto de bloco das linhas anteriores.
func HighlightRange(lines []string, from, to int) [][]syntax.Segment {
	if len(lines) == 0 || from > to {
		return nil
	}
	if to >= len(lines) {
		to = len(lines) - 1
	}
	// +1: o setext ("Título\n=====") só se decide olhando a linha de baixo
	look := to + 1
	if look >= len(lines) {
		look = len(lines) - 1
	}
	info := classify(lines, look)
	out := make([][]syntax.Segment, 0, to-from+1)
	for i := from; i <= to; i++ {
		header := info[i].kind == kTable && i+1 < len(info) && info[i+1].kind == kTableDelim
		out = append(out, highlightLine(lines[i], info[i], header))
	}
	return out
}
