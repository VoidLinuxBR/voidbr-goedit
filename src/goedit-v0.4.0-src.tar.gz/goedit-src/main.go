package main

import (
	"fmt"
	"os"

	"github.com/gdamore/tcell/v2"

	"goedit/internal/ui"
)

// Version é atualizada a cada release (ver CHANGELOG.md).
const Version = "0.4.0"

func main() {
	if len(os.Args) > 1 && (os.Args[1] == "--version" || os.Args[1] == "-v") {
		fmt.Printf("goedit v%s\n", Version)
		return
	}

	screen, err := tcell.NewScreen()
	if err != nil {
		fmt.Fprintln(os.Stderr, "erro ao iniciar terminal:", err)
		os.Exit(1)
	}
	if err := screen.Init(); err != nil {
		fmt.Fprintln(os.Stderr, "erro ao iniciar terminal:", err)
		os.Exit(1)
	}
	defer screen.Fini()
	screen.SetStyle(tcell.StyleDefault)
	screen.EnableMouse()

	var initialPath string
	if len(os.Args) > 1 {
		initialPath = os.Args[1]
	}

	app := ui.NewApp(screen, initialPath)
	defer app.Plugins.Close()

	app.Render()
	for !app.Quit {
		ev := screen.PollEvent()
		switch e := ev.(type) {
		case *tcell.EventResize:
			screen.Sync()
		case *tcell.EventKey:
			app.HandleKey(e)
		case *tcell.EventMouse:
			app.HandleMouse(e)
		}
		app.Render()
	}
}
