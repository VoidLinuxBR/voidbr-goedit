/*
   goedit
   Editor de texto para terminal (TUI), com realce de sintaxe, plugins Lua, seleção em bloco e mais
   Site:      https://chililinux.com
   Site:      https://voidbr.org
   Site:      https://voidlinux.com.br
   GitHub:    https://github.com/voidlinuxbr/voidbr-goedit
   Created:   dom 16 ago 2026 10:15:33 -04
   Updated:   sex 21 ago 2026 11:30:00 -04
   Version:   0.33.1
   Copyright (C) 2019-2026 Vilmar Catafesta <vcatafesta@gmail.com>
*/

// Package sysclip integra o clipboard interno do goedit com o
// clipboard do sistema. Detecta e usa a ferramenta certa disponível:
// wl-copy/wl-paste (pacote wl-clipboard) em Wayland, ou xclip/xsel em
// X11 — não assume um ambiente só, já que o goedit roda em terminais
// bem diferentes (Wayland puro, X11 tradicional, WSL, etc).
//
// Todas as funções falham silenciosamente se nenhuma ferramenta
// estiver instalada, ou não houver display gráfico nenhum (SSH sem
// encaminhamento, TTY puro) — nesses casos, o clipboard interno do
// goedit continua funcionando normalmente sozinho, só sem sincronizar
// com o resto do sistema.
package sysclip

import (
	"os/exec"
	"strings"
	"sync"
)

// clipCmds descreve os comandos de copiar/colar de uma ferramenta —
// tentadas em ordem até achar uma instalada.
type clipCmds struct {
	copyCmd  []string
	pasteCmd []string
}

var candidates = []clipCmds{
	{copyCmd: []string{"wl-copy"}, pasteCmd: []string{"wl-paste", "--no-newline"}},
	{copyCmd: []string{"xclip", "-selection", "clipboard"}, pasteCmd: []string{"xclip", "-selection", "clipboard", "-o"}},
	{copyCmd: []string{"xsel", "--clipboard", "--input"}, pasteCmd: []string{"xsel", "--clipboard", "--output"}},
}

var (
	mu       sync.Mutex
	lastGood int // índice da última ferramenta que funcionou — só uma dica de por onde começar, não trava nela pra sempre
)

// tryCopy tenta copiar usando o candidato de índice dado. Devolve false
// tanto se a ferramenta não estiver instalada quanto se estiver
// instalada mas falhar ao rodar (ex: wl-copy presente no disco só
// porque outro programa depende dele, mas sem compositor Wayland ativo
// — não basta existir, tem que funcionar de verdade).
func tryCopy(idx int, text string) bool {
	c := candidates[idx]
	if _, err := exec.LookPath(c.copyCmd[0]); err != nil {
		return false
	}
	cmd := exec.Command(c.copyCmd[0], c.copyCmd[1:]...)
	cmd.Stdin = strings.NewReader(text)
	return cmd.Run() == nil
}

func tryPaste(idx int) (string, bool) {
	c := candidates[idx]
	if _, err := exec.LookPath(c.pasteCmd[0]); err != nil {
		return "", false
	}
	cmd := exec.Command(c.pasteCmd[0], c.pasteCmd[1:]...)
	out, err := cmd.Output()
	if err != nil {
		return "", false
	}
	return string(out), true
}

// Copy manda o texto pro clipboard do sistema, tentando cada
// ferramenta candidata de verdade (não só checando se está instalada)
// até uma funcionar — começa pela última que funcionou da vez
// anterior, e cai pras outras se essa parar de funcionar (ex: mudou de
// sessão gráfica). Se nenhuma funcionar, não faz nada: o clipboard
// interno do goedit continua normal, só sem sincronizar.
func Copy(text string) {
	mu.Lock()
	start := lastGood
	mu.Unlock()
	for i := 0; i < len(candidates); i++ {
		idx := (start + i) % len(candidates)
		if tryCopy(idx, text) {
			mu.Lock()
			lastGood = idx
			mu.Unlock()
			return
		}
	}
}

// Paste lê o clipboard do sistema, com a mesma lógica de tentativa e
// fallback do Copy. ok=false se nenhuma ferramenta funcionar ou o
// clipboard do sistema estiver vazio.
func Paste() (text string, ok bool) {
	mu.Lock()
	start := lastGood
	mu.Unlock()
	for i := 0; i < len(candidates); i++ {
		idx := (start + i) % len(candidates)
		if text, ok := tryPaste(idx); ok {
			mu.Lock()
			lastGood = idx
			mu.Unlock()
			return text, true
		}
	}
	return "", false
}
