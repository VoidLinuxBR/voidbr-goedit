package ui

import (
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"github.com/gdamore/tcell/v2"

	"goedit/internal/buffer"
	"goedit/internal/config"
	"goedit/internal/plugin"
)

// App é o estado global do editor.
type App struct {
	Screen tcell.Screen

	// cache da contagem de palavras da barra de status — recontar o
	// arquivo inteiro em TODO frame (mesmo sem editar nada) era um
	// desperdício real, medido em ~1-3ms por tecla em arquivos grandes.
	wcCacheBufIdx int
	wcCacheCount  int
	wcCacheAt     time.Time

	Buffers    []*buffer.Buffer
	Panes      []int // índice do buffer mostrado em cada painel (1 ou 2 painéis)
	ActivePane int

	ShowSidebar    bool
	SidebarFocused bool
	SidebarPath    string
	SidebarEntries []os.DirEntry
	SidebarSel     int
	SidebarOffset  int // rolagem vertical da lista de arquivos
	SidebarWidth   int

	// busca incremental por digitação (type-ahead): digitar letras pula
	// pro primeiro arquivo/pasta cujo nome começa com o que foi
	// digitado; pausar um instante reinicia a busca do zero.
	SidebarSearchBuf  string
	SidebarSearchTime time.Time

	// prompt genérico (usado por save-as, abrir arquivo, busca, substituir, paleta de comandos)
	PromptActive bool
	PromptLabel  string
	PromptInput  string
	onSubmit     func(input string)
	onCancel     func()

	LastSearch string
	StatusMsg  string
	Clipboard  string

	Settings      config.Settings
	OverwriteMode bool

	// Estado do "renomear ao vivo" (F2) — mostra todas as ocorrências da
	// palavra destacadas e vai atualizando o texto conforme o usuário
	// digita o novo nome, como o Rename Symbol do VS Code.
	RenameActive       bool
	RenameWord         string
	RenameNew          string
	RenameCursor       int  // posição do cursor dentro de RenameNew (em bytes)
	RenameSelecting    bool // true se há um trecho marcado dentro do campo
	RenameSelStart     int  // âncora da marcação dentro do campo (em bytes)
	RenameOrigLines    []string
	RenamePaneBuf      int // índice do buffer sendo renomeado
	RenameOccs         []buffer.WordOccurrence
	RenameOriginOccIdx int // índice em RenameOccs da ocorrência onde o F2 foi apertado — é onde o cursor fica

	Plugins *plugin.Manager

	Quit bool

	// Autocompletar por palavras do buffer (estilo Vim/keyword completion —
	// não é IntelliSense semântico, é busca de palavras já usadas no
	// texto). Ativa depois de digitar algumas letras de um identificador;
	// setas navegam, Tab/Enter aceita, Esc ou continuar digitando fora
	// do padrão cancela.
	SuggestActive bool
	SuggestItems  []string
	SuggestIndex  int
	SuggestPrefix string
	SuggestStartX int // coluna onde a palavra sendo completada começa
	SuggestY      int // linha da palavra sendo completada

	// Seleção em bloco/coluna (Ctrl+Shift+setas) — marca um retângulo de
	// texto (mesma faixa de colunas em várias linhas) e permite trocar
	// aquele pedaço em todas as linhas de uma vez, digitando uma única
	// vez. Parecido com o F2, mas na vertical em vez de "todas as
	// ocorrências da palavra".
	BlockActive    bool // true enquanto ainda está só marcando (antes de digitar)
	BlockEditing   bool // true depois que já começou a digitar (linhas/colunas travadas)
	BlockAnchorY   int  // linha onde a marcação começou
	BlockAnchorX   int  // coluna onde a marcação começou
	BlockRowStart  int  // linha inicial do retângulo (travada ao começar a editar)
	BlockRowEnd    int  // linha final do retângulo (inclusive)
	BlockColWidth  int  // largura da faixa de colunas marcada (0 = só um ponto de inserção)
	BlockTyped     string
	BlockOrigLines []string
	BlockPaneBuf   int

	// Destaque do termo buscado (Ctrl+F / F3) — persiste até a próxima
	// busca, editar algo, ou Esc.
	SearchHighlightActive bool
	SearchHighlightBuf    int
	SearchHighlightY      int
	SearchHighlightX0     int
	SearchHighlightX1     int

	// Tela de ajuda (F1) — lista de atalhos, com rolagem.
	HelpActive bool
	HelpScroll int

	// Menu de contexto (botão direito do mouse) — usado tanto nas abas
	// do editor quanto no título da sidebar.
	ContextMenuActive bool
	ContextMenuX      int // canto superior esquerdo do menu, em coluna de tela
	ContextMenuY      int
	ContextMenuItems  []ContextMenuItem

	// Redimensionamento da sidebar por arrasto do mouse na divisória.
	ResizingSidebar bool

	// Layout guarda onde cada elemento foi desenhado no último Render(),
	// pra HandleMouse saber o que está embaixo de um clique.
	Layout RenderLayout
}

// ContextMenuItem é uma opção do menu de contexto (botão direito).
type ContextMenuItem struct {
	Label  string
	Action func(a *App)
}

// OpenContextMenu abre o menu de contexto na posição dada, com os itens
// passados. Fecha qualquer menu que já estivesse aberto antes.
func (a *App) OpenContextMenu(x, y int, items []ContextMenuItem) {
	a.ContextMenuActive = true
	a.ContextMenuX = x
	a.ContextMenuY = y
	a.ContextMenuItems = items
}

// CloseContextMenu fecha o menu de contexto sem executar nada.
func (a *App) CloseContextMenu() {
	a.ContextMenuActive = false
	a.ContextMenuItems = nil
}

// PaneLayout é a área ocupada por um painel na última renderização.
type PaneLayout struct {
	BufIdx            int
	X, TabY           int // coluna inicial do painel; linha da barra de abas
	TextTop, TextX    int // linha onde o texto começa; coluna onde o texto começa (depois do gutter)
	Width, TextHeight int
	Gutter            int
	TabRanges         []TabRange // faixas de coluna [X0,X1) de cada aba desenhada, pra saber em qual clicou
}

// TabRange é a faixa horizontal ocupada pelo rótulo de uma aba na barra de abas.
type TabRange struct {
	BufIdx           int
	X0, X1           int
	CloseX0, CloseX1 int // faixa do "x" de fechar, dentro da aba
}

// RenderLayout é o layout inteiro da última tela desenhada.
type RenderLayout struct {
	SidebarX0, SidebarY0, SidebarX1, SidebarY1 int
	SidebarVisible                             bool
	SidebarRowY0                               int // linha da primeira entrada da lista (depois do cabeçalho)
	SidebarCloseX0, SidebarCloseX1             int // faixa do "x" de fechar no título da sidebar
	SidebarBorderX                             int // coluna da divisória (│) entre a sidebar e o texto — arrastável
	Panes                                      []PaneLayout
}

// NewApp cria o app com um buffer inicial (arquivo passado por argumento, ou vazio).
func NewApp(screen tcell.Screen, initialPaths []string) *App {
	a := &App{
		Screen:       screen,
		ShowSidebar:  len(initialPaths) == 0, // sem arquivo: abre com a sidebar; com arquivo: como já era
		SidebarWidth: 28,
		Settings:     config.LoadSettings(),
	}

	var buf *buffer.Buffer
	if len(initialPaths) > 0 {
		b, err := buffer.Open(initialPaths[0])
		if err != nil {
			buf = buffer.New()
			a.StatusMsg = fmt.Sprintf("erro ao abrir %s: %v", initialPaths[0], err)
		} else {
			buf = b
		}
	} else {
		buf = buffer.New()
	}
	a.Buffers = append(a.Buffers, buf)
	a.Panes = []int{0}

	// arquivos extras (ex: "goedit *.sh" expandido pelo shell em vários
	// argumentos) abrem como abas a mais, sem tirar o foco do primeiro.
	var openErrs []string
	for i := 1; i < len(initialPaths); i++ {
		p := initialPaths[i]
		b, err := buffer.Open(p)
		if err != nil {
			openErrs = append(openErrs, p)
			continue
		}
		a.Buffers = append(a.Buffers, b)
	}
	if len(openErrs) > 0 {
		a.StatusMsg = fmt.Sprintf("erro ao abrir: %s", strings.Join(openErrs, ", "))
	}
	a.Panes[0] = 0 // garante que o primeiro arquivo passado fica ativo, não o último aberto

	cwd, _ := os.Getwd()
	if len(initialPaths) > 0 {
		if abs, err := filepath.Abs(filepath.Dir(initialPaths[0])); err == nil {
			cwd = abs
		}
	}
	a.SidebarPath = cwd
	a.reloadSidebar()
	a.SidebarFocused = a.ShowSidebar // já abre navegável quando começa visível

	a.Plugins = plugin.NewManager(a, config.PluginDir())
	if errs := a.Plugins.LoadAll(); len(errs) > 0 {
		a.StatusMsg = fmt.Sprintf("erro carregando plugin: %v", errs[0])
	}

	return a
}

// ActiveBuffer devolve o buffer mostrado no painel com foco.
func (a *App) ActiveBuffer() *buffer.Buffer {
	return a.Buffers[a.Panes[a.ActivePane]]
}

// parentDirEntry é uma entrada sintética ".." que aparece no topo da
// listagem da sidebar (quando não estamos na raiz do sistema de
// arquivos), pra dar um jeito óbvio e clicável de voltar pra pasta
// anterior — sem isso, só dava pra voltar com Backspace, o que não é
// nada óbvio de descobrir.
type parentDirEntry struct{}

func (parentDirEntry) Name() string               { return ".." }
func (parentDirEntry) IsDir() bool                { return true }
func (parentDirEntry) Type() os.FileMode          { return os.ModeDir }
func (parentDirEntry) Info() (os.FileInfo, error) { return nil, nil }

func (a *App) reloadSidebar() {
	entries, err := os.ReadDir(a.SidebarPath)
	if err != nil {
		a.SidebarEntries = nil
		return
	}
	sort.Slice(entries, func(i, j int) bool {
		di, dj := entries[i].IsDir(), entries[j].IsDir()
		if di != dj {
			return di // diretórios primeiro
		}
		return entries[i].Name() < entries[j].Name()
	})
	if filepath.Dir(a.SidebarPath) != a.SidebarPath {
		// não estamos na raiz ("/" já é o próprio pai dela mesma)
		full := make([]os.DirEntry, 0, len(entries)+1)
		full = append(full, parentDirEntry{})
		full = append(full, entries...)
		entries = full
	}
	a.SidebarEntries = entries
	if a.SidebarSel >= len(a.SidebarEntries) {
		a.SidebarSel = 0
	}
	a.SidebarOffset = 0
}

// openSidebarEntry abre a entrada selecionada: entra na pasta (ou volta
// pra pasta anterior, se for a entrada ".."), ou abre o arquivo. Usado
// tanto pelo Enter do teclado quanto pelo clique do mouse, pra manter
// os dois com o mesmo comportamento.
func (a *App) openSidebarEntry(e os.DirEntry) {
	if e.Name() == ".." {
		a.SidebarPath = filepath.Dir(a.SidebarPath)
		a.SidebarSel = 0
		a.reloadSidebar()
		return
	}
	full := filepath.Join(a.SidebarPath, e.Name())
	if e.IsDir() {
		a.SidebarPath = full
		a.SidebarSel = 0
		a.reloadSidebar()
	} else {
		a.OpenFile(full)
		a.SidebarFocused = false
	}
}
func (a *App) OpenFile(path string) {
	for i, b := range a.Buffers {
		if b.Path == path {
			a.Panes[a.ActivePane] = i
			return
		}
	}
	b, err := buffer.Open(path)
	if err != nil {
		a.StatusMsg = fmt.Sprintf("erro ao abrir %s: %v", path, err)
		return
	}
	a.Buffers = append(a.Buffers, b)
	a.Panes[a.ActivePane] = len(a.Buffers) - 1
}

// NewBuffer cria uma aba nova vazia.
func (a *App) NewBuffer() {
	a.Buffers = append(a.Buffers, buffer.New())
	a.Panes[a.ActivePane] = len(a.Buffers) - 1
}

// CloseActiveBuffer fecha a aba ativa do painel focado.
func (a *App) CloseActiveBuffer() {
	a.CloseBufferAt(a.Panes[a.ActivePane])
}

// CloseBufferAt fecha o buffer no índice dado (usado tanto pelo Ctrl+W
// quanto pelo menu de contexto das abas, que pode fechar uma aba
// diferente da que está ativa no momento).
func (a *App) CloseBufferAt(idx int) {
	if idx < 0 || idx >= len(a.Buffers) {
		return
	}
	if len(a.Buffers) == 1 {
		a.Buffers[0] = buffer.New()
		return
	}
	a.Buffers = append(a.Buffers[:idx], a.Buffers[idx+1:]...)
	for i := range a.Panes {
		if a.Panes[i] >= len(a.Buffers) {
			a.Panes[i] = len(a.Buffers) - 1
		} else if a.Panes[i] > idx {
			a.Panes[i]--
		}
	}
}

// CloseOtherBuffersAt fecha todos os buffers menos o do índice dado.
func (a *App) CloseOtherBuffersAt(idx int) {
	if idx < 0 || idx >= len(a.Buffers) {
		return
	}
	keep := a.Buffers[idx]
	a.Buffers = []*buffer.Buffer{keep}
	for i := range a.Panes {
		a.Panes[i] = 0
	}
}

// CloseAllBuffers fecha todas as abas, voltando pra um único buffer novo.
func (a *App) CloseAllBuffers() {
	a.Buffers = []*buffer.Buffer{buffer.New()}
	for i := range a.Panes {
		a.Panes[i] = 0
	}
}

// SaveBufferAt salva o buffer no índice dado (troca o foco pra ele
// primeiro, já que o fluxo de salvar-como usa o buffer ativo).
func (a *App) SaveBufferAt(idx int) {
	if idx < 0 || idx >= len(a.Buffers) {
		return
	}
	a.Panes[a.ActivePane] = idx
	a.doSave()
}

// NextTab avança pra próxima aba no painel ativo.
func (a *App) NextTab() {
	idx := a.Panes[a.ActivePane]
	idx = (idx + 1) % len(a.Buffers)
	a.Panes[a.ActivePane] = idx
}

// PrevTab volta pra aba anterior no painel ativo.
func (a *App) PrevTab() {
	idx := a.Panes[a.ActivePane]
	idx = (idx - 1 + len(a.Buffers)) % len(a.Buffers)
	a.Panes[a.ActivePane] = idx
}

// ToggleSplit ativa ou desativa o segundo painel.
func (a *App) ToggleSplit() {
	if len(a.Panes) == 1 {
		a.Panes = append(a.Panes, a.Panes[0])
	} else {
		a.Panes = a.Panes[:1]
		a.ActivePane = 0
	}
}

// SwitchPaneFocus alterna o foco entre os painéis abertos.
func (a *App) SwitchPaneFocus() {
	if len(a.Panes) < 2 {
		return
	}
	a.ActivePane = (a.ActivePane + 1) % len(a.Panes)
}

// startPrompt abre uma caixa de entrada na barra inferior.
func (a *App) startPrompt(label string, onSubmit func(string), onCancel func()) {
	a.PromptActive = true
	a.PromptLabel = label
	a.PromptInput = ""
	a.onSubmit = onSubmit
	a.onCancel = onCancel
}

func (a *App) cancelPrompt() {
	a.PromptActive = false
	if a.onCancel != nil {
		a.onCancel()
	}
}

func (a *App) submitPrompt() {
	a.PromptActive = false
	if a.onSubmit != nil {
		a.onSubmit(a.PromptInput)
	}
}
