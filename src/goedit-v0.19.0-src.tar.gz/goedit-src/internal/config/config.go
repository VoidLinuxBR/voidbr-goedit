package config

import (
	"encoding/json"
	"os"
	"path/filepath"
)

// PluginDir devolve ~/.config/goedit/plugins, criando o diretório se preciso.
func PluginDir() string {
	home, err := os.UserHomeDir()
	if err != nil {
		return "plugins"
	}
	dir := filepath.Join(home, ".config", "goedit", "plugins")
	_ = os.MkdirAll(dir, 0o755)
	return dir
}

// Settings são as preferências configuráveis do editor.
// Ficam em ~/.config/goedit/settings.json — o arquivo não existe até o
// usuário criar um (LoadSettings devolve os padrões nesse caso).
type Settings struct {
	// TabWidth é quantas colunas uma tabulação ocupa na tela, e também
	// quantos espaços a tecla Tab insere quando InsertSpaces é true.
	TabWidth int `json:"tabWidth"`
	// InsertSpaces: true insere espaços ao apertar Tab (padrão da maioria
	// dos editores modernos); false insere um caractere de tabulação real.
	InsertSpaces bool `json:"insertSpaces"`
}

// rawSettings usa ponteiros pra distinguir "campo ausente no JSON" de
// "campo presente com valor zero" — um settings.json com só tabWidth não
// deve zerar insertSpaces sem querer.
type rawSettings struct {
	TabWidth     *int  `json:"tabWidth"`
	InsertSpaces *bool `json:"insertSpaces"`
}

func defaultSettings() Settings {
	return Settings{TabWidth: 4, InsertSpaces: true}
}

// settingsPath devolve ~/.config/goedit/settings.json.
func settingsPath() string {
	home, err := os.UserHomeDir()
	if err != nil {
		return "settings.json"
	}
	return filepath.Join(home, ".config", "goedit", "settings.json")
}

// LoadSettings lê ~/.config/goedit/settings.json. Se o arquivo não existir
// ou tiver erro de leitura/parse, devolve os padrões (TabWidth: 4,
// InsertSpaces: true) sem quebrar a inicialização do editor. Campos
// ausentes no JSON mantêm o valor padrão.
func LoadSettings() Settings {
	s := defaultSettings()
	data, err := os.ReadFile(settingsPath())
	if err != nil {
		return s
	}
	var raw rawSettings
	if err := json.Unmarshal(data, &raw); err != nil {
		return s
	}
	if raw.TabWidth != nil && *raw.TabWidth > 0 {
		s.TabWidth = *raw.TabWidth
	}
	if raw.InsertSpaces != nil {
		s.InsertSpaces = *raw.InsertSpaces
	}
	return s
}
