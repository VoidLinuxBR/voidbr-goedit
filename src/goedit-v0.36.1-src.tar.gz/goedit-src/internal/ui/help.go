/*
   goedit
   Editor de texto para terminal (TUI), com realce de sintaxe, plugins Lua, seleção em bloco e mais
   Site:      https://chililinux.com
   Site:      https://voidbr.org
   Site:      https://voidlinux.com.br
   GitHub:    https://github.com/voidlinuxbr/voidbr-goedit
   Created:   dom 16 ago 2026 10:15:33 -04
   Updated:   sex 21 ago 2026 11:30:00 -04
   Version:   0.36.1
   Copyright (C) 2019-2026 Vilmar Catafesta <vcatafesta@gmail.com>
*/

package ui

import "github.com/gdamore/tcell/v2"

// styleHelpSection é o estilo dos cabeçalhos de seção na tela de ajuda —
// mesma paleta do menu de contexto, só que com destaque a mais.
var styleHelpSection = styleContextMenu.Bold(true).Foreground(tcell.ColorYellow)

// helpLine é uma linha da tela de ajuda — Section preenchido marca um
// cabeçalho de seção; senão é uma linha normal de Key/Desc.
type helpLine struct {
	Section string
	Key     string
	Desc    string
}

// helpContent é a lista de atalhos mostrada no F1, organizada por seção
// — mantida manualmente, então precisa ser atualizada junto de novos
// atalhos (não é gerada automaticamente a partir do código de teclado).
var helpContent = []helpLine{
	{Section: "Arquivo"},
	{Key: "Ctrl+S", Desc: "Salvar"},
	{Key: "Ctrl+O", Desc: "Abrir arquivo (digita o caminho)"},
	{Key: "Ctrl+N", Desc: "Nova aba vazia"},
	{Key: "Ctrl+W", Desc: "Fecha aba; se for a última, fecha o goedit (avisa)"},
	{Key: "Ctrl+Q", Desc: "Sair (pergunta se houver aba com alteração)"},

	{Section: "Navegação"},
	{Key: "Alt+←/→", Desc: "Aba anterior / próxima"},
	{Key: "Ctrl+B", Desc: "Mostrar/ocultar sidebar de arquivos"},
	{Key: "Ctrl+\\", Desc: "Abrir/fechar split (2 painéis)"},
	{Key: "Ctrl+L", Desc: "Trocar painel (sem split: repete busca)"},
	{Key: "Ctrl+G", Desc: "Ir para linha"},
	{Key: "Ctrl+Home/End", Desc: "Início / fim do arquivo"},

	{Section: "Busca"},
	{Key: "Ctrl+F", Desc: "Buscar; Ctrl+C ou Esc cancela"},
	{Key: "F3", Desc: "Repetir última busca"},
	{Key: "Ctrl+H", Desc: "Buscar e substituir"},

	{Section: "Editar"},
	{Key: "Ctrl+Z / Ctrl+U", Desc: "Desfazer"},
	{Key: "Ctrl+Y", Desc: "Refazer"},
	{Key: "Ctrl+A", Desc: "Selecionar tudo"},
	{Key: "Ctrl+C / V", Desc: "Copiar / colar"},
	{Key: "Alt+X", Desc: "Cortar"},
	{Key: "Ctrl+X", Desc: "Salvar e sair"},
	{Key: "Ctrl+D", Desc: "Duplicar linha (pra baixo)"},
	{Key: "Shift+Alt+↑/↓", Desc: "Duplicar linha/bloco pra cima/baixo"},
	{Key: "Alt+↑/↓", Desc: "Mover linha pra cima/baixo"},
	{Key: "Ctrl+/", Desc: "Comentar (ou bloco, com seleção de várias linhas)"},
	{Key: "Ctrl+K", Desc: "Apagar linha (copia pro clipboard antes)"},
	{Key: "Delete", Desc: "Apagar caractere à frente (ou seleção)"},
	{Key: "Insert", Desc: "Alterna inserir/sobrescrever (INS/OVR)"},
	{Key: "Tab / Shift+Tab", Desc: "Indentar / remover indentação (com seleção)"},
	{Key: "Shift+Alt+F", Desc: "Formatar código (gofmt, shfmt, etc)"},

	{Section: "Seleção"},
	{Key: "Shift+↑/↓", Desc: "Marca linha inteira (não segue a coluna)"},
	{Key: "Shift+←/→", Desc: "Estende seleção por caractere"},
	{Key: "Shift+Home/End", Desc: "Estende seleção até início/fim da linha"},
	{Key: "Ctrl+Shift+setas", Desc: "Bloco/coluna — Enter confirma, Esc cancela"},

	{Section: "F2 — Renomear ao vivo"},
	{Key: "F2", Desc: "Renomeia todas as ocorrências, inline, ao vivo"},
	{Key: "Enter / Esc", Desc: "Confirma / cancela o F2"},

	{Section: "Autocompletar"},
	{Key: "↓/↑", Desc: "Navega entre sugestões"},
	{Key: "Tab / Enter", Desc: "Aceita a sugestão"},
	{Key: "Esc", Desc: "Cancela"},

	{Section: "Sidebar"},
	{Key: "↑/↓/PgUp/PgDn/Home/End", Desc: "Navega na lista"},
	{Key: "Enter", Desc: "Abre arquivo ou entra na pasta"},
	{Key: "Backspace", Desc: "Sobe um nível (ou clica em ../)"},
	{Key: "letras", Desc: "Busca incremental por nome"},

	{Section: "Comandos"},
	{Key: "Ctrl+P", Desc: "Paleta de comandos (plugins Lua)"},
	{Key: "F1", Desc: "Essa ajuda"},
	{Key: "F9", Desc: "Trocar perfil de teclas (vscode/nano/nano-hibrido)"},
}

// drawHelp desenha a tela de ajuda por cima de tudo — uma caixa grande
// centralizada com a lista de atalhos, rolável quando não cabe inteira.
func (a *App) drawHelp() {
	if !a.HelpActive {
		return
	}
	w, h := a.Screen.Size()
	marginX, marginY := 1, 2
	boxW, boxH := w-2*marginX, h-2*marginY
	if boxW < 20 || boxH < 8 {
		return // tela pequena demais pra mostrar com conforto
	}
	boxX, boxY := marginX, marginY

	for row := 0; row < boxH; row++ {
		for col := 0; col < boxW; col++ {
			a.Screen.SetContent(boxX+col, boxY+row, ' ', nil, styleContextMenu)
		}
	}

	a.Screen.SetContent(boxX, boxY, '┌', nil, styleContextMenu)
	for c := 1; c < boxW-1; c++ {
		a.Screen.SetContent(boxX+c, boxY, '─', nil, styleContextMenu)
	}
	a.Screen.SetContent(boxX+boxW-1, boxY, '┐', nil, styleContextMenu)
	for r := 1; r < boxH-1; r++ {
		a.Screen.SetContent(boxX, boxY+r, '│', nil, styleContextMenu)
		a.Screen.SetContent(boxX+boxW-1, boxY+r, '│', nil, styleContextMenu)
	}
	a.Screen.SetContent(boxX, boxY+boxH-1, '└', nil, styleContextMenu)
	for c := 1; c < boxW-1; c++ {
		a.Screen.SetContent(boxX+c, boxY+boxH-1, '─', nil, styleContextMenu)
	}
	a.Screen.SetContent(boxX+boxW-1, boxY+boxH-1, '┘', nil, styleContextMenu)

	title := "Ajuda — atalhos do goedit  (F1 ou Esc fecha · ↑↓/PgUp/PgDn rola)"
	drawText(a.Screen, boxX+2, boxY+1, styleContextMenu.Bold(true), truncate(title, boxW-4))

	contentTop := boxY + 3
	contentHeight := boxH - 5 // -5: borda de cima, título, borda de baixo, linha do indicador, +1 folga
	maxScroll := len(helpContent) - contentHeight
	if maxScroll < 0 {
		maxScroll = 0
	}
	if a.HelpScroll > maxScroll {
		a.HelpScroll = maxScroll
	}
	if a.HelpScroll < 0 {
		a.HelpScroll = 0
	}

	keyColWidth := 22
	for i := 0; i < contentHeight; i++ {
		idx := a.HelpScroll + i
		if idx >= len(helpContent) {
			break
		}
		line := helpContent[idx]
		row := contentTop + i
		if line.Section != "" {
			drawText(a.Screen, boxX+2, row, styleHelpSection, truncate(line.Section, boxW-4))
			continue
		}
		drawText(a.Screen, boxX+2, row, styleContextMenu.Bold(true), padVisual(line.Key, keyColWidth))
		drawText(a.Screen, boxX+2+keyColWidth+1, row, styleContextMenu, truncate(line.Desc, boxW-6-keyColWidth))
	}

	if len(helpContent) > contentHeight {
		indicator := "· rolagem: mais itens abaixo ·"
		if a.HelpScroll >= maxScroll {
			indicator = "· fim da lista ·"
		} else if a.HelpScroll == 0 {
			indicator = "· rolagem: mais itens abaixo ·"
		}
		drawText(a.Screen, boxX+2, boxY+boxH-2, styleContextMenu, truncate(indicator, boxW-4))
	}
}

// handleHelpKey trata as teclas da tela de ajuda: Esc/F1 fecha, setas e
// Page Up/Down rolam o conteúdo.
func (a *App) handleHelpKey(ev *tcell.EventKey) {
	switch ev.Key() {
	case tcell.KeyEsc, tcell.KeyF1:
		a.HelpActive = false
		a.HelpScroll = 0
	case tcell.KeyDown:
		a.HelpScroll++
	case tcell.KeyUp:
		if a.HelpScroll > 0 {
			a.HelpScroll--
		}
	case tcell.KeyPgDn:
		a.HelpScroll += 15
	case tcell.KeyPgUp:
		a.HelpScroll -= 15
		if a.HelpScroll < 0 {
			a.HelpScroll = 0
		}
	}
}
