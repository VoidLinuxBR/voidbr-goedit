package syntax

import (
	"path/filepath"
	"strings"
	"sync"

	"github.com/alecthomas/chroma/v2"
	"github.com/alecthomas/chroma/v2/lexers"
	"github.com/gdamore/tcell/v2"
)

// Segment é um pedaço de texto com uma cor associada.
type Segment struct {
	Text  string
	Style tcell.Style
}

var base = tcell.StyleDefault

// lexerCache guarda o lexer já resolvido por (nome de arquivo, 1ª linha).
// A 1ª linha só entra na chave quando o arquivo não tem extensão — é o
// que muda a detecção por shebang. Resolver o lexer (lexers.Match) varre
// a lista inteira de linguagens suportadas pelo chroma — caro demais pra
// fazer de novo a cada linha, em cada redraw.
var (
	lexerCacheMu sync.Mutex
	lexerCache   = map[string]chroma.Lexer{} // nil = arquivo sem lexer conhecido
)

// shebangInterpreter mapeia o nome do interpretador citado no shebang
// (#!/usr/bin/interpreter ou #!/usr/bin/env interpreter) pro nome/alias
// que o chroma reconhece. Cobre os casos onde o nome do binário difere
// do nome que o chroma usa (ex: "python3" -> "python").
var shebangInterpreter = map[string]string{
	"python3": "python",
	"python2": "python",
	"sh":      "bash",
	"dash":    "bash",
	"ksh":     "bash",
	"zsh":     "bash",
	"node":    "javascript",
	"nodejs":  "javascript",
}

// lexerFromShebang lê a primeira linha do arquivo e, se for um shebang
// (#!...), tenta achar um lexer do chroma pro interpretador citado.
func lexerFromShebang(firstLine string) chroma.Lexer {
	firstLine = strings.TrimSpace(firstLine)
	if !strings.HasPrefix(firstLine, "#!") {
		return nil
	}
	rest := strings.TrimSpace(strings.TrimPrefix(firstLine, "#!"))
	fields := strings.Fields(rest)
	if len(fields) == 0 {
		return nil
	}
	interpreter := filepath.Base(fields[0])
	if interpreter == "env" && len(fields) > 1 {
		interpreter = filepath.Base(fields[1])
	}
	if alias, ok := shebangInterpreter[interpreter]; ok {
		interpreter = alias
	}
	return lexers.Get(interpreter)
}

// lexerFor resolve o lexer pra um arquivo: primeiro pela extensão; se o
// arquivo não tem extensão reconhecida, tenta pelo shebang da 1ª linha;
// se ainda assim não achar nada e o arquivo não tem extensão, usa bash
// como padrão (é o caso mais comum de script sem extensão no dia a dia).
func lexerFor(filename, firstLine string) chroma.Lexer {
	hasExt := filepath.Ext(filename) != ""
	key := filename
	if !hasExt {
		key = filename + "\x00" + firstLine
	}

	lexerCacheMu.Lock()
	if lx, ok := lexerCache[key]; ok {
		lexerCacheMu.Unlock()
		return lx // pode ser nil, e está tudo bem — já sabemos que não tem highlight
	}
	lexerCacheMu.Unlock()

	lx := lexers.Match(filename)
	if lx == nil && !hasExt {
		lx = lexerFromShebang(firstLine)
		if lx == nil {
			lx = lexers.Get("bash")
		}
	}
	if lx != nil {
		lx = chroma.Coalesce(lx)
	}

	lexerCacheMu.Lock()
	lexerCache[key] = lx
	lexerCacheMu.Unlock()
	return lx
}

// styleFor mapeia a categoria de token do chroma pra uma cor do terminal.
func styleFor(t chroma.TokenType) tcell.Style {
	switch {
	case t.InCategory(chroma.Comment):
		return base.Foreground(tcell.ColorGray).Italic(true)
	case t.InCategory(chroma.Keyword):
		return base.Foreground(tcell.ColorSteelBlue).Bold(true)
	case t.InCategory(chroma.String):
		return base.Foreground(tcell.ColorOlive)
	case t.InCategory(chroma.Number):
		return base.Foreground(tcell.ColorPurple)
	case t.InCategory(chroma.Name):
		if t == chroma.NameFunction {
			return base.Foreground(tcell.ColorTeal)
		}
		return base
	case t.InCategory(chroma.Operator), t.InCategory(chroma.Punctuation):
		return base.Foreground(tcell.ColorSilver)
	default:
		return base
	}
}

// resultCache guarda o resultado já tokenizado por (arquivo, texto da linha).
// Mover o cursor redesenha a tela inteira, mas o conteúdo das linhas visíveis
// quase nunca muda entre um redraw e outro — então cacheamos o resultado.
var (
	resultCacheMu sync.Mutex
	resultCache   = map[string][]Segment{}
)

// DebugLexerName devolve o nome do lexer resolvido pra um arquivo (ou
// "nenhum" se não achou nenhum) — só pra diagnóstico/depuração.
func DebugLexerName(filename, firstLine string) string {
	lx := lexerFor(filename, firstLine)
	if lx == nil {
		return "nenhum"
	}
	return lx.Config().Name
}

// HighlightLine tokeniza uma linha de acordo com a linguagem do arquivo
// (detectada pela extensão, ou pelo shebang de firstLine se não houver
// extensão, ou bash como último recurso pra arquivos sem extensão).
func HighlightLine(filename, firstLine, line string) []Segment {
	key := filename + "\x00" + firstLine + "\x00" + line
	resultCacheMu.Lock()
	if segs, ok := resultCache[key]; ok {
		resultCacheMu.Unlock()
		return segs
	}
	resultCacheMu.Unlock()

	lexer := lexerFor(filename, firstLine)
	if lexer == nil {
		return []Segment{{Text: line, Style: base}}
	}
	iter, err := lexer.Tokenise(nil, line)
	if err != nil {
		return []Segment{{Text: line, Style: base}}
	}
	var segs []Segment
	for _, tok := range iter.Tokens() {
		if tok.Value == "" {
			continue
		}
		// chroma pode devolver a quebra de linha junto; removemos.
		txt := strings.TrimSuffix(tok.Value, "\n")
		if txt == "" {
			continue
		}
		segs = append(segs, Segment{Text: txt, Style: styleFor(tok.Type)})
	}
	if len(segs) == 0 {
		segs = []Segment{{Text: line, Style: base}}
	}

	resultCacheMu.Lock()
	if len(resultCache) > 5000 {
		// evita crescer sem limite em sessões muito longas de edição
		resultCache = map[string][]Segment{}
	}
	resultCache[key] = segs
	resultCacheMu.Unlock()
	return segs
}
