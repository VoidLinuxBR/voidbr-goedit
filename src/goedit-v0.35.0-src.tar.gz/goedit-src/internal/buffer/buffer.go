/*
   goedit
   Editor de texto para terminal (TUI), com realce de sintaxe, plugins Lua, seleção em bloco e mais
   Site:      https://chililinux.com
   Site:      https://voidbr.org
   Site:      https://voidlinux.com.br
   GitHub:    https://github.com/voidlinuxbr/voidbr-goedit
   Created:   dom 16 ago 2026 10:15:33 -04
   Updated:   sex 21 ago 2026 11:30:00 -04
   Version:   0.35.0
   Copyright (C) 2019-2026 Vilmar Catafesta <vcatafesta@gmail.com>
*/

package buffer

import (
	"bufio"
	"os"
	"strings"
	"unicode/utf8"
)

// Buffer representa um arquivo aberto no editor, com histórico de undo/redo.
type Buffer struct {
	Path                 string
	Lines                []string
	Dirty                bool
	CursorX              int
	CursorY              int
	OffsetY              int // linha do topo da viewport (scroll vertical)
	OffsetX              int // coluna do início da viewport (scroll horizontal)
	Selecting            bool
	SelStartX, SelStartY int

	undoStack []snapshot
	redoStack []snapshot

	// coalescing: agrupa uma sequência contínua de digitação (ou de backspaces)
	// num único snapshot de undo, em vez de um snapshot por tecla. Isso evita
	// copiar o buffer inteiro a cada caractere em arquivos grandes, e de quebra
	// faz o undo desfazer "a frase toda" de uma vez, como o Vim faz com um <C-i>.
	runKind byte // 0 = nenhuma, 'i' = inserindo, 'b' = apagando (backspace)
	runAtX  int
	runAtY  int
}

type snapshot struct {
	lines   []string
	cursorX int
	cursorY int
}

// breakRun encerra qualquer sequência de digitação/apagamento em andamento,
// forçando o próximo InsertRune/Backspace a criar um snapshot novo.
func (b *Buffer) breakRun() {
	b.runKind = 0
}

// MarkUndoPoint salva o estado atual como um ponto de undo, pra código
// fora do pacote (como o modo de renomear ao vivo da UI) poder mexer
// direto em b.Lines e ainda assim deixar um Ctrl+Z funcionando depois.
func (b *Buffer) MarkUndoPoint() {
	b.snapshotPush()
	b.breakRun()
}

// New cria um buffer vazio (arquivo novo, "sem nome").
func New() *Buffer {
	return &Buffer{
		Lines: []string{""},
	}
}

// Open carrega um arquivo do disco para um novo Buffer.
func Open(path string) (*Buffer, error) {
	f, err := os.Open(path)
	if err != nil {
		if os.IsNotExist(err) {
			// Arquivo novo: começa vazio mas já associado ao caminho.
			b := New()
			b.Path = path
			return b, nil
		}
		return nil, err
	}
	defer f.Close()

	var lines []string
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 1024*1024), 10*1024*1024)
	for sc.Scan() {
		lines = append(lines, sc.Text())
	}
	if len(lines) == 0 {
		lines = []string{""}
	}
	return &Buffer{Path: path, Lines: lines}, nil
}

// Save escreve o conteúdo do buffer de volta no disco.
func (b *Buffer) Save() error {
	if b.Path == "" {
		return os.ErrInvalid
	}
	f, err := os.Create(b.Path)
	if err != nil {
		return err
	}
	defer f.Close()
	w := bufio.NewWriter(f)
	for i, l := range b.Lines {
		w.WriteString(l)
		if i < len(b.Lines)-1 {
			w.WriteString("\n")
		}
	}
	w.WriteString("\n")
	if err := w.Flush(); err != nil {
		return err
	}
	b.Dirty = false
	return nil
}

// SaveAs salva em um novo caminho e atualiza o Path do buffer.
func (b *Buffer) SaveAs(path string) error {
	b.Path = path
	return b.Save()
}

// Name retorna um nome curto pro título da aba.
func (b *Buffer) Name() string {
	if b.Path == "" {
		return "NoName"
	}
	parts := strings.Split(b.Path, "/")
	return parts[len(parts)-1]
}

// --- Edição ---

// snapshotPush guarda o estado atual antes de uma mudança, pra permitir undo.
func (b *Buffer) snapshotPush() {
	cp := make([]string, len(b.Lines))
	copy(cp, b.Lines)
	b.undoStack = append(b.undoStack, snapshot{lines: cp, cursorX: b.CursorX, cursorY: b.CursorY})
	if len(b.undoStack) > 200 {
		b.undoStack = b.undoStack[1:]
	}
	b.redoStack = nil
}

// Undo desfaz a última alteração. Retorna false se não há mais nada pra desfazer.
func (b *Buffer) Undo() bool {
	b.breakRun()
	if len(b.undoStack) == 0 {
		return false
	}
	cur := make([]string, len(b.Lines))
	copy(cur, b.Lines)
	b.redoStack = append(b.redoStack, snapshot{lines: cur, cursorX: b.CursorX, cursorY: b.CursorY})

	last := b.undoStack[len(b.undoStack)-1]
	b.undoStack = b.undoStack[:len(b.undoStack)-1]
	b.Lines = last.lines
	b.CursorX = last.cursorX
	b.CursorY = last.cursorY
	b.Dirty = true
	b.clampCursor()
	return true
}

// Redo refaz a última alteração desfeita.
func (b *Buffer) Redo() bool {
	b.breakRun()
	if len(b.redoStack) == 0 {
		return false
	}
	cur := make([]string, len(b.Lines))
	copy(cur, b.Lines)
	b.undoStack = append(b.undoStack, snapshot{lines: cur, cursorX: b.CursorX, cursorY: b.CursorY})

	last := b.redoStack[len(b.redoStack)-1]
	b.redoStack = b.redoStack[:len(b.redoStack)-1]
	b.Lines = last.lines
	b.CursorX = last.cursorX
	b.CursorY = last.cursorY
	b.Dirty = true
	b.clampCursor()
	return true
}

func (b *Buffer) clampCursor() {
	if b.CursorY >= len(b.Lines) {
		b.CursorY = len(b.Lines) - 1
	}
	if b.CursorY < 0 {
		b.CursorY = 0
	}
	if b.CursorX > len(b.Lines[b.CursorY]) {
		b.CursorX = len(b.Lines[b.CursorY])
	}
	if b.CursorX < 0 {
		b.CursorX = 0
	}
}

// InsertRune insere um caractere na posição do cursor. Chamadas consecutivas
// (sem mover o cursor por fora) são agrupadas num único passo de undo.
// Se houver uma seleção ativa, ela é substituída pelo caractere digitado.
func (b *Buffer) InsertRune(r rune) {
	if b.Selecting {
		b.DeleteSelection()
	}
	if b.runKind != 'i' || b.runAtX != b.CursorX || b.runAtY != b.CursorY {
		b.snapshotPush()
		b.runKind = 'i'
	}
	line := b.Lines[b.CursorY]
	s := string(r)
	b.Lines[b.CursorY] = line[:b.CursorX] + s + line[b.CursorX:]
	b.CursorX += len(s) // tamanho em BYTES do caractere — ver comentário
	// equivalente em InsertTextAtCursor (edit_extra.go) sobre por que
	// não pode ser sempre +1.
	b.runAtX = b.CursorX
	b.runAtY = b.CursorY
	b.Dirty = true
}

// InsertNewline quebra a linha atual na posição do cursor.
func (b *Buffer) InsertNewline() {
	if b.Selecting {
		b.DeleteSelection()
	} else {
		b.snapshotPush()
		b.breakRun()
	}
	line := b.Lines[b.CursorY]
	before := line[:b.CursorX]
	after := line[b.CursorX:]
	b.Lines[b.CursorY] = before
	newLines := make([]string, 0, len(b.Lines)+1)
	newLines = append(newLines, b.Lines[:b.CursorY+1]...)
	newLines = append(newLines, after)
	newLines = append(newLines, b.Lines[b.CursorY+1:]...)
	b.Lines = newLines
	b.CursorY++
	b.CursorX = 0
	b.Dirty = true
}

// Backspace apaga o caractere antes do cursor (ou junta com a linha acima).
// Se houver seleção ativa, apaga a seleção inteira. Chamadas consecutivas
// (sem seleção) são agrupadas num único passo de undo.
func (b *Buffer) Backspace() {
	if b.Selecting {
		b.DeleteSelection()
		return
	}
	if b.CursorX == 0 && b.CursorY == 0 {
		return
	}
	if b.runKind != 'b' || b.runAtX != b.CursorX || b.runAtY != b.CursorY {
		b.snapshotPush()
		b.runKind = 'b'
	}
	if b.CursorX == 0 {
		prevLen := len(b.Lines[b.CursorY-1])
		b.Lines[b.CursorY-1] += b.Lines[b.CursorY]
		b.Lines = append(b.Lines[:b.CursorY], b.Lines[b.CursorY+1:]...)
		b.CursorY--
		b.CursorX = prevLen
	} else {
		line := b.Lines[b.CursorY]
		_, size := utf8.DecodeLastRuneInString(line[:b.CursorX])
		b.Lines[b.CursorY] = line[:b.CursorX-size] + line[b.CursorX:]
		b.CursorX -= size // tamanho em BYTES do caractere apagado — apagar
		// sempre 1 byte cortava caracteres acentuados/emoji ao meio.
	}
	b.runAtX = b.CursorX
	b.runAtY = b.CursorY
	b.Dirty = true
}

// DeleteLine apaga a linha inteira onde o cursor está (usado pelo Ctrl+K).
// ClearLastLineInPlace limpa o conteúdo da linha atual SEM removê-la
// do array — usado pelo Ctrl+K do nano ao cortar a linha que é
// atualmente a última do arquivo: como não sobra nada embaixo pra
// "puxar" o cursor de volta, ele ficaria recuando pra linha anterior
// se a linha fosse removida de verdade (efeito colateral do
// DeleteLine normal). Aqui ele fica exatamente onde estava.
func (b *Buffer) ClearLastLineInPlace() {
	b.snapshotPush()
	b.breakRun()
	b.Lines[b.CursorY] = ""
	b.CursorX = 0
	b.Dirty = true
}

func (b *Buffer) DeleteLine() {
	b.snapshotPush()
	b.breakRun()
	if len(b.Lines) == 1 {
		b.Lines[0] = ""
		b.CursorX = 0
		b.Dirty = true
		return
	}
	b.Lines = append(b.Lines[:b.CursorY], b.Lines[b.CursorY+1:]...)
	if b.CursorY >= len(b.Lines) {
		b.CursorY = len(b.Lines) - 1
	}
	b.CursorX = 0
	b.Dirty = true
}

// MoveCursor move o cursor, respeitando os limites do buffer.
func (b *Buffer) MoveCursor(dx, dy int) {
	b.breakRun()
	b.CursorY += dy
	if b.CursorY < 0 {
		b.CursorY = 0
	}
	if b.CursorY >= len(b.Lines) {
		b.CursorY = len(b.Lines) - 1
	}
	b.CursorX += dx
	if b.CursorX < 0 {
		if b.CursorY > 0 {
			b.CursorY--
			b.CursorX = len(b.Lines[b.CursorY])
		} else {
			b.CursorX = 0
		}
	}
	lineLen := len(b.Lines[b.CursorY])
	if b.CursorX > lineLen {
		if dx > 0 && b.CursorY < len(b.Lines)-1 {
			b.CursorY++
			b.CursorX = 0
		} else {
			b.CursorX = lineLen
		}
	}
}

// Find procura uma substring a partir de uma posição, retorna (linha, coluna, achou).
// Find procura query a partir de (fromLine, fromCol), sem diferenciar
// maiúsculas de minúsculas — dá a volta pro início se não achar daí
// pra frente. Devolve (linha, coluna, achou).
func (b *Buffer) Find(query string, fromLine, fromCol int) (int, int, bool) {
	if query == "" {
		return 0, 0, false
	}
	queryLower := strings.ToLower(query)
	for y := fromLine; y < len(b.Lines); y++ {
		start := 0
		if y == fromLine {
			start = fromCol
		}
		if start > len(b.Lines[y]) {
			continue
		}
		idx := strings.Index(strings.ToLower(b.Lines[y][start:]), queryLower)
		if idx >= 0 {
			return y, start + idx, true
		}
	}
	// dá a volta a partir do início
	for y := 0; y <= fromLine && y < len(b.Lines); y++ {
		limit := len(b.Lines[y])
		if y == fromLine {
			limit = fromCol
		}
		idx := strings.Index(strings.ToLower(b.Lines[y][:limit]), queryLower)
		if idx >= 0 {
			return y, idx, true
		}
	}
	return 0, 0, false
}

// ReplaceAll substitui todas as ocorrências de "from" por "to". Retorna quantas trocas fez.
func (b *Buffer) ReplaceAll(from, to string) int {
	if from == "" {
		return 0
	}
	b.snapshotPush()
	b.breakRun()
	count := 0
	for i, line := range b.Lines {
		n := strings.Count(line, from)
		if n > 0 {
			b.Lines[i] = strings.ReplaceAll(line, from, to)
			count += n
		}
	}
	if count > 0 {
		b.Dirty = true
	}
	return count
}
