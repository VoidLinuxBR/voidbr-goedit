/*
   goedit
   Editor de texto para terminal (TUI), com realce de sintaxe, plugins Lua, seleção em bloco e mais
   Site:      https://chililinux.com
   Site:      https://voidbr.org
   Site:      https://voidlinux.com.br
   GitHub:    https://github.com/voidlinuxbr/voidbr-goedit
   Created:   dom 16 ago 2026 10:15:33 -04
   Updated:   sex 21 ago 2026 11:30:00 -04
   Version:   0.35.0
   Copyright (C) 2019-2026 Vilmar Catafesta <vcatafesta@gmail.com>
*/

package ui

import (
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"

	"github.com/gdamore/tcell/v2"

	"goedit/internal/buffer"
)

// HandleKey processa um evento de teclado e atualiza o estado do App.
func (a *App) HandleKey(ev *tcell.EventKey) {
	if a.Pasting {
		a.accumulatePasteKey(ev)
		return
	}
	if a.HelpActive {
		a.handleHelpKey(ev)
		return
	}
	if a.ContextMenuActive {
		a.handleContextMenuKey(ev)
		return
	}
	if a.PaletteActive {
		a.handlePaletteKey(ev)
		return
	}
	if a.BlockActive {
		if a.handleBlockKey(ev) {
			return
		}
		// devolveu false: a tecla não era do modo bloco, e o bloco já
		// foi cancelado dentro de handleBlockKey — cai pro fluxo normal
		// do editor em vez de simplesmente descartar a tecla.
	}
	if a.RenameActive {
		a.handleRenameKey(ev)
		return
	}
	if a.PromptActive {
		a.handlePromptKey(ev)
		return
	}
	if a.SidebarFocused {
		a.handleSidebarKey(ev)
		return
	}
	a.dispatchEditorKey(ev)
}

// accumulatePasteKey é chamada tecla a tecla enquanto um bracketed
// paste está em andamento (ver a.Pasting) — só acumula o caractere em
// a.PasteBuf, sem processar pelo caminho normal de edição (que faria
// um snapshot de undo e uma reconstrução do array de linhas POR
// CARACTERE, o que ficava visivelmente lento pra colar textos grandes).
// O texto acumulado é aplicado de uma vez só em FinishPaste, quando o
// paste termina.
func (a *App) accumulatePasteKey(ev *tcell.EventKey) {
	switch ev.Key() {
	case tcell.KeyRune:
		a.PasteBuf.WriteRune(ev.Rune())
	case tcell.KeyEnter, tcell.KeyLF:
		a.PasteBuf.WriteByte('\n')
	case tcell.KeyTab:
		a.PasteBuf.WriteByte('\t')
	}
	// outras teclas especiais dentro de um paste (raras) são ignoradas
}

// FinishPaste aplica de uma vez o texto acumulado durante um bracketed
// paste (ver a.Pasting/a.PasteBuf) — chamada pelo main.go quando chega
// o EventPaste de fim. Insere no prompt ativo (busca, salvar como...)
// se houver um; senão, no buffer do editor.
func (a *App) FinishPaste() {
	text := a.PasteBuf.String()
	a.PasteBuf.Reset()
	if text == "" {
		return
	}
	if a.PromptActive {
		a.PromptInput += text
		return
	}
	if a.SidebarFocused {
		return // sidebar não usa texto colado (busca incremental é por tecla só)
	}
	b := a.ActiveBuffer()
	b.InsertTextAtCursor(text)
}

// dispatchEditorKey é a porta de entrada pro editor de texto normal.
// Primeiro dá chance ao popup de autocompletar (setas navegam, Tab/Enter
// aceita, Esc cancela); se a tecla não era disso, segue pro fluxo normal
// de edição (handleEditorKey, que tem muitos "return" internos e por
// isso não dá pra simplesmente inserir lógica no meio dela) e, depois
// que ela termina, decide se deve recalcular ou cancelar as sugestões.
// handleContextMenuKey trata as teclas com o menu de contexto aberto —
// pensado pra funcionar sem mouse nenhum (TTY puro, sem X11/Wayland):
// setas navegam, Enter confirma o item destacado, Esc cancela sem fazer
// nada. Qualquer outra tecla é ignorada (evita digitar sem querer).
func (a *App) handleContextMenuKey(ev *tcell.EventKey) {
	switch ev.Key() {
	case tcell.KeyEsc:
		a.CloseContextMenu()
	case tcell.KeyUp:
		if len(a.ContextMenuItems) > 0 {
			a.ContextMenuIndex = (a.ContextMenuIndex - 1 + len(a.ContextMenuItems)) % len(a.ContextMenuItems)
		}
	case tcell.KeyDown:
		if len(a.ContextMenuItems) > 0 {
			a.ContextMenuIndex = (a.ContextMenuIndex + 1) % len(a.ContextMenuItems)
		}
	case tcell.KeyEnter:
		if a.ContextMenuIndex >= 0 && a.ContextMenuIndex < len(a.ContextMenuItems) {
			action := a.ContextMenuItems[a.ContextMenuIndex].Action
			a.CloseContextMenu()
			if action != nil {
				action(a)
			}
		}
	}
}

// handlePaletteKey trata a navegação/filtro/seleção na paleta de
// comandos (Ctrl+P) — ver OpenPalette/paletteRefilter em app.go.
func (a *App) handlePaletteKey(ev *tcell.EventKey) {
	switch ev.Key() {
	case tcell.KeyEsc, tcell.KeyCtrlC:
		a.ClosePalette()
	case tcell.KeyUp:
		if len(a.PaletteItems) > 0 {
			a.PaletteSel = (a.PaletteSel - 1 + len(a.PaletteItems)) % len(a.PaletteItems)
		}
	case tcell.KeyDown:
		if len(a.PaletteItems) > 0 {
			a.PaletteSel = (a.PaletteSel + 1) % len(a.PaletteItems)
		}
	case tcell.KeyEnter:
		if a.PaletteSel >= 0 && a.PaletteSel < len(a.PaletteItems) {
			name := a.PaletteItems[a.PaletteSel]
			a.ClosePalette()
			if err := a.Plugins.Run(name); err != nil {
				a.SetStatusMsg("erro no comando '" + name + "': " + err.Error())
			}
		} else {
			a.ClosePalette()
		}
	case tcell.KeyBackspace, tcell.KeyBackspace2:
		if len(a.PaletteFilter) > 0 {
			a.PaletteFilter = a.PaletteFilter[:len(a.PaletteFilter)-1]
			a.paletteRefilter()
		}
	case tcell.KeyRune:
		a.PaletteFilter += string(ev.Rune())
		a.paletteRefilter()
	}
}

func (a *App) dispatchEditorKey(ev *tcell.EventKey) {
	if a.tryNanoKey(ev) {
		return
	}
	// Limpa o destaque do termo buscado ao digitar ou apertar Esc — F3
	// (repetir busca) e as setas de navegação não contam, só edição de
	// verdade ou cancelar explicitamente.
	if a.SearchHighlightActive {
		switch ev.Key() {
		case tcell.KeyRune, tcell.KeyBackspace, tcell.KeyBackspace2, tcell.KeyDelete, tcell.KeyEnter, tcell.KeyEsc:
			a.SearchHighlightActive = false
		}
	}

	// Ctrl+Shift+seta: começa a seleção em bloco/coluna (se ainda não
	// estava ativa) e já processa essa primeira tecla.
	mods := ev.Modifiers()
	if mods&tcell.ModCtrl != 0 && mods&tcell.ModShift != 0 {
		switch ev.Key() {
		case tcell.KeyUp, tcell.KeyDown, tcell.KeyLeft, tcell.KeyRight:
			a.startBlockSelect()
			a.handleBlockKey(ev)
			return
		}
	}
	if a.SuggestActive {
		if a.handleSuggestKey(ev) {
			return
		}
	}
	a.handleEditorKey(ev)
	a.syncSuggestionsAfterKey(ev)
}

func (a *App) handlePromptKey(ev *tcell.EventKey) {
	switch ev.Key() {
	case tcell.KeyEnter:
		a.submitPrompt()
	case tcell.KeyEsc, tcell.KeyCtrlC:
		a.cancelPrompt()
	case tcell.KeyBackspace, tcell.KeyBackspace2:
		if len(a.PromptInput) > 0 {
			a.PromptInput = a.PromptInput[:len(a.PromptInput)-1]
		}
	case tcell.KeyUp:
		if a.PromptIsSearch && a.searchHistoryPos > 0 {
			a.searchHistoryPos--
			a.PromptInput = a.SearchHistory[a.searchHistoryPos]
		}
	case tcell.KeyDown:
		if a.PromptIsSearch && a.searchHistoryPos < len(a.SearchHistory) {
			a.searchHistoryPos++
			if a.searchHistoryPos == len(a.SearchHistory) {
				a.PromptInput = "" // passou do mais recente: volta a caixa vazia
			} else {
				a.PromptInput = a.SearchHistory[a.searchHistoryPos]
			}
		}
	case tcell.KeyRune:
		a.PromptInput += string(ev.Rune())
	}
}

func (a *App) handleSidebarKey(ev *tcell.EventKey) {
	switch ev.Key() {
	case tcell.KeyUp:
		if a.SidebarSel > 0 {
			a.SidebarSel--
		}
		return
	case tcell.KeyDown:
		if a.SidebarSel < len(a.SidebarEntries)-1 {
			a.SidebarSel++
		}
		return
	case tcell.KeyPgDn:
		a.SidebarSel += a.sidebarPageSize()
		if a.SidebarSel > len(a.SidebarEntries)-1 {
			a.SidebarSel = len(a.SidebarEntries) - 1
		}
		if a.SidebarSel < 0 {
			a.SidebarSel = 0
		}
		return
	case tcell.KeyPgUp:
		a.SidebarSel -= a.sidebarPageSize()
		if a.SidebarSel < 0 {
			a.SidebarSel = 0
		}
		return
	case tcell.KeyHome:
		a.SidebarSel = 0
		return
	case tcell.KeyEnd:
		if len(a.SidebarEntries) > 0 {
			a.SidebarSel = len(a.SidebarEntries) - 1
		}
		return
	case tcell.KeyEnter:
		if a.SidebarSel < len(a.SidebarEntries) {
			a.openSidebarEntry(a.SidebarEntries[a.SidebarSel])
		}
		return
	case tcell.KeyBackspace, tcell.KeyBackspace2:
		a.SidebarPath = filepath.Dir(a.SidebarPath)
		a.SidebarSel = 0
		a.reloadSidebar()
		return
	case tcell.KeyEsc:
		a.SidebarFocused = false
		return
	case tcell.KeyRune:
		a.sidebarTypeAhead(ev.Rune())
		return
	}

	// Não é uma tecla de navegação da sidebar — tenta como atalho global
	// de app (Ctrl+Q, Ctrl+S, Ctrl+O, trocar de aba, buscar, etc). Se
	// nem isso for, a tecla é ignorada (não deixa digitar sem querer
	// no buffer por trás enquanto está navegando a lista de arquivos).
	a.handleGlobalAppShortcut(ev)
}

// sidebarTypeAhead implementa busca incremental por digitação (igual
// exploradores de arquivo clássicos): cada letra digitada é acrescentada
// a um buffer de busca, e o cursor pula pro primeiro item cujo nome
// começa com esse buffer (sem diferenciar maiúsculas/minúsculas). Se
// passar muito tempo sem digitar, o próximo caractere reinicia a busca
// do zero em vez de acrescentar.
func (a *App) sidebarTypeAhead(r rune) {
	const resetAfter = 700 * time.Millisecond

	now := time.Now()
	if now.Sub(a.SidebarSearchTime) > resetAfter {
		a.SidebarSearchBuf = ""
	}
	a.SidebarSearchTime = now

	tryBuf := a.SidebarSearchBuf + strings.ToLower(string(r))
	if idx, ok := findSidebarEntryByPrefix(a.SidebarEntries, tryBuf); ok {
		a.SidebarSearchBuf = tryBuf
		a.SidebarSel = idx
		a.SetStatusMsg("busca: " + a.SidebarSearchBuf)
		return
	}

	// não achou continuando o buffer anterior — recomeça só com essa
	// letra (comum quando a pessoa já mudou de ideia sobre o nome)
	fresh := strings.ToLower(string(r))
	if idx, ok := findSidebarEntryByPrefix(a.SidebarEntries, fresh); ok {
		a.SidebarSearchBuf = fresh
		a.SidebarSel = idx
		a.SetStatusMsg("busca: " + a.SidebarSearchBuf)
	}
}

// findSidebarEntryByPrefix acha o primeiro item cujo nome começa com
// prefix (sem diferenciar maiúsculas/minúsculas).
func findSidebarEntryByPrefix(entries []os.DirEntry, prefix string) (int, bool) {
	for i, e := range entries {
		if strings.HasPrefix(strings.ToLower(e.Name()), prefix) {
			return i, true
		}
	}
	return 0, false
}

// sidebarPageSize calcula quantas linhas de arquivo cabem na sidebar
// (usado pelo PageUp/PageDown), com base na altura real do terminal —
// mesmas contas de editorBottom/cabeçalho usadas no Render.
func (a *App) sidebarPageSize() int {
	_, h := a.Screen.Size()
	visible := h - 2 - 1 // h-2 = editorBottom; -1 = linha do cabeçalho "ARQUIVOS"
	if visible < 1 {
		visible = 1
	}
	return visible
}

// handleGlobalAppShortcut trata os atalhos "de nível de app" — sair,
// salvar, abrir, trocar de aba, buscar, paleta de comandos — que fazem
// sentido disparar em qualquer lugar, inclusive com a sidebar focada
// (diferente de undo/copiar/colar/etc, que mexem em texto e só fazem
// sentido vindo do editor). Devolve true se tratou a tecla.
func (a *App) handleGlobalAppShortcut(ev *tcell.EventKey) bool {
	b := a.ActiveBuffer()
	alt := ev.Modifiers()&tcell.ModAlt != 0

	if ev.Key() == tcell.KeyCtrlQ {
		// Fecha só a aba atual — se sobrar mais de uma aba aberta, as
		// outras continuam; se for a última, sai do programa (com o
		// menu "Sair sem salvar"/"Sair e salvar" se tiver alteração).
		// Vale em todos os perfis de teclado, não só no nano-híbrido.
		a.closeActiveTabWithConfirm()
		return true
	}

	if a.Settings.Keymap == "nano-hibrido" {
		// perfil "nano híbrido": igual vscode em tudo, exceto Ctrl+W
		// (vira buscar, estilo nano) — Ctrl+Q já tratado acima, igual
		// em todos os perfis agora.
		switch ev.Key() {
		case tcell.KeyCtrlW:
			a.startSearchPrompt()
			return true
		}
	}

	switch ev.Key() {
	case tcell.KeyCtrlS:
		a.doSave()
		return true
	case tcell.KeyCtrlX:
		// Salvar e sair (o Ctrl+X "recortar" antigo virou parte do
		// Ctrl+K, que agora também copia antes de apagar). Fica aqui
		// (não em handleEditorKey) pra funcionar de qualquer lugar,
		// inclusive com a sidebar focada — igual o Ctrl+Q. Só sai
		// depois que o salvamento terminar de verdade — se o arquivo
		// ainda não tem caminho, espera o prompt "salvar como"
		// terminar antes de sair; se der erro ao salvar, não sai, pra
		// não arriscar perder o conteúdo sem aviso.
		if b.Path == "" && !b.Dirty {
			// arquivo sem nome, sem nenhuma alteração — não tem nada
			// pra salvar, então nem pergunta o caminho, só sai
			a.Quit = true
			return true
		}
		if b.Path == "" {
			a.startPrompt("Salvar como: ", func(path string) {
				if path == "" {
					return // cancelou o "salvar como" — não sai
				}
				if err := b.SaveAs(path); err != nil {
					a.SetStatusMsg("erro ao salvar: " + err.Error())
					return
				}
				a.SetStatusMsg("salvo em " + path)
				a.Quit = true
			}, nil)
			return true
		}
		if err := b.Save(); err != nil {
			a.SetStatusMsg("erro ao salvar: " + err.Error())
			return true
		}
		a.Quit = true
		return true
	case tcell.KeyCtrlO:
		a.startPrompt("Abrir arquivo: ", func(input string) {
			if input != "" {
				a.OpenFile(input)
			}
		}, nil)
		return true
	case tcell.KeyCtrlN:
		a.NewBuffer()
		return true
	case tcell.KeyCtrlW:
		a.closeActiveTabWithConfirm()
		return true
	case tcell.KeyCtrlB:
		if a.SidebarFocused {
			// já estava navegando a sidebar: Ctrl+B fecha, igual o
			// atalho já fazia antes de focar nela.
			a.ShowSidebar = false
			a.SidebarFocused = false
		} else {
			a.ShowSidebar = !a.ShowSidebar
			if a.ShowSidebar {
				a.SidebarFocused = true
			}
		}
		return true
	case tcell.KeyCtrlBackslash:
		a.ToggleSplit()
		return true
	case tcell.KeyCtrlL:
		if len(a.Panes) > 1 {
			a.SwitchPaneFocus()
		} else {
			a.doFind(true) // sem split, não tem painel pra trocar — vira "repetir busca" (igual F3)
		}
		return true
	case tcell.KeyCtrlF:
		a.startSearchPrompt()
		return true
	case tcell.KeyCtrlH:
		a.startPrompt("Substituir - buscar: ", func(find string) {
			a.startPrompt("Substituir por: ", func(repl string) {
				n := b.ReplaceAll(find, repl)
				a.SetStatusMsg(fmt.Sprintf("%d substituição(ões) feita(s)", n))
			}, nil)
		}, nil)
		return true
	case tcell.KeyCtrlG:
		a.startPrompt("Ir para linha: ", func(input string) {
			n, err := strconv.Atoi(input)
			if err == nil {
				b.GoToLine(n)
			}
		}, nil)
		return true
	case tcell.KeyCtrlP:
		a.OpenPalette()
		return true
	case tcell.KeyF1:
		a.HelpActive = true
		a.HelpScroll = 0
		return true
	case tcell.KeyF9:
		a.CycleKeymap()
		return true
	}

	if alt {
		switch ev.Key() {
		case tcell.KeyLeft:
			a.PrevTab()
			return true
		case tcell.KeyRight:
			a.NextTab()
			return true
		}
	}
	return false
}

func (a *App) handleEditorKey(ev *tcell.EventKey) {
	b := a.ActiveBuffer()
	mods := ev.Modifiers()
	shift := mods&tcell.ModShift != 0
	alt := mods&tcell.ModAlt != 0

	// Atalhos "de app" que fazem sentido mesmo com a sidebar focada
	// (sair, salvar, abrir, trocar de aba, buscar...) — não mexem no
	// texto do jeito que undo/copiar/colar/etc mexeriam, então são
	// seguros de disparar em qualquer lugar.
	if a.handleGlobalAppShortcut(ev) {
		return
	}

	// Atalhos globais que dependem do buffer ativo (não chamados pela
	// sidebar, só daqui — mexem em texto, não fazem sentido "no vazio").
	switch ev.Key() {
	case tcell.KeyCtrlZ:
		if !b.Undo() {
			a.SetStatusMsg("nada para desfazer")
		}
		return
	case tcell.KeyCtrlU:
		// Atalho extra de undo (além do Ctrl+Z padrão) — não mostra
		// mensagem quando não há mais nada a desfazer, então dá pra
		// martelar sem se preocupar em passar do ponto.
		b.Undo()
		return
	case tcell.KeyCtrlY:
		if !b.Redo() {
			a.SetStatusMsg("nada para refazer")
		}
		return
	case tcell.KeyCtrlK:
		// Apaga a linha, copiando ela pro clipboard antes — dá pra
		// colar de volta com Ctrl+V depois (igual o Ctrl+X fazia antes
		// de virar "salvar e sair"). No terminal, Ctrl+Shift+K quase
		// sempre chega como o mesmo código de Ctrl+K puro (o bit de
		// shift se perde em combinações Ctrl+letra), então tratamos os
		// dois igual — bate com o atalho de apagar linha do VS Code.
		if b.Selecting {
			a.copyToClipboard(b.SelectedText())
			b.DeleteSelection()
		} else {
			a.copyToClipboard(b.Lines[b.CursorY] + "\n")
			b.DeleteLine()
		}
		return
	case tcell.KeyCtrlD:
		b.DuplicateLine()
		return
	case tcell.KeyCtrlA:
		b.SelectAll()
		return
	case tcell.KeyCtrlC:
		if b.Selecting {
			a.copyToClipboard(b.SelectedText())
			a.SetStatusMsg("copiado")
		}
		return
	case tcell.KeyCtrlV:
		if text := a.pasteFromClipboard(); text != "" {
			b.InsertTextAtCursor(text)
		}
		return
	case tcell.KeyCtrlUnderscore:
		// Ctrl+/ chega como este código na maioria dos terminais (mesmo byte 0x1F).
		style := commentStyleFor(b.Path, b.Lines[0])
		if y0, y1, ok := b.SelectionLines(); ok && y0 != y1 {
			// seleção de várias linhas: bloco se a linguagem suportar,
			// senão prefixo em cada linha
			if style.BlockStart != "" {
				b.ToggleBlockComment(y0, y1, style.BlockStart, style.BlockEnd)
			} else if style.Line != "" {
				b.ToggleLineCommentRange(y0, y1, style.Line)
			}
			return
		}
		// sem seleção (ou seleção de 1 linha só): comenta só a linha atual
		if style.Line != "" {
			b.ToggleLineComment(style.Line)
		} else if style.BlockStart != "" {
			// linguagem só tem comentário em bloco (html, xml, md) —
			// usa bloco mesmo pra 1 linha só, é o único jeito que existe
			b.ToggleBlockComment(b.CursorY, b.CursorY, style.BlockStart, style.BlockEnd)
		}
		return
	case tcell.KeyF3:
		a.doFind(true)
		return
	case tcell.KeyF2:
		a.startRename(b)
		return
	}

	// Alt+Cima/Baixo: move linha. Shift+Alt+Cima/Baixo: duplica linha
	// (pra cima/baixo, igual o VS Code) — diferente do Ctrl+D, que
	// sempre duplica pra baixo. Alt+Esquerda/Direita já tratado na
	// função compartilhada de atalhos globais. Shift+Alt+F formata.
	if alt {
		switch ev.Key() {
		case tcell.KeyUp:
			if shift {
				if b.Selecting {
					b.DuplicateSelectionDown()
				} else {
					b.DuplicateLine() // já duplica pra baixo
				}
			} else {
				b.MoveLineUp()
			}
			return
		case tcell.KeyDown:
			if shift {
				if b.Selecting {
					b.DuplicateSelectionUp()
				} else {
					b.DuplicateLineUp()
				}
			} else {
				b.MoveLineDown()
			}
			return
		case tcell.KeyRune:
			if ev.Rune() == 'F' || ev.Rune() == 'f' {
				a.FormatActiveBuffer()
				return
			}
			if ev.Rune() == 'X' || ev.Rune() == 'x' {
				// Alt+X: cortar — preenche o espaço que o Ctrl+X deixou
				// ao virar "salvar e sair"
				if b.Selecting {
					a.copyToClipboard(b.SelectedText())
					b.DeleteSelection()
				} else {
					a.copyToClipboard(b.Lines[b.CursorY] + "\n")
					b.DeleteLine()
				}
				return
			}
			if ev.Rune() == 'N' || ev.Rune() == 'n' {
				// Alt+N: mostra/esconde os números de linha — vale em
				// qualquer perfil de teclado (vscode não tem atalho
				// padrão pra isso, só menu/configurações)
				a.ShowLineNumbers = !a.ShowLineNumbers
				if a.ShowLineNumbers {
					a.SetStatusMsg("números de linha: mostrando")
				} else {
					a.SetStatusMsg("números de linha: escondidos")
				}
				return
			}
		}
	}

	// Shift+Seta: estende a seleção. Em alguns terminais/gerenciadores de
	// janela, Shift+seta sozinho chega com o bit de Shift "perdido" e só
	// o de Ctrl presente — mas Ctrl+Shift+seta junto chega correto (com
	// os dois bits), então dá pra distinguir. Como Ctrl+seta sozinho não
	// é usado pra nada no editor, tratamos esse caso (só Ctrl, sem Alt)
	// como se fosse Shift — mas só pras 4 setas, nunca Home/End/etc, pra
	// não atropelar o Ctrl+Home/Ctrl+End de verdade (esses usam o mesmo
	// Ctrl sozinho nesse terminal, só que pra outra coisa).
	shiftArrow := shift || (mods&tcell.ModCtrl != 0 && mods&tcell.ModAlt == 0 && !shift)
	if shiftArrow {
		switch ev.Key() {
		case tcell.KeyUp:
			if !b.Selecting {
				// 1º toque: marca a linha atual inteira, âncora no
				// início da PRÓXIMA linha (fim da atual)
				b.SelStartY = b.CursorY + 1
				b.SelStartX = 0
				b.Selecting = true
				b.CursorX = 0
			} else if b.CursorY > 0 {
				b.CursorY--
				b.CursorX = 0
			}
			return
		case tcell.KeyDown:
			if !b.Selecting {
				// 1º toque: marca a linha atual inteira, âncora no
				// início dela, cursor vai pro início da próxima
				b.SelStartY = b.CursorY
				b.SelStartX = 0
				b.Selecting = true
				if b.CursorY < len(b.Lines)-1 {
					b.CursorY++
				}
				b.CursorX = 0
			} else if b.CursorY < len(b.Lines)-1 {
				b.CursorY++
				b.CursorX = 0
			}
			return
		case tcell.KeyLeft:
			b.StartSelection()
			b.MoveCursor(-1, 0)
			return
		case tcell.KeyRight:
			b.StartSelection()
			b.MoveCursor(1, 0)
			return
		}
	}

	// Shift+Home / Shift+End: estende a seleção (só shift genuíno — sem
	// o fallback de Ctrl, pra não atropelar Ctrl+Home/Ctrl+End reais).
	if shift {
		switch ev.Key() {
		case tcell.KeyHome:
			b.StartSelection()
			b.CursorX = 0
			return
		case tcell.KeyEnd:
			b.StartSelection()
			b.CursorX = len(b.Lines[b.CursorY])
			return
		}
	}

	// Ctrl+Home / Ctrl+End: início/fim do arquivo.
	if ev.Modifiers()&tcell.ModCtrl != 0 {
		switch ev.Key() {
		case tcell.KeyHome:
			b.ClearSelection()
			b.CursorY, b.CursorX = 0, 0
			return
		case tcell.KeyEnd:
			b.ClearSelection()
			b.CursorY = len(b.Lines) - 1
			b.CursorX = len(b.Lines[b.CursorY])
			return
		}
	}

	// Edição / navegação normal — qualquer movimento sem shift cancela a seleção.
	switch ev.Key() {
	case tcell.KeyUp:
		b.ClearSelection()
		b.MoveCursor(0, -1)
	case tcell.KeyDown:
		b.ClearSelection()
		b.MoveCursor(0, 1)
	case tcell.KeyLeft:
		b.ClearSelection()
		b.MoveCursor(-1, 0)
	case tcell.KeyRight:
		b.ClearSelection()
		b.MoveCursor(1, 0)
	case tcell.KeyHome:
		b.ClearSelection()
		b.CursorX = 0
	case tcell.KeyEnd:
		b.ClearSelection()
		b.CursorX = len(b.Lines[b.CursorY])
	case tcell.KeyPgUp:
		b.ClearSelection()
		h := a.pageHeight()
		for i := 0; i < h; i++ {
			b.MoveCursor(0, -1)
		}
		b.OffsetY -= h
		if b.OffsetY < 0 {
			b.OffsetY = 0
		}
	case tcell.KeyPgDn:
		b.ClearSelection()
		h := a.pageHeight()
		for i := 0; i < h; i++ {
			b.MoveCursor(0, 1)
		}
		b.OffsetY += h
		if maxOffset := len(b.Lines) - h; b.OffsetY > maxOffset {
			b.OffsetY = maxOffset
		}
		if b.OffsetY < 0 {
			b.OffsetY = 0
		}
	case tcell.KeyEnter, tcell.KeyLF:
		// KeyLF (mesmo código de Ctrl+J) é o que chega pra uma quebra
		// de linha dentro de um texto colado via bracketed paste — sem
		// tratar aqui, a quebra de linha colada simplesmente sumia.
		b.InsertNewline()
	case tcell.KeyBackspace, tcell.KeyBackspace2:
		b.Backspace()
	case tcell.KeyDelete:
		b.DeleteForward()
	case tcell.KeyInsert:
		a.OverwriteMode = !a.OverwriteMode
		if a.OverwriteMode {
			a.SetStatusMsg("modo OVERWRITE (sobrescrever)")
		} else {
			a.SetStatusMsg("modo INSERT (inserir)")
		}
	case tcell.KeyTab:
		if b.Selecting {
			b.IndentSelection(a.indentString())
		} else if a.Settings.InsertSpaces {
			for i := 0; i < a.Settings.TabWidth; i++ {
				b.InsertRune(' ')
			}
		} else {
			b.InsertRune('\t')
		}
	case tcell.KeyBacktab:
		if b.Selecting {
			b.DedentSelection(a.Settings.TabWidth)
		} else {
			b.DedentCurrentLine(a.Settings.TabWidth)
		}
	case tcell.KeyRune:
		if a.OverwriteMode && !b.Selecting {
			b.OverwriteRune(ev.Rune())
		} else {
			b.InsertRune(ev.Rune())
		}
	}
}

// indentString devolve o texto inserido por um nível de indentação,
// respeitando a configuração de tabWidth/insertSpaces do usuário.
func (a *App) indentString() string {
	if a.Settings.InsertSpaces {
		return strings.Repeat(" ", a.Settings.TabWidth)
	}
	return "\t"
}

// commentPrefixFor devolve o prefixo de comentário de linha pra linguagens comuns,
// baseado na extensão do arquivo. Vazio significa "sem comentário conhecido".
// commentStyle descreve como comentar código numa linguagem: o prefixo
// de comentário de linha (ex: "//"), e opcionalmente os marcadores de
// comentário em bloco (ex: "/*" e "*/") — vazios se a linguagem não
// tiver comentário em bloco.
type commentStyle struct {
	Line       string
	BlockStart string
	BlockEnd   string
}

// commentStyleFor devolve o estilo de comentário pra linguagem do
// arquivo — primeiro pela extensão; se não tiver extensão, tenta pelo
// shebang da 1ª linha (igual o realce de sintaxe já faz); se não
// conseguir identificar nada (sem extensão E sem shebang reconhecido),
// cai pra "#" em todas as linhas — é o mais comum em scripts do dia a
// dia sem extensão, e evita assumir sintaxe estilo C (//) à toa.
// realExt devolve a extensão do arquivo pelo mesmo critério de
// filepath.Ext, mas corrigindo um caso que o Go erra: em "dotfiles"
// como ".bashrc" ou ".vimrc" (sem nome nenhum antes do ponto),
// filepath.Ext devolve o nome inteiro (".bashrc") em vez de vazio —
// isso fazia esses arquivos serem tratados como "extensão conhecida
// mas sem formatador/estilo de comentário configurado" em vez de
// cair no fallback certo (shebang, depois padrão universal).
func realExt(path string) string {
	ext := filepath.Ext(path)
	if ext == filepath.Base(path) {
		return ""
	}
	return ext
}

func commentStyleFor(path, firstLine string) commentStyle {
	ext := realExt(path)
	switch ext {
	case ".go", ".c", ".h", ".cpp", ".hpp", ".cc", ".java", ".js", ".ts", ".jsx", ".tsx",
		".rs", ".swift", ".kt", ".cs", ".php", ".scala", ".dart", ".css":
		return commentStyle{Line: "//", BlockStart: "/*", BlockEnd: "*/"}
	case ".py", ".rb", ".pl", ".r", ".yaml", ".yml", ".toml", ".cfg", ".ini":
		return commentStyle{Line: "#"}
	case ".sh", ".bash", ".zsh":
		// bash não tem comentário em bloco de verdade, mas o truque
		// clássico é redirecionar um heredoc pro comando ":" (no-op) —
		// tudo entre as duas marcações vira "entrada" desse comando,
		// então é ignorado na prática, igual um bloco de comentário.
		return commentStyle{Line: "#", BlockStart: ": <<'REMARK'", BlockEnd: "REMARK"}
	case ".lua", ".sql", ".hs":
		return commentStyle{Line: "--"}
	case ".vim":
		return commentStyle{Line: "\""}
	case ".html", ".xml", ".md":
		// essas linguagens só têm comentário em bloco — não existe um
		// "comentário de linha" de verdade nelas
		return commentStyle{BlockStart: "<!--", BlockEnd: "-->"}
	}
	if ext == "" {
		if style, ok := commentStyleFromShebang(firstLine); ok {
			return style
		}
	}
	// sem extensão e sem shebang reconhecido (ou extensão desconhecida):
	// "#" é o palpite mais seguro pra script do dia a dia
	return commentStyle{Line: "#"}
}

// commentStyleFromShebang tenta identificar a linguagem pelo
// interpretador da 1ª linha (ex: "#!/usr/bin/env python3").
func commentStyleFromShebang(firstLine string) (commentStyle, bool) {
	firstLine = strings.TrimSpace(firstLine)
	if !strings.HasPrefix(firstLine, "#!") {
		return commentStyle{}, false
	}
	rest := strings.TrimSpace(strings.TrimPrefix(firstLine, "#!"))
	fields := strings.Fields(rest)
	if len(fields) == 0 {
		return commentStyle{}, false
	}
	interpreter := filepath.Base(fields[0])
	if interpreter == "env" && len(fields) > 1 {
		interpreter = filepath.Base(fields[1])
	}
	switch interpreter {
	case "bash", "sh", "zsh", "dash", "ksh":
		return commentStyle{Line: "#", BlockStart: ": <<'REMARK'", BlockEnd: "REMARK"}, true
	case "python", "python3", "python2", "ruby", "perl", "perl5":
		return commentStyle{Line: "#"}, true
	case "node", "nodejs":
		return commentStyle{Line: "//", BlockStart: "/*", BlockEnd: "*/"}, true
	case "lua":
		return commentStyle{Line: "--"}, true
	}
	return commentStyle{}, false
}

func (a *App) doSave() {
	b := a.ActiveBuffer()
	if b.Path == "" {
		a.startPrompt("Salvar como: ", func(path string) {
			if path == "" {
				return
			}
			if err := b.SaveAs(path); err != nil {
				a.SetStatusMsg("erro ao salvar: " + err.Error())
			} else {
				a.SetStatusMsg("salvo em " + path)
			}
		}, nil)
		return
	}
	if err := b.Save(); err != nil {
		a.SetStatusMsg("erro ao salvar: " + err.Error())
	} else {
		a.SetStatusMsg("salvo")
	}
}

func (a *App) doFind(skipCurrent bool) {
	if a.LastSearch == "" {
		return
	}
	b := a.ActiveBuffer()
	fromCol := b.CursorX
	if skipCurrent {
		fromCol++
	}
	y, x, ok := b.Find(a.LastSearch, b.CursorY, fromCol)
	if !ok {
		a.SetStatusMsg("não encontrado: " + a.LastSearch)
		a.SearchHighlightActive = false
		return
	}
	b.CursorY = y
	b.CursorX = x
	a.StatusMsg = ""
	a.SearchHighlightActive = true
	a.SearchHighlightBuf = a.Panes[a.ActivePane]
	a.SearchHighlightY = y
	a.SearchHighlightX0 = x
	a.SearchHighlightX1 = x + len(a.LastSearch)
}

// --- Renomear ao vivo (F2) ---

// startRename entra no modo de renomear: acha a palavra sob o cursor,
// guarda uma cópia do texto original (pra poder cancelar e pra servir de
// base do preview a cada tecla), e identifica qual ocorrência é a de
// origem (onde o F2 foi apertado) — o cursor fica ali, no texto
// principal, durante toda a edição, em vez de pular pra um campo à parte.
func (a *App) startRename(b *buffer.Buffer) {
	word, wordStart, _ := b.WordUnderCursorBounds()
	if word == "" {
		a.SetStatusMsg("cursor precisa estar em cima de uma palavra")
		return
	}
	origY := b.CursorY
	// posição do cursor RELATIVA à palavra (0 = início, len(word) = fim,
	// ou algo no meio) — a edição começa exatamente aí, não sempre no
	// fim. Uma seleção ativa nunca muda qual palavra é essa: o F2
	// sempre mira a palavra sob o cursor, igual o VS Code faz com o
	// LSP (a seleção não influencia o alvo do rename).
	relCursor := b.CursorX - wordStart
	b.ClearSelection()

	orig := make([]string, len(b.Lines))
	copy(orig, b.Lines)

	b.MarkUndoPoint() // um único ponto de undo pra sessão de rename inteira

	a.RenameActive = true
	a.RenameWord = word
	a.RenameNew = word // começa com o nome original intacto (só destacado, como o VS Code)
	a.RenameCursor = relCursor
	a.RenameSelecting = false
	a.RenameOrigLines = orig
	a.RenamePaneBuf = a.Panes[a.ActivePane]

	// acha o índice da ocorrência de origem: a que está na mesma linha
	// e começa exatamente onde a palavra sob o cursor começava.
	_, occs := buffer.ReplaceWholeWordPreview(orig, word, word)
	a.RenameOriginOccIdx = -1
	for idx, o := range occs {
		if o.Y == origY && o.X0 == wordStart {
			a.RenameOriginOccIdx = idx
			break
		}
	}

	a.updateRenamePreview()
}

// updateRenamePreview recalcula o texto (a partir do snapshot original)
// com o nome já digitado até agora, atualiza o destaque das ocorrências,
// e mantém o cursor na ocorrência de ORIGEM (onde o F2 foi apertado),
// na posição correspondente a RenameCursor dentro do nome sendo editado
// — o cursor visível do terminal fica no texto principal, inline, nunca
// numa linha separada.
func (a *App) updateRenamePreview() {
	b := a.Buffers[a.RenamePaneBuf]
	newLines, occs := buffer.ReplaceWholeWordPreview(a.RenameOrigLines, a.RenameWord, a.RenameNew)
	b.Lines = newLines
	a.RenameOccs = occs
	b.Dirty = true
	if a.RenameOriginOccIdx >= 0 && a.RenameOriginOccIdx < len(occs) {
		o := occs[a.RenameOriginOccIdx]
		b.CursorY = o.Y
		b.CursorX = o.X0 + a.RenameCursor
	} else if len(occs) > 0 {
		b.CursorY = occs[0].Y
		b.CursorX = occs[0].X1
	}
}

func (a *App) handleRenameKey(ev *tcell.EventKey) {
	shift := ev.Modifiers()&tcell.ModShift != 0

	switch ev.Key() {
	case tcell.KeyEnter:
		a.commitRename()
		return
	case tcell.KeyEsc:
		a.cancelRename()
		return
	case tcell.KeyLeft:
		a.renameStartOrClearSelect(shift)
		if a.RenameCursor > 0 {
			_, size := utf8.DecodeLastRuneInString(a.RenameNew[:a.RenameCursor])
			a.RenameCursor -= size
		}
		a.updateRenamePreview()
		return
	case tcell.KeyRight:
		a.renameStartOrClearSelect(shift)
		if a.RenameCursor < len(a.RenameNew) {
			_, size := utf8.DecodeRuneInString(a.RenameNew[a.RenameCursor:])
			a.RenameCursor += size
		}
		a.updateRenamePreview()
		return
	case tcell.KeyHome:
		a.renameStartOrClearSelect(shift)
		a.RenameCursor = 0
		a.updateRenamePreview()
		return
	case tcell.KeyEnd:
		a.renameStartOrClearSelect(shift)
		a.RenameCursor = len(a.RenameNew)
		a.updateRenamePreview()
		return
	case tcell.KeyBackspace, tcell.KeyBackspace2:
		if a.RenameSelecting {
			a.renameDeleteSelection()
		} else if a.RenameCursor > 0 {
			_, size := utf8.DecodeLastRuneInString(a.RenameNew[:a.RenameCursor])
			a.RenameNew = a.RenameNew[:a.RenameCursor-size] + a.RenameNew[a.RenameCursor:]
			a.RenameCursor -= size
		}
		a.updateRenamePreview()
		return
	case tcell.KeyDelete:
		if a.RenameSelecting {
			a.renameDeleteSelection()
		} else if a.RenameCursor < len(a.RenameNew) {
			_, size := utf8.DecodeRuneInString(a.RenameNew[a.RenameCursor:])
			a.RenameNew = a.RenameNew[:a.RenameCursor] + a.RenameNew[a.RenameCursor+size:]
		}
		a.updateRenamePreview()
		return
	case tcell.KeyInsert:
		a.OverwriteMode = !a.OverwriteMode
		return
	case tcell.KeyRune:
		r := string(ev.Rune())
		if a.RenameSelecting {
			// marcação ativa: digitar substitui só o trecho marcado,
			// local — não mexe em mais nada além disso.
			a.renameDeleteSelection()
			a.RenameNew = a.RenameNew[:a.RenameCursor] + r + a.RenameNew[a.RenameCursor:]
			a.RenameCursor += len(r)
		} else if a.OverwriteMode && a.RenameCursor < len(a.RenameNew) {
			// sem marcação: comportamento atual — respeita o modo
			// overwrite do editor, substitui o caractere sob o cursor.
			_, size := utf8.DecodeRuneInString(a.RenameNew[a.RenameCursor:])
			a.RenameNew = a.RenameNew[:a.RenameCursor] + r + a.RenameNew[a.RenameCursor+size:]
			a.RenameCursor += len(r)
		} else {
			a.RenameNew = a.RenameNew[:a.RenameCursor] + r + a.RenameNew[a.RenameCursor:]
			a.RenameCursor += len(r)
		}
		a.updateRenamePreview()
		return
	}
}

// renameStartOrClearSelect ancora uma nova marcação (se shift pressionado
// e ainda não havia marcação) ou cancela a marcação atual (se moveu sem
// shift) — mesma lógica do Shift+seta no editor principal.
func (a *App) renameStartOrClearSelect(shift bool) {
	if shift {
		if !a.RenameSelecting {
			a.RenameSelecting = true
			a.RenameSelStart = a.RenameCursor
		}
	} else {
		a.RenameSelecting = false
	}
}

// renameDeleteSelection apaga o trecho marcado dentro do campo de nome e
// deixa o cursor no ponto do corte.
func (a *App) renameDeleteSelection() {
	s, e := a.RenameSelStart, a.RenameCursor
	if s > e {
		s, e = e, s
	}
	a.RenameNew = a.RenameNew[:s] + a.RenameNew[e:]
	a.RenameCursor = s
	a.RenameSelecting = false
}

func (a *App) commitRename() {
	b := a.Buffers[a.RenamePaneBuf]
	if a.RenameNew == "" || a.RenameNew == a.RenameWord {
		// nome vazio ou igual ao original: nada de fato mudou, restaura
		// o texto original pra não deixar uma alteração vazia no undo.
		b.Lines = a.RenameOrigLines
		b.Dirty = len(a.RenameOrigLines) > 0 && b.Dirty // mantém o estado anterior
		a.SetStatusMsg("renomear cancelado (nome vazio ou igual)")
	} else {
		a.SetStatusMsg(fmt.Sprintf("%d ocorrência(s) de '%s' renomeada(s) para '%s'",
			len(a.RenameOccs), a.RenameWord, a.RenameNew))
	}
	a.RenameActive = false
	a.RenameOccs = nil
	a.RenameOrigLines = nil
}

func (a *App) cancelRename() {
	b := a.Buffers[a.RenamePaneBuf]
	b.Lines = a.RenameOrigLines
	a.RenameActive = false
	a.RenameOccs = nil
	a.RenameOrigLines = nil
	a.SetStatusMsg("renomear cancelado")
}
