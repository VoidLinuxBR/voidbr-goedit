package ui

import (
	"bytes"
	"errors"
	"fmt"
	"os/exec"
	"path/filepath"
	"strings"
)

// formatterCmd é o comando (+ argumentos) usado pra formatar um tipo de
// arquivo — sempre lendo o código pela entrada padrão e devolvendo o
// resultado formatado pela saída padrão, sem tocar em arquivo nenhum no
// disco (o goedit é quem decide se salva ou não).
type formatterCmd struct {
	cmd  string
	args []string
}

// formattersByExt mapeia extensão de arquivo pro formatador externo
// correspondente. Fácil de estender: só adicionar uma linha nova.
var formattersByExt = map[string]formatterCmd{
	".go":   {cmd: "gofmt"},
	".sh":   {cmd: "shfmt"},
	".bash": {cmd: "shfmt"},
}

// formatterFor devolve o formatador certo pro caminho do arquivo, ou
// ok=false se não tiver um configurado pra essa extensão.
func formatterFor(path string) (formatterCmd, bool) {
	fc, ok := formattersByExt[filepath.Ext(path)]
	return fc, ok
}

// FormatActiveBuffer roda o formatador externo correspondente à
// linguagem do arquivo ativo, substituindo o conteúdo pelo resultado
// formatado (como uma única alteração de undo) se tudo der certo.
func (a *App) FormatActiveBuffer() {
	b := a.ActiveBuffer()
	fc, ok := formatterFor(b.Path)
	if !ok {
		a.StatusMsg = "sem formatador configurado pra esse tipo de arquivo"
		return
	}

	input := strings.Join(b.Lines, "\n") + "\n"
	cmd := exec.Command(fc.cmd, fc.args...)
	cmd.Stdin = strings.NewReader(input)
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr

	err := cmd.Run()
	if err != nil {
		var execErr *exec.Error
		if errors.As(err, &execErr) && errors.Is(execErr.Err, exec.ErrNotFound) {
			a.StatusMsg = fmt.Sprintf("%s não está instalado", fc.cmd)
			return
		}
		msg := strings.TrimSpace(stderr.String())
		if msg == "" {
			msg = err.Error()
		}
		a.StatusMsg = fmt.Sprintf("erro ao formatar (%s): %s", fc.cmd, firstLineOnly(msg))
		return
	}

	out := stdout.String()
	out = strings.TrimSuffix(out, "\n")
	newLines := strings.Split(out, "\n")
	b.SetLines(newLines)
	a.StatusMsg = fmt.Sprintf("formatado com %s", fc.cmd)
}

// firstLineOnly corta uma mensagem de erro multi-linha na primeira linha,
// pra não estourar a barra de status com o erro inteiro do formatador.
func firstLineOnly(s string) string {
	if i := strings.IndexByte(s, '\n'); i >= 0 {
		return s[:i]
	}
	return s
}
