/*
   goedit
   Editor de texto para terminal (TUI), com realce de sintaxe, plugins Lua, seleção em bloco e mais
   Site:      https://chililinux.com
   Site:      https://voidbr.org
   Site:      https://voidlinux.com.br
   GitHub:    https://github.com/voidlinuxbr/voidbr-goedit
   Created:   dom 16 ago 2026 10:15:33 -04
   Updated:   sex 21 ago 2026 11:30:00 -04
   Version:   0.29.0
   Copyright (C) 2019-2026 Vilmar Catafesta <vcatafesta@gmail.com>
*/

package main

import (
	"fmt"
	"os"

	"github.com/gdamore/tcell/v2"

	"goedit/internal/ui"
)

// Version é atualizada a cada release (ver CHANGELOG.md).
const Version = "0.29.0"

func main() {
	if len(os.Args) > 1 && (os.Args[1] == "--version" || os.Args[1] == "-v") {
		fmt.Printf("goedit v%s\n", Version)
		return
	}

	screen, err := tcell.NewScreen()
	if err != nil {
		fmt.Fprintln(os.Stderr, "erro ao iniciar terminal:", err)
		os.Exit(1)
	}
	if err := screen.Init(); err != nil {
		fmt.Fprintln(os.Stderr, "erro ao iniciar terminal:", err)
		os.Exit(1)
	}
	defer screen.Fini()
	screen.SetStyle(tcell.StyleDefault)
	screen.EnableMouse()
	screen.EnablePaste()

	app := ui.NewApp(screen, os.Args[1:])
	defer app.Plugins.Close()

	app.Render()
	for !app.Quit {
		ev := screen.PollEvent()
		switch e := ev.(type) {
		case *tcell.EventResize:
			screen.Sync()
		case *tcell.EventKey:
			app.HandleKey(e)
		case *tcell.EventMouse:
			app.HandleMouse(e)
		case *tcell.EventPaste:
			app.Pasting = e.Start()
			if !app.Pasting {
				app.FinishPaste()
			}
		}
		// enquanto colando (paste nativo do terminal, entre o início e
		// o fim marcados por EventPaste), as teclas do texto colado
		// ainda chegam uma a uma — mas só redesenha a tela quando
		// terminar de colar, em vez de ficar atualizando palavra por
		// palavra, linha por linha, a cada caractere.
		if !app.Pasting {
			app.Render()
		}
	}
	app.SaveAllOpenPositions()
}
