/*
   goedit
   Editor de texto para terminal (TUI), com realce de sintaxe, plugins Lua, seleção em bloco e mais
   Site:      https://chililinux.com
   Site:      https://voidbr.org
   Site:      https://voidlinux.com.br
   GitHub:    https://github.com/voidlinuxbr/voidbr-goedit
   Created:   dom 16 ago 2026 10:15:33 -04
   Updated:   sex 21 ago 2026 11:30:00 -04
   Version:   0.29.0
   Copyright (C) 2019-2026 Vilmar Catafesta <vcatafesta@gmail.com>
*/

package config

import (
	"encoding/json"
	"os"
	"path/filepath"
)

// PluginDir devolve ~/.config/goedit/plugins, criando o diretório se preciso.
func PluginDir() string {
	home, err := os.UserHomeDir()
	if err != nil {
		return "plugins"
	}
	dir := filepath.Join(home, ".config", "goedit", "plugins")
	_ = os.MkdirAll(dir, 0o755)
	return dir
}

// Settings são as preferências configuráveis do editor.
// Ficam em ~/.config/goedit/settings.json — o arquivo não existe até o
// usuário criar um (LoadSettings devolve os padrões nesse caso).
type Settings struct {
	// TabWidth é quantas colunas uma tabulação ocupa na tela, e também
	// quantos espaços a tecla Tab insere quando InsertSpaces é true.
	TabWidth int `json:"tabWidth"`
	// InsertSpaces: true insere espaços ao apertar Tab (padrão da maioria
	// dos editores modernos); false insere um caractere de tabulação real.
	InsertSpaces bool `json:"insertSpaces"`
}

// rawSettings usa ponteiros pra distinguir "campo ausente no JSON" de
// "campo presente com valor zero" — um settings.json com só tabWidth não
// deve zerar insertSpaces sem querer.
type rawSettings struct {
	TabWidth     *int  `json:"tabWidth"`
	InsertSpaces *bool `json:"insertSpaces"`
}

func defaultSettings() Settings {
	return Settings{TabWidth: 4, InsertSpaces: true}
}

// settingsPath devolve ~/.config/goedit/settings.json.
func settingsPath() string {
	home, err := os.UserHomeDir()
	if err != nil {
		return "settings.json"
	}
	return filepath.Join(home, ".config", "goedit", "settings.json")
}

// LoadSettings lê ~/.config/goedit/settings.json. Se o arquivo não existir
// ou tiver erro de leitura/parse, devolve os padrões (TabWidth: 4,
// InsertSpaces: true) sem quebrar a inicialização do editor. Campos
// ausentes no JSON mantêm o valor padrão.
func LoadSettings() Settings {
	s := defaultSettings()
	data, err := os.ReadFile(settingsPath())
	if err != nil {
		return s
	}
	var raw rawSettings
	if err := json.Unmarshal(data, &raw); err != nil {
		return s
	}
	if raw.TabWidth != nil && *raw.TabWidth > 0 {
		s.TabWidth = *raw.TabWidth
	}
	if raw.InsertSpaces != nil {
		s.InsertSpaces = *raw.InsertSpaces
	}
	return s
}

// --- Posição de cursor por arquivo (linha/coluna) ---

// Position é a última posição do cursor num arquivo, salva ao fechar
// (aba ou app) e restaurada ao reabrir o mesmo arquivo.
type Position struct {
	Line int `json:"line"`
	Col  int `json:"col"`
}

// positionsPath devolve ~/.config/goedit/positions.json.
func positionsPath() string {
	home, err := os.UserHomeDir()
	if err != nil {
		return "positions.json"
	}
	return filepath.Join(home, ".config", "goedit", "positions.json")
}

// LoadPositions lê ~/.config/goedit/positions.json (chave = caminho
// absoluto do arquivo). Se não existir ou der erro, devolve um mapa
// vazio sem quebrar a inicialização.
func LoadPositions() map[string]Position {
	positions := map[string]Position{}
	data, err := os.ReadFile(positionsPath())
	if err != nil {
		return positions
	}
	_ = json.Unmarshal(data, &positions) // erro de parse: só fica vazio mesmo
	return positions
}

// SavePositions grava o mapa inteiro de volta em
// ~/.config/goedit/positions.json — sobrescreve o arquivo, então quem
// chama precisa carregar (LoadPositions), atualizar as entradas que
// mudaram, e só então salvar o mapa completo.
func SavePositions(positions map[string]Position) error {
	home, err := os.UserHomeDir()
	if err != nil {
		return err
	}
	dir := filepath.Join(home, ".config", "goedit")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return err
	}
	data, err := json.MarshalIndent(positions, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(positionsPath(), data, 0o644)
}
