package ui

import (
	"github.com/gdamore/tcell/v2"
)

// mouseDragging indica se o botão esquerdo está sendo segurado desde um
// clique anterior no texto — usado pra saber se um movimento de mouse com
// botão pressionado deve estender a seleção.
var mouseDragging bool

// --- Entrada principal ---

// HandleMouse processa clique, arrasto e roda do mouse. Ordem de
// despacho: arrasto de redimensionamento em andamento tem prioridade
// total (captura o mouse até soltar); depois o menu de contexto, se
// estiver aberto; depois clique direito (abre menu); depois roda;
// depois clique na sidebar; por fim clique em aba/texto de algum painel.
func (a *App) HandleMouse(ev *tcell.EventMouse) {
	if a.PromptActive {
		return // prompts não reagem a mouse por enquanto
	}
	a.SuggestActive = false // qualquer interação de mouse cancela sugestão pendente

	x, y := ev.Position()
	btn := ev.Buttons()

	if a.ResizingSidebar {
		a.continueResizeSidebar(x, btn)
		return
	}

	if a.ContextMenuActive {
		a.handleContextMenuClick(x, y, btn)
		return
	}

	if btn&tcell.Button2 != 0 { // botão direito: abre menu de contexto
		a.handleRightClick(x, y)
		return
	}

	if delta, ok := wheelDelta(btn); ok {
		a.handleWheel(x, y, delta)
		return
	}

	if a.pointInSidebar(x, y) {
		a.handleSidebarClick(x, y, btn)
		return
	}

	if btn&tcell.Button1 != 0 && a.Layout.SidebarVisible && x == a.Layout.SidebarBorderX {
		a.ResizingSidebar = true
		return
	}

	a.handlePaneClick(x, y, btn, ev.Modifiers()&tcell.ModShift != 0)
}

// wheelDelta traduz o estado dos botões num delta de rolagem (+3 pra
// baixo, -3 pra cima), ou ok=false se o evento não é de roda.
func wheelDelta(btn tcell.ButtonMask) (delta int, ok bool) {
	switch {
	case btn&tcell.WheelUp != 0:
		return -3, true
	case btn&tcell.WheelDown != 0:
		return 3, true
	default:
		return 0, false
	}
}

// handleWheel rola a sidebar se o ponteiro estiver em cima dela, senão
// rola o painel de texto sob o ponteiro.
func (a *App) handleWheel(x, y, delta int) {
	if a.scrollSidebarAt(x, y, delta) {
		return
	}
	a.scrollPaneAt(x, y, delta)
}

// pointInSidebar diz se a coordenada de tela cai dentro da área visível
// da sidebar (usado pra clique, roda do mouse e início do redimensionamento).
func (a *App) pointInSidebar(x, y int) bool {
	return a.Layout.SidebarVisible &&
		x >= a.Layout.SidebarX0 && x < a.Layout.SidebarX1 &&
		y >= a.Layout.SidebarY0 && y < a.Layout.SidebarY1
}

// --- Redimensionamento da sidebar por arrasto ---

// continueResizeSidebar atualiza a largura da sidebar enquanto o botão
// segue pressionado, e encerra o arrasto quando o botão é solto.
func (a *App) continueResizeSidebar(x int, btn tcell.ButtonMask) {
	if btn&tcell.Button1 == 0 {
		a.ResizingSidebar = false
		return
	}
	const minWidth, maxWidth = 12, 80
	a.SidebarWidth = clamp(x, minWidth, maxWidth)
}

// --- Menu de contexto ---

// handleRightClick decide qual menu abrir (se algum) de acordo com o que
// está embaixo do clique direito: título da sidebar ou uma aba do editor.
func (a *App) handleRightClick(x, y int) {
	if a.Layout.SidebarVisible && a.pointInSidebar(x, y) && y == a.Layout.SidebarY0 {
		a.OpenContextMenu(x, y+1, a.sidebarContextMenuItems())
		return
	}
	for _, pl := range a.Layout.Panes {
		if y != pl.TabY || x < pl.X || x >= pl.X+pl.Width {
			continue
		}
		for _, tr := range pl.TabRanges {
			if x >= tr.X0 && x < tr.X1 {
				a.OpenContextMenu(x, y+1, a.tabContextMenuItems(tr.BufIdx))
				return
			}
		}
	}
}

// tabContextMenuItems monta as opções do menu de contexto de uma aba.
func (a *App) tabContextMenuItems(bufIdx int) []ContextMenuItem {
	return []ContextMenuItem{
		{Label: "Fechar", Action: func(a *App) { a.CloseBufferAt(bufIdx) }},
		{Label: "Fechar outras", Action: func(a *App) { a.CloseOtherBuffersAt(bufIdx) }},
		{Label: "Fechar todas", Action: func(a *App) { a.CloseAllBuffers() }},
		{Label: "Salvar", Action: func(a *App) { a.SaveBufferAt(bufIdx) }},
	}
}

// sidebarContextMenuItems monta as opções do menu de contexto do título
// da sidebar.
func (a *App) sidebarContextMenuItems() []ContextMenuItem {
	return []ContextMenuItem{
		{Label: "Fechar", Action: func(a *App) {
			a.ShowSidebar = false
			a.SidebarFocused = false
		}},
		{Label: "Atualizar", Action: func(a *App) { a.reloadSidebar() }},
	}
}

// handleContextMenuClick resolve um clique enquanto o menu de contexto
// está aberto: clicar num item executa a ação dele; clicar em qualquer
// outro lugar só fecha o menu, sem fazer nada.
func (a *App) handleContextMenuClick(x, y int, btn tcell.ButtonMask) {
	if btn&tcell.Button1 == 0 {
		return // só reage a clique de verdade (press), não a soltura
	}
	mx, my, mw, _ := a.contextMenuBox()
	row := y - my
	if row >= 0 && row < len(a.ContextMenuItems) && x >= mx && x < mx+mw {
		action := a.ContextMenuItems[row].Action
		a.CloseContextMenu()
		if action != nil {
			action(a)
		}
		return
	}
	a.CloseContextMenu()
}

// --- Sidebar: clique normal (fora do menu de contexto) ---

// handleSidebarClick trata clique esquerdo em qualquer parte da sidebar:
// o "x" de fechar no título, ou uma entrada da lista de arquivos.
func (a *App) handleSidebarClick(x, y int, btn tcell.ButtonMask) {
	if btn&tcell.Button1 == 0 {
		return
	}
	if y == a.Layout.SidebarY0 && a.Layout.SidebarCloseX0 >= 0 &&
		x >= a.Layout.SidebarCloseX0 && x < a.Layout.SidebarCloseX1 {
		a.ShowSidebar = false
		a.SidebarFocused = false
		return
	}
	a.clickSidebar(y)
}

// clickSidebar seleciona e abre a entrada clicada. Abrir um arquivo pelo
// mouse funciona igual ao Enter do teclado: abre numa aba e mantém a
// sidebar aberta (só perde o foco) — ela só fecha de verdade quando o
// usuário aperta Ctrl+B (ou o "x" do título) de novo, nunca sozinha por
// causa de um clique num arquivo.
func (a *App) clickSidebar(y int) {
	idx := a.SidebarOffset + (y - a.Layout.SidebarRowY0)
	if idx < 0 || idx >= len(a.SidebarEntries) {
		return
	}
	a.SidebarSel = idx
	a.SidebarFocused = true
	a.openSidebarEntry(a.SidebarEntries[idx])
}

// scrollSidebarAt rola a lista de arquivos da sidebar quando o mouse está
// em cima dela. Devolve false se o ponteiro não está sobre a sidebar (pra
// o chamador tentar rolar o painel de texto em vez disso).
func (a *App) scrollSidebarAt(x, y, delta int) bool {
	if !a.pointInSidebar(x, y) {
		return false
	}
	a.SidebarSel = clamp(a.SidebarSel+delta, 0, len(a.SidebarEntries)-1)
	return true
}

// --- Abas e texto ---

// handlePaneClick trata clique/arrasto/soltura de botão esquerdo dentro
// de algum painel de edição (aba ou texto).
func (a *App) handlePaneClick(x, y int, btn tcell.ButtonMask, extendSelection bool) {
	for i, pl := range a.Layout.Panes {
		if x < pl.X || x >= pl.X+pl.Width {
			continue
		}
		if btn&tcell.Button1 == 0 {
			// botão solto: encerra o arrasto de seleção, se houver
			mouseDragging = false
			return
		}

		a.ActivePane = i
		a.SidebarFocused = false

		if y == pl.TabY {
			a.clickTabAt(pl, x)
			mouseDragging = false
			return
		}
		if y >= pl.TextTop && y < pl.TextTop+pl.TextHeight {
			a.clickText(pl, x, y, extendSelection)
			return
		}
		return
	}
}

func (a *App) clickTabAt(pl PaneLayout, x int) {
	for _, tr := range pl.TabRanges {
		if x >= tr.CloseX0 && x < tr.CloseX1 {
			a.CloseBufferAt(tr.BufIdx)
			return
		}
		if x >= tr.X0 && x < tr.X1 {
			a.Panes[a.ActivePane] = tr.BufIdx
			return
		}
	}
}

// clickText posiciona o cursor (ou estende a seleção) na posição de
// texto correspondente à coordenada de tela clicada, considerando
// scroll horizontal/vertical e largura de tabulação.
func (a *App) clickText(pl PaneLayout, x, y int, extendSelection bool) {
	b := a.Buffers[pl.BufIdx]

	lineIdx := clamp(b.OffsetY+(y-pl.TextTop), 0, len(b.Lines)-1)

	tabWidth := a.Settings.TabWidth
	if tabWidth <= 0 {
		tabWidth = 4
	}
	targetVCol := b.OffsetX + (x - pl.TextX)
	if targetVCol < 0 {
		targetVCol = 0
	}
	col := byteIndexForVisualCol(b.Lines[lineIdx], targetVCol, tabWidth)

	if extendSelection || mouseDragging {
		if !b.Selecting {
			// início de um arrasto nunca marcado: ancora na posição
			// atual do cursor antes de mover
			b.StartSelection()
		}
	} else {
		b.ClearSelection()
	}
	b.CursorY = lineIdx
	b.CursorX = col
	mouseDragging = true
}

// scrollPaneAt rola o painel de texto sob o cursor do mouse, movendo o
// cursor junto (o auto-scroll da renderização segue a posição do cursor,
// então não dá pra rolar a viewport sem mover o cursor também neste
// editor) — o cursor fica sempre na mesma linha de tela onde o ponteiro
// está, não foge pras extremidades.
func (a *App) scrollPaneAt(x, y, delta int) {
	for i, pl := range a.Layout.Panes {
		if x < pl.X || x >= pl.X+pl.Width {
			continue
		}
		if y < pl.TextTop || y >= pl.TextTop+pl.TextHeight {
			continue
		}
		b := a.Buffers[pl.BufIdx]
		b.ClearSelection()

		mouseLineIdx := b.OffsetY + (y - pl.TextTop)

		maxOffset := len(b.Lines) - pl.TextHeight
		if maxOffset < 0 {
			maxOffset = 0
		}
		b.OffsetY = clamp(b.OffsetY+delta, 0, maxOffset)
		b.CursorY = clamp(mouseLineIdx+delta, 0, len(b.Lines)-1)
		b.CursorX = 0

		a.ActivePane = i
		return
	}
}

// clamp restringe v ao intervalo [lo, hi]. Se hi < lo (ex: lista vazia,
// len-1 = -1), devolve lo.
func clamp(v, lo, hi int) int {
	if v < lo {
		return lo
	}
	if hi >= lo && v > hi {
		return hi
	}
	return v
}
