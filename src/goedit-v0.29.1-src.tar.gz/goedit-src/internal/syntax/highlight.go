/*
   goedit
   Editor de texto para terminal (TUI), com realce de sintaxe, plugins Lua, seleção em bloco e mais
   Site:      https://chililinux.com
   Site:      https://voidbr.org
   Site:      https://voidlinux.com.br
   GitHub:    https://github.com/voidlinuxbr/voidbr-goedit
   Created:   dom 16 ago 2026 10:15:33 -04
   Updated:   sex 21 ago 2026 11:30:00 -04
   Version:   0.29.1
   Copyright (C) 2019-2026 Vilmar Catafesta <vcatafesta@gmail.com>
*/

package syntax

import (
	"path/filepath"
	"strings"
	"sync"

	"github.com/alecthomas/chroma/v2"
	"github.com/alecthomas/chroma/v2/lexers"
	"github.com/gdamore/tcell/v2"
)

// Segment é um pedaço de texto com uma cor associada.
type Segment struct {
	Text  string
	Style tcell.Style
}

var base = tcell.StyleDefault

// lexerCache guarda o lexer já resolvido por (nome de arquivo, 1ª linha).
// A 1ª linha só entra na chave quando o arquivo não tem extensão — é o
// que muda a detecção por shebang. Resolver o lexer (lexers.Match) varre
// a lista inteira de linguagens suportadas pelo chroma — caro demais pra
// fazer de novo a cada linha, em cada redraw.
var (
	lexerCacheMu sync.Mutex
	lexerCache   = map[string]chroma.Lexer{} // nil = arquivo sem lexer conhecido
)

// shebangInterpreter mapeia o nome do interpretador citado no shebang
// (#!/usr/bin/interpreter ou #!/usr/bin/env interpreter) pro nome/alias
// que o chroma reconhece. Cobre os casos onde o nome do binário difere
// do nome que o chroma usa (ex: "python3" -> "python").
var shebangInterpreter = map[string]string{
	"python3": "python",
	"python2": "python",
	"sh":      "bash",
	"dash":    "bash",
	"ksh":     "bash",
	"zsh":     "bash",
	"node":    "javascript",
	"nodejs":  "javascript",
}

// lexerFromShebang lê a primeira linha do arquivo e, se for um shebang
// (#!...), tenta achar um lexer do chroma pro interpretador citado.
func lexerFromShebang(firstLine string) chroma.Lexer {
	firstLine = strings.TrimSpace(firstLine)
	if !strings.HasPrefix(firstLine, "#!") {
		return nil
	}
	rest := strings.TrimSpace(strings.TrimPrefix(firstLine, "#!"))
	fields := strings.Fields(rest)
	if len(fields) == 0 {
		return nil
	}
	interpreter := filepath.Base(fields[0])
	if interpreter == "env" && len(fields) > 1 {
		interpreter = filepath.Base(fields[1])
	}
	if alias, ok := shebangInterpreter[interpreter]; ok {
		interpreter = alias
	}
	return lexers.Get(interpreter)
}

// lexerFor resolve o lexer pra um arquivo: primeiro pela extensão; se o
// arquivo não tem extensão reconhecida, tenta pelo shebang da 1ª linha;
// se ainda assim não achar nada e o arquivo não tem extensão, usa bash
// como padrão (é o caso mais comum de script sem extensão no dia a dia).
func lexerFor(filename, firstLine string) chroma.Lexer {
	// a 1ª linha só influencia o resultado quando o arquivo NÃO tem
	// extensão (aí sim entra em jogo pra detectar shebang) — incluir
	// ela sempre na chave, mesmo pra arquivo com extensão reconhecida,
	// invalidava o cache toda vez que a pessoa editava a 1ª linha do
	// arquivo, obrigando reconstruir o lexer do zero a cada tecla.
	key := filename
	if filepath.Ext(filename) == "" {
		key = filename + "\x00" + firstLine
	}

	lexerCacheMu.Lock()
	if lx, ok := lexerCache[key]; ok {
		lexerCacheMu.Unlock()
		return lx // pode ser nil, e está tudo bem — já sabemos que não tem highlight
	}
	lexerCacheMu.Unlock()

	lx := lexers.Match(filename)
	if lx == nil {
		// nem a extensão nem (se não tinha extensão) o shebang acharam
		// nada — usa bash como padrão universal, é o caso mais comum de
		// arquivo de texto/script sem highlight reconhecido.
		lx = lexerFromShebang(firstLine)
		if lx == nil {
			lx = lexers.Get("bash")
		}
	}
	if lx != nil {
		lx = chroma.Coalesce(lx)
	}

	lexerCacheMu.Lock()
	lexerCache[key] = lx
	lexerCacheMu.Unlock()
	return lx
}

// styleFor mapeia a categoria de token do chroma pra uma cor do
// terminal. isBash aplica um esquema de cores à parte pro bash
// (baseado numa captura de tela do VS Code que o usuário mandou) —
// outras linguagens mantêm o esquema padrão de sempre.
func styleFor(t chroma.TokenType, text string, isBash bool) tcell.Style {
	if isBash {
		if st, ok := styleForBash(t, text); ok {
			return st
		}
	}
	switch {
	case t.InCategory(chroma.Comment):
		return base.Foreground(tcell.ColorGray).Italic(true)
	case t.InCategory(chroma.Keyword):
		return base.Foreground(tcell.ColorSteelBlue).Bold(true)
	case t.InCategory(chroma.String):
		return base.Foreground(tcell.ColorOlive)
	case t.InCategory(chroma.Number):
		return base.Foreground(tcell.ColorPurple)
	case t == chroma.NameFunction, t == chroma.NameFunctionMagic:
		return base.Foreground(tcell.ColorTeal)
	case t == chroma.NameVariable, t == chroma.NameVariableGlobal,
		t == chroma.NameVariableInstance, t == chroma.NameVariableClass,
		t == chroma.NameVariableMagic:
		return base.Foreground(tcell.ColorLightSkyBlue)
	case t == chroma.NameBuiltin, t == chroma.NameBuiltinPseudo:
		return base.Foreground(tcell.ColorDarkCyan)
	case t == chroma.NameClass, t == chroma.NameNamespace:
		return base.Foreground(tcell.ColorTeal).Bold(true)
	case t == chroma.NameConstant:
		return base.Foreground(tcell.ColorPurple)
	case t == chroma.NameDecorator, t == chroma.NameTag, t == chroma.NameAttribute,
		t == chroma.NameLabel, t == chroma.NameProperty:
		return base.Foreground(tcell.ColorOrange)
	case t == chroma.NameException:
		return base.Foreground(tcell.ColorRed)
	case t.InCategory(chroma.Name):
		return base
	case t.InCategory(chroma.Operator), t.InCategory(chroma.Punctuation):
		return base.Foreground(tcell.ColorSilver)
	default:
		return base
	}
}

// styleForBash é o esquema de cores extraído de capturas de tela do
// VS Code que o usuário mandou (tons próximos do tema "GitHub Dark"),
// aplicado só em arquivos bash — cores tiradas por amostragem direta
// dos pixels da imagem, não chutadas. O chroma classifica tanto
// "$var"/"${var}" (referência) quanto "nome" em "declare nome=..."
// (só o nome, sem $) como o mesmo tipo de token (NameVariable) — pra
// diferenciar (vermelho só na referência com $, igual pedido à parte;
// azul no nome declarado, igual a imagem mostra) só dá olhando o
// próprio texto do token, não só o tipo.
func styleForBash(t chroma.TokenType, text string) (tcell.Style, bool) {
	switch {
	case t.InCategory(chroma.Comment):
		return base.Foreground(tcell.NewRGBColor(0x8b, 0x94, 0x9e)), true // cinza
	case t.InCategory(chroma.Keyword):
		return base.Foreground(tcell.NewRGBColor(0xff, 0x7b, 0x72)), true // coral/vermelho
	case t.InCategory(chroma.String):
		return base.Foreground(tcell.NewRGBColor(0xa5, 0xd6, 0xff)), true // azul claro
	case t.InCategory(chroma.Number):
		return base.Foreground(tcell.NewRGBColor(0xb4, 0xce, 0xa7)), true // verde claro
	case t == chroma.NameFunction, t == chroma.NameFunctionMagic:
		return base.Foreground(tcell.NewRGBColor(0xd2, 0xa7, 0xff)), true // lilás
	case t == chroma.NameVariable, t == chroma.NameVariableGlobal,
		t == chroma.NameVariableInstance, t == chroma.NameVariableClass,
		t == chroma.NameVariableMagic:
		if strings.HasPrefix(text, "$") {
			return base.Foreground(tcell.ColorRed), true // $VAR, ${VAR}, $1 — referência de verdade
		}
		return base.Foreground(tcell.NewRGBColor(0x56, 0x9c, 0xd6)), true // nome declarado (sem $) — mesmo azul do declare
	case t == chroma.NameBuiltin, t == chroma.NameBuiltinPseudo:
		return base.Foreground(tcell.NewRGBColor(0x56, 0x9c, 0xd6)), true // azul médio
	}
	return tcell.Style{}, false
}

// resultCache guarda o resultado já tokenizado por (arquivo, texto da linha).
// Mover o cursor redesenha a tela inteira, mas o conteúdo das linhas visíveis
// quase nunca muda entre um redraw e outro — então cacheamos o resultado.
var (
	resultCacheMu sync.Mutex
	resultCache   = map[string][]Segment{}
)

// DebugLexerName devolve o nome do lexer resolvido pra um arquivo (ou
// "nenhum" se não achou nenhum) — só pra diagnóstico/depuração.
func DebugLexerName(filename, firstLine string) string {
	lx := lexerFor(filename, firstLine)
	if lx == nil {
		return "nenhum"
	}
	return lx.Config().Name
}

// HighlightLine tokeniza uma linha de acordo com a linguagem do arquivo
// (detectada pela extensão, ou pelo shebang de firstLine se não houver
// extensão, ou bash como último recurso pra arquivos sem extensão).
func HighlightLine(filename, firstLine, line string) []Segment {
	// mesmo raciocínio do lexerFor: firstLine só importa de verdade
	// pra arquivo sem extensão. Incluir sempre na chave fazia editar a
	// 1ª linha do arquivo invalidar o highlight cacheado de TODAS as
	// outras linhas visíveis, não só dela mesma.
	key := filename + "\x00" + line
	if filepath.Ext(filename) == "" {
		key = filename + "\x00" + firstLine + "\x00" + line
	}
	resultCacheMu.Lock()
	if segs, ok := resultCache[key]; ok {
		resultCacheMu.Unlock()
		return segs
	}
	resultCacheMu.Unlock()

	lexer := lexerFor(filename, firstLine)
	if lexer == nil {
		return []Segment{{Text: line, Style: base}}
	}
	isBash := lexer.Config().Name == "Bash"
	iter, err := lexer.Tokenise(nil, line)
	if err != nil {
		return []Segment{{Text: line, Style: base}}
	}
	var segs []Segment
	afterDollarBrace := false
	for _, tok := range iter.Tokens() {
		if tok.Value == "" {
			continue
		}
		// chroma pode devolver a quebra de linha junto; removemos.
		txt := strings.TrimSuffix(tok.Value, "\n")
		if txt == "" {
			continue
		}
		effectiveText := txt
		if afterDollarBrace && tok.Type == chroma.NameVariable {
			// "${var}" vem em 3 tokens separados (${ / var / }) — o do
			// meio não carrega o "$" junto, então sem isso aqui ele
			// cairia como nome declarado (azul) em vez de referência
			// de verdade (vermelho).
			effectiveText = "$" + txt
		}
		afterDollarBrace = strings.HasSuffix(txt, "${")
		segs = append(segs, Segment{Text: txt, Style: styleFor(tok.Type, effectiveText, isBash)})
	}
	if len(segs) == 0 {
		segs = []Segment{{Text: line, Style: base}}
	}

	resultCacheMu.Lock()
	if len(resultCache) > 5000 {
		// evita crescer sem limite em sessões muito longas de edição
		resultCache = map[string][]Segment{}
	}
	resultCache[key] = segs
	resultCacheMu.Unlock()
	return segs
}
