/*
   goedit
   Editor de texto para terminal (TUI), com realce de sintaxe, plugins Lua, seleção em bloco e mais
   Site:      https://chililinux.com
   Site:      https://voidbr.org
   Site:      https://voidlinux.com.br
   GitHub:    https://github.com/voidlinuxbr/voidbr-goedit
   Created:   dom 16 ago 2026 10:15:33 -04
   Updated:   sex 21 ago 2026 11:30:00 -04
   Version:   0.38.0
   Copyright (C) 2019-2026 Vilmar Catafesta <vcatafesta@gmail.com>
*/

package ui

import (
	"strings"

	"github.com/gdamore/tcell/v2"
)

// startBlockSelect inicia (ou, se já ativo, só garante que está ativo) o
// modo de seleção em bloco, ancorando na posição atual do cursor.
func (a *App) startBlockSelect() {
	if a.BlockActive {
		return
	}
	b := a.ActiveBuffer()
	a.BlockActive = true
	a.BlockEditing = false
	a.BlockAnchorY = b.CursorY
	a.BlockAnchorX = b.CursorX
	a.BlockColWidth = 0
	a.BlockPaneBuf = a.Panes[a.ActivePane]
}

// handleBlockKey trata as teclas do modo de seleção em bloco. Devolve
// true se tratou a tecla (o chamador não deve fazer mais nada com ela).
func (a *App) handleBlockKey(ev *tcell.EventKey) bool {
	mods := ev.Modifiers()
	ctrlShift := mods&tcell.ModCtrl != 0 && mods&tcell.ModShift != 0

	if a.BlockEditing {
		return a.handleBlockEditingKey(ev)
	}

	// ainda só marcando (antes de digitar qualquer coisa)
	if ctrlShift {
		b := a.Buffers[a.BlockPaneBuf]
		switch ev.Key() {
		case tcell.KeyDown:
			if b.CursorY < len(b.Lines)-1 {
				b.CursorY++
			}
			return true
		case tcell.KeyUp:
			if b.CursorY > 0 {
				b.CursorY--
			}
			return true
		case tcell.KeyRight:
			a.BlockColWidth++
			return true
		case tcell.KeyLeft:
			if a.BlockColWidth > 0 {
				a.BlockColWidth--
			}
			return true
		}
	}
	switch ev.Key() {
	case tcell.KeyEsc:
		a.cancelBlockSelect()
		return true
	case tcell.KeyCtrlC:
		a.copyBlockSelection()
		return true // mantém a marcação ativa, só copia
	case tcell.KeyCtrlX:
		a.copyBlockSelection()
		a.beginBlockEditing()
		a.updateBlockPreview() // BlockTyped ainda vazio: apaga o trecho
		a.commitBlockSelect()
		return true
	case tcell.KeyRune, tcell.KeyBackspace, tcell.KeyBackspace2, tcell.KeyEnter, tcell.KeyDelete:
		a.beginBlockEditing()
		return a.handleBlockEditingKey(ev)
	}
	// qualquer outra tecla (mover sem Ctrl+Shift, atalhos, etc) cancela
	// a marcação sem fazer nada — evita ficar "preso" no modo bloco.
	a.cancelBlockSelect()
	return false
}

// copyBlockSelection copia o retângulo marcado (uma linha por linha do
// texto, sem juntar com o resto de cada linha) pro clipboard interno.
func (a *App) copyBlockSelection() {
	b := a.Buffers[a.BlockPaneBuf]
	rowStart, rowEnd := a.BlockAnchorY, b.CursorY
	if rowStart > rowEnd {
		rowStart, rowEnd = rowEnd, rowStart
	}
	colStart, colEnd := a.BlockAnchorX, a.BlockAnchorX+a.BlockColWidth
	lines := make([]string, 0, rowEnd-rowStart+1)
	for y := rowStart; y <= rowEnd; y++ {
		line := b.Lines[y]
		c0, c1 := colStart, colEnd
		if c0 > len(line) {
			c0 = len(line)
		}
		if c1 > len(line) {
			c1 = len(line)
		}
		if c1 < c0 {
			c1 = c0
		}
		lines = append(lines, line[c0:c1])
	}
	a.Clipboard = strings.Join(lines, "\n")
	a.SetStatusMsg("bloco copiado")
}

// beginBlockEditing trava a forma do retângulo (linhas/colunas) e guarda
// uma cópia do texto original — a partir daqui, redimensionar o bloco
// não é mais possível, só editar o conteúdo dele.
func (a *App) beginBlockEditing() {
	b := a.Buffers[a.BlockPaneBuf]
	a.BlockRowStart, a.BlockRowEnd = a.BlockAnchorY, b.CursorY
	if a.BlockRowStart > a.BlockRowEnd {
		a.BlockRowStart, a.BlockRowEnd = a.BlockRowEnd, a.BlockRowStart
	}
	a.BlockOrigLines = make([]string, len(b.Lines))
	copy(a.BlockOrigLines, b.Lines)
	b.MarkUndoPoint()
	a.BlockEditing = true
	a.BlockTyped = ""
}

// handleBlockEditingKey trata as teclas depois que a edição do bloco já
// começou: digitar troca o conteúdo marcado em todas as linhas do
// retângulo de uma vez; Enter/Esc confirma e sai do modo bloco.
func (a *App) handleBlockEditingKey(ev *tcell.EventKey) bool {
	switch ev.Key() {
	case tcell.KeyEnter:
		a.commitBlockSelect()
		return true
	case tcell.KeyEsc:
		a.cancelBlockSelect()
		return true
	case tcell.KeyBackspace, tcell.KeyBackspace2:
		if len(a.BlockTyped) > 0 {
			r := []rune(a.BlockTyped)
			a.BlockTyped = string(r[:len(r)-1])
		}
		// sempre recalcula, mesmo com BlockTyped vazio — no primeiro
		// toque, isso é o que de fato apaga o trecho marcado (troca
		// pelo texto vazio), não só desfaz o que foi digitado depois.
		a.updateBlockPreview()
		return true
	case tcell.KeyDelete:
		// mesma coisa: aplica a troca atual (que começa vazia), o que
		// apaga o trecho marcado em todas as linhas de uma vez.
		a.updateBlockPreview()
		return true
	case tcell.KeyRune:
		a.BlockTyped += string(ev.Rune())
		a.updateBlockPreview()
		return true
	}
	// setas, Ctrl+shortcuts, etc: confirma o que já foi digitado e deixa
	// a tecla seguir pro fluxo normal (não trava o resto do editor).
	a.commitBlockSelect()
	return false
}

// updateBlockPreview recalcula as linhas do retângulo a partir do
// snapshot original + o que já foi digitado nessa sessão.
func (a *App) updateBlockPreview() {
	b := a.Buffers[a.BlockPaneBuf]
	newLines := make([]string, len(a.BlockOrigLines))
	copy(newLines, a.BlockOrigLines)
	col := a.BlockAnchorX
	for y := a.BlockRowStart; y <= a.BlockRowEnd; y++ {
		line := a.BlockOrigLines[y]
		c0, c1 := col, col+a.BlockColWidth
		if c0 > len(line) {
			c0 = len(line)
		}
		if c1 > len(line) {
			c1 = len(line)
		}
		if c1 < c0 {
			c1 = c0
		}
		newLines[y] = line[:c0] + a.BlockTyped + line[c1:]
	}
	b.Lines = newLines
	b.Dirty = true
	b.CursorY = a.BlockRowStart
	b.CursorX = col + len(a.BlockTyped)
}

// commitBlockSelect finaliza a edição em bloco (se algo foi digitado) e
// sai do modo — o snapshot inicial já virou undo point, então isso não
// precisa fazer mais nada além de limpar o estado.
func (a *App) commitBlockSelect() {
	a.BlockActive = false
	a.BlockEditing = false
	a.BlockOrigLines = nil
	a.BlockTyped = ""
}

// cancelBlockSelect sai do modo bloco sem aplicar nada — se já tinha
// começado a editar, desfaz o preview e volta ao texto original.
func (a *App) cancelBlockSelect() {
	if a.BlockEditing && a.BlockPaneBuf < len(a.Buffers) {
		b := a.Buffers[a.BlockPaneBuf]
		b.Lines = a.BlockOrigLines
	}
	a.BlockActive = false
	a.BlockEditing = false
	a.BlockOrigLines = nil
	a.BlockTyped = ""
}

// blockRange devolve os limites do retângulo marcado, já normalizados,
// pra desenhar o destaque na tela — funciona tanto antes (BlockActive,
// ainda ajustando a forma) quanto depois (BlockEditing) de começar a
// digitar.
func (a *App) blockRange() (rowStart, rowEnd, colStart, colEnd int) {
	if a.BlockEditing {
		return a.BlockRowStart, a.BlockRowEnd, a.BlockAnchorX, a.BlockAnchorX + a.BlockColWidth
	}
	b := a.Buffers[a.BlockPaneBuf]
	rowStart, rowEnd = a.BlockAnchorY, b.CursorY
	if rowStart > rowEnd {
		rowStart, rowEnd = rowEnd, rowStart
	}
	return rowStart, rowEnd, a.BlockAnchorX, a.BlockAnchorX + a.BlockColWidth
}
