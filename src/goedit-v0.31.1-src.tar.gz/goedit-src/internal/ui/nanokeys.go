/*
   goedit
   Editor de texto para terminal (TUI), com realce de sintaxe, plugins Lua, seleção em bloco e mais
   Site:      https://chililinux.com
   Site:      https://voidbr.org
   Site:      https://voidlinux.com.br
   GitHub:    https://github.com/voidlinuxbr/voidbr-goedit
   Created:   dom 16 ago 2026 10:15:33 -04
   Updated:   seg 24 ago 2026 14:30:00 -04
   Version:   0.31.1
   Copyright (C) 2019-2026 Vilmar Catafesta <vcatafesta@gmail.com>
*/

package ui

import (
	"fmt"
	"os"

	"github.com/gdamore/tcell/v2"
)

// tryNanoKey trata as teclas do estilo "nano" (settings.json:
// "keymap": "nano") — chamada antes do despacho normal (estilo
// vscode, o padrão do goedit) sempre que esse estilo estiver ativo.
// Devolve true se tratou a tecla (nesse caso, o despacho normal nem
// roda pra essa tecla); false pra deixar cair no comportamento normal
// (digitação, setas, Home/End sem Ctrl, Delete, Backspace sem Ctrl,
// Page Up/Down sem Ctrl — tudo isso já funciona igual em qualquer
// estilo, sem precisar de tratamento especial aqui).
//
// Cobre o subconjunto mais usado do nano de verdade — não inclui
// coisas como justificar parágrafo (Ctrl+J) ou corretor ortográfico
// (Ctrl+T), que fazem pouco sentido num editor voltado a código.
func (a *App) tryNanoKey(ev *tcell.EventKey) bool {
	km := a.Settings.Keymap
	if km != "nano" && km != "nano-hibrido" {
		return false
	}
	if ev.Key() != tcell.KeyCtrlK {
		a.nanoCutStreak = false // qualquer tecla que não seja Ctrl+K quebra a sequência de corte
	}
	b := a.ActiveBuffer()

	// Ctrl+K com acúmulo vale nos dois perfis nano (no nano-híbrido é
	// a única mudança em cima do Ctrl+K que já existia — continua
	// cortando a linha, só que acumulando em sequência igual o nano
	// clássico faz).
	if ev.Key() == tcell.KeyCtrlK {
		// Cut — igual o nano de verdade: Ctrl+K seguido de Ctrl+K de
		// novo (sem nenhuma outra tecla no meio) ACRESCENTA a linha
		// cortada ao que já tinha, em vez de substituir. Só assim um
		// Ctrl+U depois restaura todas as linhas cortadas em sequência
		// de uma vez, não só a última.
		if a.nanoCutStreak {
			a.copyToClipboard(a.Clipboard + b.Lines[b.CursorY] + "\n")
		} else {
			a.copyToClipboard(b.Lines[b.CursorY] + "\n")
		}
		b.DeleteLine()
		a.nanoCutStreak = true
		return true
	}
	if km != "nano" {
		return false // as teclas abaixo (Ctrl+G, Ctrl+O, Ctrl+A...) só valem no nano clássico
	}

	switch ev.Key() {
	case tcell.KeyCtrlG:
		// nano de verdade: Ctrl+G é ajuda (não "ir pra linha", que no
		// goedit em estilo vscode usa essa tecla)
		a.HelpActive = true
		a.HelpScroll = 0
		return true
	case tcell.KeyCtrlO:
		// WriteOut = salvar
		a.doSave()
		return true
	case tcell.KeyCtrlR:
		// Read File = insere o conteúdo de outro arquivo no cursor
		a.startPrompt("Ler arquivo: ", func(path string) {
			if path == "" {
				return
			}
			data, err := os.ReadFile(path)
			if err != nil {
				a.SetStatusMsg("erro ao ler arquivo: " + err.Error())
				return
			}
			b.InsertTextAtCursor(string(data))
		}, nil)
		return true
	case tcell.KeyCtrlW:
		// Where Is = buscar
		a.startSearchPrompt()
		return true
	case tcell.KeyCtrlBackslash:
		// Replace
		a.startPrompt("Substituir - buscar: ", func(find string) {
			a.startPrompt("Substituir por: ", func(repl string) {
				n := b.ReplaceAll(find, repl)
				a.SetStatusMsg(fmt.Sprintf("%d substituição(ões) feita(s)", n))
			}, nil)
		}, nil)
		return true
	case tcell.KeyCtrlU:
		// UnCut = colar
		if text := a.pasteFromClipboard(); text != "" {
			b.InsertTextAtCursor(text)
		}
		return true
	case tcell.KeyCtrlC:
		// Cur Pos = mostra a posição atual (não copia, isso é Ctrl+^
		// pra marcar seleção + outra tecla pra copiar, no nano de
		// verdade — mas copiar seleção via Ctrl+C já não existe nele)
		a.SetStatusMsg(fmt.Sprintf("linha %d de %d, coluna %d", b.CursorY+1, len(b.Lines), b.CursorX+1))
		return true
	case tcell.KeyCtrlUnderscore:
		// Go To Line (mesmo código de Ctrl+/ na maioria dos terminais
		// — em estilo nano, comentar linha fica sem atalho de Ctrl
		// dedicado, já que não é um conceito do nano)
		a.startPrompt("Ir para linha: ", func(input string) {
			var n int
			if _, err := fmt.Sscanf(input, "%d", &n); err == nil {
				b.GoToLine(n)
			}
		}, nil)
		return true
	case tcell.KeyCtrlCarat: // Ctrl+^ / Ctrl+6 — Mark Set
		if b.Selecting {
			b.ClearSelection()
			a.SetStatusMsg("seleção cancelada")
		} else {
			b.StartSelection()
			a.SetStatusMsg("marcação iniciada")
		}
		return true
	case tcell.KeyCtrlA:
		// Home (início da linha) — não "selecionar tudo", que é o
		// estilo vscode
		b.ClearSelection()
		b.CursorX = 0
		return true
	case tcell.KeyCtrlE:
		// End (fim da linha)
		b.ClearSelection()
		b.CursorX = len(b.Lines[b.CursorY])
		return true
	case tcell.KeyCtrlY:
		// Prev Page
		b.ClearSelection()
		h := a.pageHeight()
		for i := 0; i < h; i++ {
			b.MoveCursor(0, -1)
		}
		b.OffsetY -= h
		if b.OffsetY < 0 {
			b.OffsetY = 0
		}
		return true
	case tcell.KeyCtrlV:
		// Next Page (não colar — isso é Ctrl+U em estilo nano)
		b.ClearSelection()
		h := a.pageHeight()
		for i := 0; i < h; i++ {
			b.MoveCursor(0, 1)
		}
		b.OffsetY += h
		if maxOffset := len(b.Lines) - h; b.OffsetY > maxOffset {
			b.OffsetY = maxOffset
		}
		if b.OffsetY < 0 {
			b.OffsetY = 0
		}
		return true
	case tcell.KeyCtrlD:
		// apaga o caractere sob o cursor (não duplicar linha, que é
		// o estilo vscode)
		b.DeleteForward()
		return true
	case tcell.KeyCtrlH:
		// Backspace (não substituir, que é Ctrl+\ em estilo nano)
		b.Backspace()
		return true
	}
	return false
}
