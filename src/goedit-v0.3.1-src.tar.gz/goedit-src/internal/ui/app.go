package ui

import (
	"fmt"
	"os"
	"path/filepath"
	"sort"

	"github.com/gdamore/tcell/v2"

	"goedit/internal/buffer"
	"goedit/internal/config"
	"goedit/internal/plugin"
)

// App é o estado global do editor.
type App struct {
	Screen tcell.Screen

	Buffers    []*buffer.Buffer
	Panes      []int // índice do buffer mostrado em cada painel (1 ou 2 painéis)
	ActivePane int

	ShowSidebar    bool
	SidebarFocused bool
	SidebarPath    string
	SidebarEntries []os.DirEntry
	SidebarSel     int
	SidebarWidth   int

	// prompt genérico (usado por save-as, abrir arquivo, busca, substituir, paleta de comandos)
	PromptActive bool
	PromptLabel  string
	PromptInput  string
	onSubmit     func(input string)
	onCancel     func()

	LastSearch string
	StatusMsg  string
	Clipboard  string

	Settings      config.Settings
	OverwriteMode bool

	// Estado do "renomear ao vivo" (F2) — mostra todas as ocorrências da
	// palavra destacadas e vai atualizando o texto conforme o usuário
	// digita o novo nome, como o Rename Symbol do VS Code.
	RenameActive    bool
	RenameWord      string
	RenameNew       string
	RenameFirstKey  bool // true até a 1ª tecla digitada — limpa o nome pré-preenchido
	RenameOrigLines []string
	RenamePaneBuf   int // índice do buffer sendo renomeado
	RenameOccs      []buffer.WordOccurrence

	Plugins *plugin.Manager

	Quit bool

	// Layout guarda onde cada elemento foi desenhado no último Render(),
	// pra HandleMouse saber o que está embaixo de um clique.
	Layout RenderLayout
}

// PaneLayout é a área ocupada por um painel na última renderização.
type PaneLayout struct {
	BufIdx            int
	X, TabY           int // coluna inicial do painel; linha da barra de abas
	TextTop, TextX    int // linha onde o texto começa; coluna onde o texto começa (depois do gutter)
	Width, TextHeight int
	Gutter            int
	TabRanges         []TabRange // faixas de coluna [X0,X1) de cada aba desenhada, pra saber em qual clicou
}

// TabRange é a faixa horizontal ocupada pelo rótulo de uma aba na barra de abas.
type TabRange struct {
	BufIdx int
	X0, X1 int
}

// RenderLayout é o layout inteiro da última tela desenhada.
type RenderLayout struct {
	SidebarX0, SidebarY0, SidebarX1, SidebarY1 int
	SidebarVisible                             bool
	SidebarRowY0                               int // linha da primeira entrada da lista (depois do cabeçalho)
	Panes                                      []PaneLayout
}

// NewApp cria o app com um buffer inicial (arquivo passado por argumento, ou vazio).
func NewApp(screen tcell.Screen, initialPath string) *App {
	a := &App{
		Screen:       screen,
		ShowSidebar:  false,
		SidebarWidth: 28,
		Settings:     config.LoadSettings(),
	}

	var buf *buffer.Buffer
	if initialPath != "" {
		b, err := buffer.Open(initialPath)
		if err != nil {
			buf = buffer.New()
			a.StatusMsg = fmt.Sprintf("erro ao abrir %s: %v", initialPath, err)
		} else {
			buf = b
		}
	} else {
		buf = buffer.New()
	}
	a.Buffers = append(a.Buffers, buf)
	a.Panes = []int{0}

	cwd, _ := os.Getwd()
	if initialPath != "" {
		if abs, err := filepath.Abs(filepath.Dir(initialPath)); err == nil {
			cwd = abs
		}
	}
	a.SidebarPath = cwd
	a.reloadSidebar()

	a.Plugins = plugin.NewManager(a, config.PluginDir())
	if errs := a.Plugins.LoadAll(); len(errs) > 0 {
		a.StatusMsg = fmt.Sprintf("erro carregando plugin: %v", errs[0])
	}

	return a
}

// ActiveBuffer devolve o buffer mostrado no painel com foco.
func (a *App) ActiveBuffer() *buffer.Buffer {
	return a.Buffers[a.Panes[a.ActivePane]]
}

func (a *App) reloadSidebar() {
	entries, err := os.ReadDir(a.SidebarPath)
	if err != nil {
		a.SidebarEntries = nil
		return
	}
	sort.Slice(entries, func(i, j int) bool {
		di, dj := entries[i].IsDir(), entries[j].IsDir()
		if di != dj {
			return di // diretórios primeiro
		}
		return entries[i].Name() < entries[j].Name()
	})
	a.SidebarEntries = entries
	if a.SidebarSel >= len(a.SidebarEntries) {
		a.SidebarSel = 0
	}
}

// OpenFile abre um arquivo em uma nova aba (ou foca se já estiver aberto).
func (a *App) OpenFile(path string) {
	for i, b := range a.Buffers {
		if b.Path == path {
			a.Panes[a.ActivePane] = i
			return
		}
	}
	b, err := buffer.Open(path)
	if err != nil {
		a.StatusMsg = fmt.Sprintf("erro ao abrir %s: %v", path, err)
		return
	}
	a.Buffers = append(a.Buffers, b)
	a.Panes[a.ActivePane] = len(a.Buffers) - 1
}

// NewBuffer cria uma aba nova vazia.
func (a *App) NewBuffer() {
	a.Buffers = append(a.Buffers, buffer.New())
	a.Panes[a.ActivePane] = len(a.Buffers) - 1
}

// CloseActiveBuffer fecha a aba ativa do painel focado.
func (a *App) CloseActiveBuffer() {
	idx := a.Panes[a.ActivePane]
	if len(a.Buffers) == 1 {
		a.Buffers[0] = buffer.New()
		return
	}
	a.Buffers = append(a.Buffers[:idx], a.Buffers[idx+1:]...)
	for i := range a.Panes {
		if a.Panes[i] >= len(a.Buffers) {
			a.Panes[i] = len(a.Buffers) - 1
		} else if a.Panes[i] > idx {
			a.Panes[i]--
		}
	}
}

// NextTab avança pra próxima aba no painel ativo.
func (a *App) NextTab() {
	idx := a.Panes[a.ActivePane]
	idx = (idx + 1) % len(a.Buffers)
	a.Panes[a.ActivePane] = idx
}

// PrevTab volta pra aba anterior no painel ativo.
func (a *App) PrevTab() {
	idx := a.Panes[a.ActivePane]
	idx = (idx - 1 + len(a.Buffers)) % len(a.Buffers)
	a.Panes[a.ActivePane] = idx
}

// ToggleSplit ativa ou desativa o segundo painel.
func (a *App) ToggleSplit() {
	if len(a.Panes) == 1 {
		a.Panes = append(a.Panes, a.Panes[0])
	} else {
		a.Panes = a.Panes[:1]
		a.ActivePane = 0
	}
}

// SwitchPaneFocus alterna o foco entre os painéis abertos.
func (a *App) SwitchPaneFocus() {
	if len(a.Panes) < 2 {
		return
	}
	a.ActivePane = (a.ActivePane + 1) % len(a.Panes)
}

// startPrompt abre uma caixa de entrada na barra inferior.
func (a *App) startPrompt(label string, onSubmit func(string), onCancel func()) {
	a.PromptActive = true
	a.PromptLabel = label
	a.PromptInput = ""
	a.onSubmit = onSubmit
	a.onCancel = onCancel
}

func (a *App) cancelPrompt() {
	a.PromptActive = false
	if a.onCancel != nil {
		a.onCancel()
	}
}

func (a *App) submitPrompt() {
	a.PromptActive = false
	if a.onSubmit != nil {
		a.onSubmit(a.PromptInput)
	}
}
