package ui

import (
	"fmt"

	"github.com/gdamore/tcell/v2"
	"github.com/mattn/go-runewidth"

	"goedit/internal/buffer"
	"goedit/internal/syntax"
)

var (
	styleDefault    = tcell.StyleDefault
	styleStatus     = tcell.StyleDefault.Background(tcell.ColorDarkSlateGray).Foreground(tcell.ColorWhite)
	styleTabActive  = tcell.StyleDefault.Background(tcell.ColorSteelBlue).Foreground(tcell.ColorWhite).Bold(true)
	styleTabIdle    = tcell.StyleDefault.Background(tcell.ColorDarkSlateGray).Foreground(tcell.ColorLightGray)
	styleSidebar    = tcell.StyleDefault.Foreground(tcell.ColorLightGray)
	styleSidebarSel = tcell.StyleDefault.Background(tcell.ColorSteelBlue).Foreground(tcell.ColorWhite)
	styleLineNum    = tcell.StyleDefault.Foreground(tcell.ColorGray)
	styleDirty      = tcell.StyleDefault.Foreground(tcell.ColorOrange)
	styleSelection  = tcell.StyleDefault.Background(tcell.ColorDimGray)
	styleRename     = tcell.StyleDefault.Background(tcell.ColorDarkGoldenrod).Foreground(tcell.ColorBlack)
)

func drawText(s tcell.Screen, x, y int, style tcell.Style, text string) int {
	for _, r := range text {
		s.SetContent(x, y, r, nil, style)
		x += runewidth.RuneWidth(r)
	}
	return x
}

// Render desenha a tela inteira a partir do estado atual do App.
func (a *App) Render() {
	a.Screen.Clear()
	w, h := a.Screen.Size()
	if w < 20 || h < 5 {
		a.Screen.Show()
		return
	}

	editorTop := 0
	editorBottom := h - 2 // deixa 1 linha pra status, 1 pra prompt/mensagem
	editorLeft := 0

	layout := RenderLayout{}

	if a.ShowSidebar {
		a.drawSidebar(0, editorTop, a.SidebarWidth, editorBottom)
		editorLeft = a.SidebarWidth + 1
		layout.SidebarVisible = true
		layout.SidebarX0, layout.SidebarY0 = 0, editorTop
		layout.SidebarX1, layout.SidebarY1 = a.SidebarWidth, editorTop+editorBottom
		layout.SidebarRowY0 = editorTop + 1
	}

	paneCount := len(a.Panes)
	paneWidth := (w - editorLeft) / paneCount
	layout.Panes = make([]PaneLayout, paneCount)
	for i, bufIdx := range a.Panes {
		px := editorLeft + i*paneWidth
		pw := paneWidth
		if i == paneCount-1 {
			pw = w - px
		}
		pl := a.drawPane(bufIdx, px, editorTop, pw, editorBottom, i == a.ActivePane && !a.SidebarFocused)
		layout.Panes[i] = pl
	}
	a.Layout = layout

	a.drawStatusBar(0, h-2, w)
	a.drawBottomLine(0, h-1, w)

	// posiciona o cursor visível do terminal
	if !a.PromptActive && !a.SidebarFocused {
		bufIdx := a.Panes[a.ActivePane]
		b := a.Buffers[bufIdx]
		paneX := editorLeft + a.ActivePane*paneWidth
		gutter := lineNumWidth(len(b.Lines))
		tabWidth := a.Settings.TabWidth
		if tabWidth <= 0 {
			tabWidth = 4
		}
		cursorVCol := visualColOf(b.Lines[b.CursorY], b.CursorX, tabWidth)
		cx := paneX + gutter + (cursorVCol - b.OffsetX)
		cy := editorTop + 1 + (b.CursorY - b.OffsetY) // +1: a linha de abas fica acima do texto
		a.Screen.ShowCursor(cx, cy)
	} else {
		a.Screen.HideCursor()
	}

	a.Screen.Show()
}

// visualColOf calcula a coluna visual (na tela) correspondente a um índice
// de byte dentro da linha, respeitando tab-stops — necessário porque uma
// tabulação ocupa mais de 1 coluna, então índice de byte e coluna de tela
// divergem em qualquer linha que tenha \t.
func visualColOf(line string, byteIdx, tabWidth int) int {
	if byteIdx > len(line) {
		byteIdx = len(line)
	}
	if tabWidth <= 0 {
		tabWidth = 4
	}
	vcol := 0
	i := 0
	for _, r := range line {
		if i >= byteIdx {
			break
		}
		if r == '\t' {
			vcol += tabWidth - (vcol % tabWidth)
		} else {
			w := runewidth.RuneWidth(r)
			if w <= 0 {
				w = 1
			}
			vcol += w
		}
		i += len(string(r))
	}
	return vcol
}

// byteIndexForVisualCol é o inverso de visualColOf: dada uma coluna visual
// (coluna de tela) alvo, acha o índice de byte na linha que corresponde a
// ela — necessário pra saber em qual caractere um clique do mouse caiu,
// já que tabs ocupam mais de 1 coluna de tela.
func byteIndexForVisualCol(line string, targetVCol, tabWidth int) int {
	if tabWidth <= 0 {
		tabWidth = 4
	}
	vcol := 0
	i := 0
	for _, r := range line {
		if vcol >= targetVCol {
			return i
		}
		if r == '\t' {
			vcol += tabWidth - (vcol % tabWidth)
		} else {
			w := runewidth.RuneWidth(r)
			if w <= 0 {
				w = 1
			}
			vcol += w
		}
		i += len(string(r))
	}
	return len(line)
}

func lineNumWidth(nlines int) int {
	digits := 2
	n := nlines
	for n >= 10 {
		digits++
		n /= 10
	}
	if digits < 4 {
		digits = 4
	}
	return digits
}

func (a *App) drawSidebar(x, y, width, height int) {
	style := styleSidebar
	drawText(a.Screen, x, y, style.Bold(true), truncate(" ARQUIVOS", width))
	for row := 1; row < height; row++ {
		for c := 0; c < width; c++ {
			a.Screen.SetContent(x+c, y+row, ' ', nil, styleDefault)
		}
	}
	for i, e := range a.SidebarEntries {
		row := y + 1 + i
		if row >= y+height {
			break
		}
		name := e.Name()
		if e.IsDir() {
			name += "/"
		}
		st := style
		if a.SidebarFocused && i == a.SidebarSel {
			st = styleSidebarSel
		}
		line := truncate(" "+name, width)
		for len(line) < width {
			line += " "
		}
		drawText(a.Screen, x, row, st, line)
	}
	// borda direita
	for row := y; row < y+height; row++ {
		a.Screen.SetContent(x+width, row, '│', nil, styleSidebar)
	}
}

func (a *App) drawPane(bufIdx, x, y, width, height int, focused bool) PaneLayout {
	b := a.Buffers[bufIdx]
	tabRanges := a.drawTabs(bufIdx, x, y, width)

	gutter := lineNumWidth(len(b.Lines))
	textTop := y + 1
	textHeight := height - 1
	textWidth := width - gutter
	if textWidth < 1 {
		textWidth = 1
	}

	tabWidth := a.Settings.TabWidth
	if tabWidth <= 0 {
		tabWidth = 4
	}

	// ajusta scroll vertical/horizontal pra manter o cursor visível.
	// O scroll horizontal trabalha em COLUNA VISUAL (considerando o
	// espaço que uma tabulação ocupa na tela), não em índice bruto do
	// texto — senão uma linha com \t rola errado.
	if b.CursorY < b.OffsetY {
		b.OffsetY = b.CursorY
	}
	if b.CursorY >= b.OffsetY+textHeight {
		b.OffsetY = b.CursorY - textHeight + 1
	}
	cursorVCol := visualColOf(b.Lines[b.CursorY], b.CursorX, tabWidth)
	if cursorVCol < b.OffsetX {
		b.OffsetX = cursorVCol
	}
	if cursorVCol >= b.OffsetX+textWidth {
		b.OffsetX = cursorVCol - textWidth + 1
	}
	if b.OffsetY < 0 {
		b.OffsetY = 0
	}
	if b.OffsetX < 0 {
		b.OffsetX = 0
	}

	var selSY, selSX, selEY, selEX int
	hasSel := b.Selecting
	if hasSel {
		selSY, selSX, selEY, selEX = selectionRange(b.SelStartY, b.SelStartX, b.CursorY, b.CursorX)
	}

	renaming := a.RenameActive && bufIdx == a.RenamePaneBuf

	for row := 0; row < textHeight; row++ {
		lineIdx := b.OffsetY + row
		sy := textTop + row
		if lineIdx >= len(b.Lines) {
			drawText(a.Screen, x, sy, styleLineNum, fmt.Sprintf("%*s ", gutter-1, "~"))
			continue
		}
		numStr := fmt.Sprintf("%*d ", gutter-1, lineIdx+1)
		drawText(a.Screen, x, sy, styleLineNum, numStr)

		segs := syntax.HighlightLine(b.Path, b.Lines[0], b.Lines[lineIdx])
		cx := x + gutter
		vcol := 0   // coluna visual (considera largura de tab) desde o início da linha
		byteAt := 0 // posição em bytes desde o início da linha (bate com CursorX/SelStartX)
		for _, seg := range segs {
			for _, r := range seg.Text {
				runeBytes := len(string(r))
				st := seg.Style
				if hasSel && inSelection(lineIdx, byteAt, selSY, selSX, selEY, selEX) {
					st = styleSelection
				}
				if renaming && inRenameOccurrence(lineIdx, byteAt, a.RenameOccs) {
					st = styleRename
				}
				if r == '\t' {
					stop := tabWidth - (vcol % tabWidth)
					for k := 0; k < stop; k++ {
						if vcol >= b.OffsetX && cx < x+width {
							a.Screen.SetContent(cx, sy, ' ', nil, st)
							cx++
						}
						vcol++
					}
				} else {
					w := runewidth.RuneWidth(r)
					if w <= 0 {
						w = 1
					}
					if vcol >= b.OffsetX && cx < x+width {
						a.Screen.SetContent(cx, sy, r, nil, st)
						cx += w
					}
					vcol += w
				}
				byteAt += runeBytes
			}
		}
	}

	return PaneLayout{
		BufIdx:     bufIdx,
		X:          x,
		TabY:       y,
		TextTop:    textTop,
		TextX:      x + gutter,
		Width:      width,
		TextHeight: textHeight,
		Gutter:     gutter,
		TabRanges:  tabRanges,
	}
}

// selectionRange normaliza dois pontos (início/fim) na ordem em que aparecem no texto.
func selectionRange(sy, sx, ey, ex int) (int, int, int, int) {
	if sy > ey || (sy == ey && sx > ex) {
		return ey, ex, sy, sx
	}
	return sy, sx, ey, ex
}

// inSelection diz se a posição (linha, coluna) está dentro do intervalo selecionado.
func inSelection(y, x, sy, sx, ey, ex int) bool {
	if y < sy || y > ey {
		return false
	}
	if sy == ey {
		return x >= sx && x < ex
	}
	if y == sy {
		return x >= sx
	}
	if y == ey {
		return x < ex
	}
	return true
}

// inRenameOccurrence diz se a posição (linha, byte) cai dentro de alguma
// das ocorrências destacadas pelo modo de renomear ao vivo (F2).
func inRenameOccurrence(y, x int, occs []buffer.WordOccurrence) bool {
	for _, o := range occs {
		if o.Y == y && x >= o.X0 && x < o.X1 {
			return true
		}
	}
	return false
}

func (a *App) drawTabs(activeBufIdx, x, y, width int) []TabRange {
	cx := x
	var ranges []TabRange
	for i, b := range a.Buffers {
		name := b.Name()
		if b.Dirty {
			name = "*" + name
		}
		label := " " + name + " "
		st := styleTabIdle
		if i == activeBufIdx {
			st = styleTabActive
		}
		if cx+len(label) > x+width {
			break
		}
		x0 := cx
		cx = drawText(a.Screen, cx, y, st, label)
		ranges = append(ranges, TabRange{BufIdx: i, X0: x0, X1: cx})
	}
	for cx < x+width {
		a.Screen.SetContent(cx, y, ' ', nil, styleTabIdle)
		cx++
	}
	return ranges
}

func (a *App) drawStatusBar(x, y, width int) {
	b := a.ActiveBuffer()
	dirty := ""
	if b.Dirty {
		dirty = " [+]"
	}
	mode := "INS"
	if a.OverwriteMode {
		mode = "OVR"
	}
	left := fmt.Sprintf(" %s%s — linha %d, col %d — %s", b.Name(), dirty, b.CursorY+1, b.CursorX+1, mode)
	right := "Ctrl+P comandos · Ctrl+B sidebar · Ctrl+\\ split · Ctrl+Q sair "
	line := left
	for len(line)+len(right) < width {
		line += " "
	}
	line += right
	drawText(a.Screen, x, y, styleStatus, truncate(line, width))
}

func (a *App) drawBottomLine(x, y, width int) {
	if a.RenameActive {
		n := len(a.RenameOccs)
		text := fmt.Sprintf("Renomear '%s' (%d ocorrência(s)) para: %s   [Enter confirma · Esc cancela]",
			a.RenameWord, n, a.RenameNew)
		drawText(a.Screen, x, y, styleRename, truncate(text, width))
		return
	}
	if a.PromptActive {
		text := a.PromptLabel + a.PromptInput
		drawText(a.Screen, x, y, styleDefault, truncate(text, width))
		return
	}
	if a.StatusMsg != "" {
		drawText(a.Screen, x, y, styleDirty, truncate(a.StatusMsg, width))
	}
}

func truncate(s string, width int) string {
	if width <= 0 {
		return ""
	}
	r := []rune(s)
	if len(r) <= width {
		return s
	}
	return string(r[:width])
}
