/*
   goedit
   Editor de texto para terminal (TUI), com realce de sintaxe, plugins Lua, seleção em bloco e mais
   Site:      https://chililinux.com
   Site:      https://voidbr.org
   Site:      https://voidlinux.com.br
   GitHub:    https://github.com/voidlinuxbr/voidbr-goedit
   Created:   dom 16 ago 2026 10:15:33 -04
   Updated:   sex 21 ago 2026 11:30:00 -04
   Version:   0.28.0
   Copyright (C) 2019-2026 Vilmar Catafesta <vcatafesta@gmail.com>
*/

package ui

// Este arquivo implementa plugin.EditorAPI, a interface que os scripts Lua
// enxergam através da tabela global `goedit` (ver internal/plugin).

func (a *App) GetLine(y int) string {
	b := a.ActiveBuffer()
	if y < 0 || y >= len(b.Lines) {
		return ""
	}
	return b.Lines[y]
}

func (a *App) SetLine(y int, text string) {
	b := a.ActiveBuffer()
	if y < 0 || y >= len(b.Lines) {
		return
	}
	b.Lines[y] = text
	b.Dirty = true
}

func (a *App) LineCount() int {
	return len(a.ActiveBuffer().Lines)
}

func (a *App) GetCursor() (int, int) {
	b := a.ActiveBuffer()
	return b.CursorX, b.CursorY
}

func (a *App) SetCursor(x, y int) {
	b := a.ActiveBuffer()
	b.CursorY = y
	b.CursorX = x
}

func (a *App) InsertText(text string) {
	b := a.ActiveBuffer()
	for _, r := range text {
		if r == '\n' {
			b.InsertNewline()
			continue
		}
		b.InsertRune(r)
	}
}

func (a *App) CurrentFileName() string {
	return a.ActiveBuffer().Path
}

func (a *App) Notify(msg string) {
	a.SetStatusMsg(msg)
}
