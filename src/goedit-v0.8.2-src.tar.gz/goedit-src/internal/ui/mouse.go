package ui

import (
	"github.com/gdamore/tcell/v2"
)

// mouseDragging indica se o botão esquerdo está sendo segurado desde um
// clique anterior no texto — usado pra saber se um movimento de mouse com
// botão pressionado deve estender a seleção.
var mouseDragging bool

// --- Entrada principal ---

// HandleMouse processa clique, arrasto e roda do mouse. A ordem de
// despacho é sempre a mesma: roda primeiro (sidebar tem prioridade sobre
// o painel de texto), depois clique na sidebar, depois clique em
// aba/texto de algum painel.
func (a *App) HandleMouse(ev *tcell.EventMouse) {
	if a.PromptActive {
		return // prompts não reagem a mouse por enquanto
	}

	x, y := ev.Position()
	btn := ev.Buttons()

	if delta, ok := wheelDelta(btn); ok {
		a.handleWheel(x, y, delta)
		return
	}

	if a.pointInSidebar(x, y) {
		if btn&tcell.Button1 != 0 {
			a.clickSidebar(y)
		}
		return
	}

	a.handlePaneClick(x, y, btn, ev.Modifiers()&tcell.ModShift != 0)
}

// wheelDelta traduz o estado dos botões num delta de rolagem (+3 pra
// baixo, -3 pra cima), ou ok=false se o evento não é de roda.
func wheelDelta(btn tcell.ButtonMask) (delta int, ok bool) {
	switch {
	case btn&tcell.WheelUp != 0:
		return -3, true
	case btn&tcell.WheelDown != 0:
		return 3, true
	default:
		return 0, false
	}
}

// handleWheel rola a sidebar se o ponteiro estiver em cima dela, senão
// rola o painel de texto sob o ponteiro.
func (a *App) handleWheel(x, y, delta int) {
	if a.scrollSidebarAt(x, y, delta) {
		return
	}
	a.scrollPaneAt(x, y, delta)
}

// pointInSidebar diz se a coordenada de tela cai dentro da área visível
// da sidebar (usado tanto pra clique quanto pra roda do mouse).
func (a *App) pointInSidebar(x, y int) bool {
	return a.Layout.SidebarVisible &&
		x >= a.Layout.SidebarX0 && x < a.Layout.SidebarX1 &&
		y >= a.Layout.SidebarY0 && y < a.Layout.SidebarY1
}

// handlePaneClick trata clique/arrasto/soltura de botão dentro de algum
// painel de edição (aba ou texto).
func (a *App) handlePaneClick(x, y int, btn tcell.ButtonMask, extendSelection bool) {
	for i, pl := range a.Layout.Panes {
		if x < pl.X || x >= pl.X+pl.Width {
			continue
		}
		if btn&tcell.Button1 == 0 {
			// botão solto: encerra o arrasto de seleção, se houver
			mouseDragging = false
			return
		}

		a.ActivePane = i
		a.SidebarFocused = false

		if y == pl.TabY {
			a.clickTabAt(pl, x)
			mouseDragging = false
			return
		}
		if y >= pl.TextTop && y < pl.TextTop+pl.TextHeight {
			a.clickText(pl, x, y, extendSelection)
			return
		}
		return
	}
}

// --- Sidebar ---

// clickSidebar seleciona e abre a entrada clicada. Abrir um arquivo pelo
// mouse funciona igual ao Enter do teclado: abre numa aba e mantém a
// sidebar aberta (só perde o foco) — ela só fecha de verdade quando o
// usuário aperta Ctrl+B de novo, nunca sozinha por causa de um clique.
func (a *App) clickSidebar(y int) {
	idx := a.SidebarOffset + (y - a.Layout.SidebarRowY0)
	if idx < 0 || idx >= len(a.SidebarEntries) {
		return
	}
	a.SidebarSel = idx
	a.SidebarFocused = true
	a.openSidebarEntry(a.SidebarEntries[idx])
}

// scrollSidebarAt rola a lista de arquivos da sidebar quando o mouse está
// em cima dela. Devolve false se o ponteiro não está sobre a sidebar (pra
// o chamador tentar rolar o painel de texto em vez disso).
func (a *App) scrollSidebarAt(x, y, delta int) bool {
	if !a.pointInSidebar(x, y) {
		return false
	}
	a.SidebarSel = clamp(a.SidebarSel+delta, 0, len(a.SidebarEntries)-1)
	return true
}

// --- Abas e texto ---

func (a *App) clickTabAt(pl PaneLayout, x int) {
	for _, tr := range pl.TabRanges {
		if x >= tr.X0 && x < tr.X1 {
			a.Panes[a.ActivePane] = tr.BufIdx
			return
		}
	}
}

// clickText posiciona o cursor (ou estende a seleção) na posição de
// texto correspondente à coordenada de tela clicada, considerando
// scroll horizontal/vertical e largura de tabulação.
func (a *App) clickText(pl PaneLayout, x, y int, extendSelection bool) {
	b := a.Buffers[pl.BufIdx]

	lineIdx := clamp(b.OffsetY+(y-pl.TextTop), 0, len(b.Lines)-1)

	tabWidth := a.Settings.TabWidth
	if tabWidth <= 0 {
		tabWidth = 4
	}
	targetVCol := b.OffsetX + (x - pl.TextX)
	if targetVCol < 0 {
		targetVCol = 0
	}
	col := byteIndexForVisualCol(b.Lines[lineIdx], targetVCol, tabWidth)

	if extendSelection || mouseDragging {
		if !b.Selecting {
			// início de um arrasto nunca marcado: ancora na posição
			// atual do cursor antes de mover
			b.StartSelection()
		}
	} else {
		b.ClearSelection()
	}
	b.CursorY = lineIdx
	b.CursorX = col
	mouseDragging = true
}

// scrollPaneAt rola o painel de texto sob o cursor do mouse, movendo o
// cursor junto (o auto-scroll da renderização segue a posição do cursor,
// então não dá pra rolar a viewport sem mover o cursor também neste
// editor) — o cursor fica sempre na mesma linha de tela onde o ponteiro
// está, não foge pras extremidades.
func (a *App) scrollPaneAt(x, y, delta int) {
	for i, pl := range a.Layout.Panes {
		if x < pl.X || x >= pl.X+pl.Width {
			continue
		}
		if y < pl.TextTop || y >= pl.TextTop+pl.TextHeight {
			continue
		}
		b := a.Buffers[pl.BufIdx]
		b.ClearSelection()

		mouseLineIdx := b.OffsetY + (y - pl.TextTop)

		maxOffset := len(b.Lines) - pl.TextHeight
		if maxOffset < 0 {
			maxOffset = 0
		}
		b.OffsetY = clamp(b.OffsetY+delta, 0, maxOffset)
		b.CursorY = clamp(mouseLineIdx+delta, 0, len(b.Lines)-1)
		b.CursorX = 0

		a.ActivePane = i
		return
	}
}

// clamp restringe v ao intervalo [lo, hi]. Se hi < lo (ex: lista vazia,
// len-1 = -1), devolve lo.
func clamp(v, lo, hi int) int {
	if v < lo {
		return lo
	}
	if hi >= lo && v > hi {
		return hi
	}
	return v
}
